from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


LEGACY_KEY = re.compile(r"^(?P<key>[a-z0-9_.]+):\s*(?P<value>.+)$")


def _coerce(value: str) -> object:
    value = value.strip()
    if re.fullmatch(r"-?\d+", value):
        return int(value)
    try:
        return float(value)
    except ValueError:
        return value


def parse_legacy_report(text: str) -> dict[str, object]:
    datasets: dict[str, dict[str, object]] = {}
    summary: dict[str, object] = {}
    current: dict[str, object] | None = None
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if line.startswith("== ") and line.endswith(" =="):
            label = line[3:-3]
            if label == "suite summary":
                current = summary
            else:
                current = datasets.setdefault(label, {})
            continue
        if current is None:
            continue
        match = LEGACY_KEY.match(line)
        if match is not None:
            current[match.group("key")] = _coerce(match.group("value"))
    return {"summary": summary, "datasets": datasets}


def build_comparison(
    decomp_report: dict[str, object], legacy_report: dict[str, object]
) -> dict[str, object]:
    backend = dict(dict(decomp_report["backends"])["native"])
    legacy_summary = dict(legacy_report["summary"])
    decomp_cases = list(backend["cases"])
    legacy_datasets = dict(legacy_report["datasets"])
    legacy_by_name = {
        Path(str(label)).name: row for label, row in legacy_datasets.items()
    }
    shared_rows = []
    for raw_case in decomp_cases:
        case = dict(raw_case)
        name = Path(str(case["replay"])).name
        shared_rows.append(
            {
                "replay": str(case["replay"]),
                "characters": list(case["characters"]),
                "stage_id": case["stage_id"],
                "decomp_status": case["status"],
                "decomp_exact_prefix_frames": case.get("exact_prefix_frames"),
                "decomp_mismatched_frames": case.get("mismatched_frames"),
                "legacy": legacy_by_name.get(name),
            }
        )

    counts = dict(backend["counts"])
    return {
        "schema": "MSL_BACKEND_COMPARISON1",
        "measurement_contract": {
            "decomp": (
                "Cold-prefix replay from canonical match start. Every serialized "
                "validation field is compared with Slippi; strict classifications are enabled."
            ),
            "legacy": (
                "Replay-anchored rollout streaks. Legacy hidden state is reconstructed from "
                "Slippi at each restart, then recorded inputs run until a discrete-state mismatch."
            ),
            "warning": (
                "These axes are intentionally not collapsed into one score. Decomp tests full "
                "prefix fidelity; legacy tests local seeded-rollout survival."
            ),
        },
        "decomp": {
            "cases": len(decomp_cases),
            "counts": counts,
            "compared_frames": backend["compared_frames"],
            "matched_frames": backend["matched_frames"],
            "exact_frame_ratio": backend["exact_frame_ratio"],
            "wall_seconds": backend["wall_seconds"],
            "aggregate_fps": backend["aggregate_fps"],
        },
        "legacy": {
            "cases": len(legacy_datasets),
            "streak_count": legacy_summary.get("overall.rollout.streak_count"),
            "median_streak_frames": legacy_summary.get(
                "overall.rollout.streak_len.median"
            ),
            "p90_streak_frames": legacy_summary.get(
                "overall.rollout.streak_len.p90"
            ),
            "p95_streak_frames": legacy_summary.get(
                "overall.rollout.streak_len.p95"
            ),
            "max_streak_frames": legacy_summary.get(
                "overall.rollout.streak_len.max"
            ),
            "first_mismatch_total": legacy_summary.get(
                "overall.rollout.first_mismatch_total"
            ),
            "seeded_first_mismatch_total": legacy_summary.get(
                "overall.rollout.first_mismatch_seeded_total"
            ),
            "status": legacy_summary.get("overall.rollout.status"),
        },
        "interpretation": (
            "On this shared corpus, the decomp backend is the stronger replay simulator if it "
            "retains a near-perfect strict frame ratio while legacy local rollouts break after "
            "short streaks. Legacy remains valuable where it supports a character or injection "
            "contract that decomp has not yet acquired."
        ),
        "cases": shared_rows,
    }


def markdown_report(comparison: dict[str, object]) -> str:
    decomp = dict(comparison["decomp"])
    legacy = dict(comparison["legacy"])
    counts = dict(decomp["counts"])
    ratio = 100.0 * float(decomp["exact_frame_ratio"])
    return "\n".join(
        (
            "# MSL backend parity checkpoint",
            "",
            "## Result",
            "",
            f"- Decomp strict replay frames: {int(decomp['matched_frames']):,}/"
            f"{int(decomp['compared_frames']):,} ({ratio:.4f}%).",
            f"- Decomp cases: {counts.get('pass', 0)} pass, "
            f"{counts.get('fail', 0)} raw fail, {counts.get('error', 0)} error.",
            f"- Legacy seeded-rollout median: {legacy['median_streak_frames']} frames; "
            f"p90: {legacy['p90_streak_frames']} frames; max: {legacy['max_streak_frames']} frames.",
            f"- Legacy first mismatches: {legacy['first_mismatch_total']} "
            f"({legacy['seeded_first_mismatch_total']} at the seeded boundary).",
            "",
            "## Interpretation",
            "",
            str(comparison["interpretation"]),
            "",
            "## Measurement contract",
            "",
            f"- Decomp: {dict(comparison['measurement_contract'])['decomp']}",
            f"- Legacy: {dict(comparison['measurement_contract'])['legacy']}",
            f"- Caution: {dict(comparison['measurement_contract'])['warning']}",
            "",
        )
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Combine decomp strict validation and legacy rollout reports."
    )
    parser.add_argument("--decomp-json", type=Path, required=True)
    parser.add_argument("--legacy-report", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    parser.add_argument("--out-md", type=Path, required=True)
    args = parser.parse_args()

    decomp = json.loads(args.decomp_json.read_text())
    legacy = parse_legacy_report(args.legacy_report.read_text())
    comparison = build_comparison(decomp, legacy)
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_md.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_text(json.dumps(comparison, indent=2, sort_keys=True) + "\n")
    args.out_md.write_text(markdown_report(comparison))
    print(json.dumps({"out_json": str(args.out_json), "out_md": str(args.out_md)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
