from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from peppi_py import _read_slippi

import melee_sim as msl
from melee_sim import dtypes
from tools.validation.slpz import replay_path_for_peppi
from tools.validation.validate_replay import load_native


POLICY_CONTROLLER_PLAYER_DTYPE = np.dtype(
    [
        ("buttons", "<u2"),
        ("main_x", "<f4"),
        ("main_y", "<f4"),
        ("c_x", "<f4"),
        ("c_y", "<f4"),
        ("shoulder", "<f4"),
    ],
    align=False,
)
POLICY_CONTROLLER_DTYPE = np.dtype(
    [("players", POLICY_CONTROLLER_PLAYER_DTYPE, (4,))], align=False
)


@dataclass(frozen=True, slots=True)
class ReplayAuthority:
    config: np.ndarray
    previous_input: np.ndarray
    frames: np.ndarray
    frame_ids: np.ndarray
    policy_controllers: np.ndarray

    def frame_index(self, frame_id: int) -> int:
        matches = np.flatnonzero(self.frame_ids == int(frame_id))
        if matches.size != 1:
            raise ValueError(
                f"expected one finalized replay frame {frame_id}, found {matches.size}"
            )
        return int(matches[0])


@dataclass(frozen=True, slots=True)
class ReplayCheckpoint:
    frame_id: int
    frame_index: int
    observation: np.void
    state: bytes


def extract_replay_authority(
    replay: str | Path,
    *,
    ucf_cardinals_1_0_enabled: bool = True,
    ucf_shield_sdi_enabled: bool = True,
    ucf_sdi_enabled: bool = True,
    ucf_shield_drop_extended_enabled: bool = True,
    played_on: str | None = None,
) -> ReplayAuthority:
    native = load_native()
    with replay_path_for_peppi(Path(replay)) as peppi_path:
        game = _read_slippi(str(peppi_path), False)
        metadata = game.metadata
        if played_on is not None:
            metadata = dict(metadata)
            metadata["playedOn"] = played_on
        packet = native.extract_replay_authority(
            game.frames,
            game.start,
            metadata,
            ucf_cardinals_1_0_enabled=ucf_cardinals_1_0_enabled,
            ucf_shield_sdi_enabled=ucf_shield_sdi_enabled,
            ucf_sdi_enabled=ucf_sdi_enabled,
            ucf_shield_drop_extended_enabled=(
                ucf_shield_drop_extended_enabled
            ),
        )

    config = np.frombuffer(
        packet["config"], dtype=dtypes.replay_match_config_dtype()
    ).copy()
    previous_input = np.frombuffer(
        packet["previous_input"], dtype=dtypes.replay_input_dtype()
    ).copy()
    frames = np.frombuffer(
        packet["frames"], dtype=dtypes.replay_frame_dtype()
    ).copy()
    frame_ids = np.frombuffer(packet["frame_ids"], dtype="<i4").copy()
    policy_controllers = np.frombuffer(
        packet["policy_controllers"], dtype=POLICY_CONTROLLER_DTYPE
    ).copy()
    frame_count = int(packet["frame_count"])
    if (
        config.shape != (1,)
        or previous_input.shape != (1,)
        or frames.shape != (frame_count,)
        or frame_ids.shape != (frame_count,)
        or policy_controllers.shape != (frame_count,)
    ):
        raise RuntimeError("native replay authority packet has inconsistent dimensions")
    return ReplayAuthority(
        config, previous_input, frames, frame_ids, policy_controllers
    )


def warm_replay_checkpoint(
    authority: ReplayAuthority,
    frame_id: int,
    *,
    data_dir: str | Path | None = None,
    buffer_length: int = 256,
) -> ReplayCheckpoint:
    target = authority.frame_index(frame_id)
    if buffer_length <= 0:
        raise ValueError("buffer_length must be positive")
    with msl.EnvBatch(
        batch_size=1,
        length=buffer_length,
        data_dir=data_dir,
        action_format="raw",
    ) as env:
        env.reset_replay(authority.config, authority.previous_input)
        for logical_pos in range(target + 1):
            if env.t == env.length:
                env.reset_cursor()
            env.step_replay(authority.frames[logical_pos : logical_pos + 1])
        return ReplayCheckpoint(
            frame_id=int(frame_id),
            frame_index=target,
            observation=env.current_frame[0].copy(),
            state=env.save(0),
        )
