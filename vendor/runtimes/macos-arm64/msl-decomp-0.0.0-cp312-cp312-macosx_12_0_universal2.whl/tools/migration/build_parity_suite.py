from __future__ import annotations

import argparse
import json
import re
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Iterable

from tools.validation.suite_io import ReplaySuite, SuiteReplay, load_suite


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_LEGACY_CHARACTERS = (
    "Fox",
    "Falco",
    "Marth",
    "Captain Falcon",
    "Sheik",
    "Zelda",
    "Jigglypuff",
    "Peach",
    "Samus",
    "Pikachu",
    "Ganondorf",
)
DEFAULT_STAGES = (2, 3, 8, 28, 31, 32)


def _entry_characters(entry: SuiteReplay) -> tuple[str, ...]:
    if entry.characters is None:
        return ()
    return tuple(
        str(entry.characters[str(port)])
        for port in entry.ports
        if str(port) in entry.characters
    )


def filter_overlap_cases(
    entries: Iterable[SuiteReplay],
    *,
    characters: Iterable[str],
    stages: Iterable[int],
) -> list[SuiteReplay]:
    character_scope = {str(character).casefold() for character in characters}
    stage_scope = {int(stage) for stage in stages}
    selected: list[SuiteReplay] = []
    for entry in entries:
        entry_characters = _entry_characters(entry)
        if (
            entry.stage_id is None
            or int(entry.stage_id) not in stage_scope
            or len(entry_characters) != len(entry.ports)
            or not all(character.casefold() in character_scope for character in entry_characters)
        ):
            continue
        selected.append(entry)
    return selected


def select_coverage_cases(
    entries: Iterable[SuiteReplay], *, max_cases: int
) -> list[SuiteReplay]:
    candidates = list(entries)
    if max_cases <= 0 or max_cases >= len(candidates):
        return candidates

    coverage = [
        {
            (character.casefold(), int(entry.stage_id))
            for character in _entry_characters(entry)
        }
        for entry in candidates
    ]
    uncovered = set().union(*coverage)
    remaining = list(range(len(candidates)))
    chosen: list[int] = []
    while remaining and len(chosen) < max_cases:
        best = max(
            remaining,
            key=lambda index: (len(coverage[index] & uncovered), -index),
        )
        chosen.append(best)
        uncovered -= coverage[best]
        remaining.remove(best)
    return [candidates[index] for index in sorted(chosen)]


def _rewrite_replay_path(replay: str, replay_root: str | None) -> str:
    if replay_root is None:
        return replay
    parts = PurePosixPath(replay).parts
    if re.match(r"^(?:[A-Za-z]:[\\/]|\\\\)", replay_root):
        return str(PureWindowsPath(replay_root).joinpath(*parts))
    return str(Path(replay_root).joinpath(*parts))


def suite_payload(
    source: ReplaySuite,
    entries: Iterable[SuiteReplay],
    *,
    replay_root: str | None = None,
) -> dict[str, object]:
    replay_rows: list[dict[str, object]] = []
    for entry in entries:
        row: dict[str, object] = {
            "replay": _rewrite_replay_path(entry.replay, replay_root),
            "ports": list(entry.ports),
            "stage_id": entry.stage_id,
            "characters": entry.characters,
        }
        optional = {
            "ucf_cardinals_1_0_enabled": entry.ucf_cardinals_1_0_enabled,
            "ucf_shield_sdi_enabled": entry.ucf_shield_sdi_enabled,
            "ucf_sdi_enabled": entry.ucf_sdi_enabled,
            "ucf_shield_drop_extended_enabled": (
                entry.ucf_shield_drop_extended_enabled
            ),
            "played_on": entry.played_on,
        }
        row.update({key: value for key, value in optional.items() if value is not None})
        replay_rows.append(row)

    return {
        "name": f"{source.name}_legacy_overlap",
        "notes": (
            "Generated cross-backend parity inventory. Replay order is inherited "
            "from the decomp aggregate; an optional cap uses greedy character/stage coverage."
        ),
        "ucf_enabled": source.ucf_enabled,
        "ucf_cardinals_1_0_enabled": source.ucf_cardinals_1_0_enabled,
        "team_attack_on": source.team_attack_on,
        "replays": replay_rows,
    }


def _csv(value: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in value.split(",") if part.strip())


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build a shared replay suite for legacy/decomp parity checks."
    )
    parser.add_argument(
        "--suite",
        type=Path,
        default=ROOT / "replays/suites/melee_core_aggregate.json",
    )
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--characters", default=",".join(DEFAULT_LEGACY_CHARACTERS)
    )
    parser.add_argument(
        "--stages", default=",".join(str(stage) for stage in DEFAULT_STAGES)
    )
    parser.add_argument(
        "--max-cases",
        type=int,
        default=0,
        help="Greedy character/stage coverage cap; zero keeps every overlap case.",
    )
    parser.add_argument(
        "--replay-root",
        default=None,
        help="Rewrite replay paths under this root, including Windows or UNC roots.",
    )
    args = parser.parse_args()
    if args.max_cases < 0:
        parser.error("--max-cases must be non-negative")

    source = load_suite(args.suite)
    overlap = filter_overlap_cases(
        source.replays,
        characters=_csv(args.characters),
        stages=(int(stage) for stage in _csv(args.stages)),
    )
    selected = select_coverage_cases(overlap, max_cases=args.max_cases)
    payload = suite_payload(source, selected, replay_root=args.replay_root)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n")

    coverage = sorted(
        {
            (character, int(entry.stage_id))
            for entry in selected
            for character in _entry_characters(entry)
        }
    )
    print(
        json.dumps(
            {
                "source_cases": len(source.replays),
                "overlap_cases": len(overlap),
                "selected_cases": len(selected),
                "character_stage_pairs": len(coverage),
                "out": str(args.out),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
