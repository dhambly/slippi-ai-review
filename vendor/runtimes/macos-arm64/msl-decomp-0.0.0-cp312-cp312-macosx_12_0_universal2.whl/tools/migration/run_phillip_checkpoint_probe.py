from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np

import melee_sim as msl
from melee_sim import dtypes
from tools.migration.replay_checkpoint import extract_replay_authority
from tools.modelplay.phillip_adapter import (
    controller_to_input_player,
    controllers_from_policy_row,
    game_from_observation,
)
from tools.modelplay.phillip_agent import (
    AnimationFilter,
    batch_games,
    build_agent,
    decoded_controllers,
    force_previous_controller,
    import_eval_lib,
    load_state,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Warm a replay-exact MSL checkpoint and probe Phillip takeover."
    )
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--takeover-frame", type=int, required=True)
    parser.add_argument("--analyzed-player", type=int, choices=(0, 1), required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--slippi-ai-root", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--warmup-frames", type=int, default=180)
    parser.add_argument("--rollout-frames", type=int, default=90)
    parser.add_argument("--defender-takeover-delay", type=int, default=60)
    parser.add_argument("--sample-temperature", type=float, default=1.0)
    parser.add_argument(
        "--replay-bridge-policy-delay",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Postpone analyzed-player control by Phillip's delay window. "
            "The default applies the already-warmed delayed queue immediately."
        ),
    )
    parser.add_argument("--disable-gpu", action="store_true")
    parser.add_argument("--out", type=Path, required=True)
    return parser.parse_args()


def _viewpoint_games(
    env: msl.EnvBatch,
    controllers: dict[int, object],
    *,
    num_players: int,
) -> Any:
    if env.t == env.length:
        env.reset_cursor()
    games = []
    for viewpoint in range(num_players):
        env.observe_viewpoints(np.array([viewpoint], dtype=np.uint8))
        games.append(game_from_observation(env.current_frame[0].copy(), controllers))
    return batch_games(games)


def _controller_json(controller: object) -> dict[str, object]:
    return {
        "buttons": [
            name
            for name in controller.buttons._fields
            if bool(getattr(controller.buttons, name))
        ],
        "main": [
            round(float(controller.main_stick.x), 6),
            round(float(controller.main_stick.y), 6),
        ],
        "c": [
            round(float(controller.c_stick.x), 6),
            round(float(controller.c_stick.y), 6),
        ],
        "shoulder": round(float(controller.shoulder), 6),
    }


def _state_json(observation: np.void) -> dict[str, object]:
    players = sorted(
        (slot for slot in observation["slots"] if slot["present"]),
        key=lambda slot: int(slot["source_player"]),
    )
    return {
        "frame": int(observation["frame_id"]),
        "players": [
            {
                "player": int(slot["source_player"]),
                "action": int(slot["action_id"]),
                "actionFrame": int(slot["action_frame"]),
                "x": round(float(slot["pos_x"]), 6),
                "y": round(float(slot["pos_y"]), 6),
                "percent": round(float(slot["percent"]), 4),
                "stocks": int(slot["stocks"]),
                "hitlag": int(slot["hitlag"]),
                "hitstun": int(slot["hitstun"]),
            }
            for slot in players
        ],
    }


def main() -> int:
    args = parse_args()
    if args.warmup_frames < 1 or args.rollout_frames < 1:
        raise SystemExit("--warmup-frames and --rollout-frames must be positive")
    started = time.perf_counter()
    authority = extract_replay_authority(args.replay)
    target = authority.frame_index(args.takeover_frame)
    num_players = int(authority.config[0]["match"]["num_players"])
    if num_players != 2:
        raise SystemExit("the first Phillip checkpoint probe supports two-player games")
    defender = 1 - args.analyzed_player

    eval_lib = import_eval_lib(args.slippi_ai_root, disable_gpus=args.disable_gpu)
    state = load_state(eval_lib, args.model)
    agent = build_agent(
        eval_lib,
        state=state,
        batch_size=num_players,
        sample_temperature=args.sample_temperature,
    )
    agent.start()
    delay = max(0, int(agent.delay))
    analyzed_control_frame = args.takeover_frame + (
        delay if args.replay_bridge_policy_delay else 0
    )
    defender_takeover_frame = (
        args.takeover_frame + args.defender_takeover_delay
    )
    defender_control_frame = defender_takeover_frame
    animation_filter = AnimationFilter(
        num_players, enabled=bool(agent.observation_config.animation.mask)
    )
    trace: list[dict[str, object]] = []
    timings = {"extractAndModelStartupSeconds": time.perf_counter() - started}

    try:
        with msl.EnvBatch(
            batch_size=1,
            length=256,
            data_dir=args.data_dir,
            action_format="raw",
        ) as env:
            env.reset_replay(authority.config, authority.previous_input)
            warm_start = max(0, target - args.warmup_frames + 1)
            outputs = None
            needs_reset = np.ones(num_players, dtype=np.bool_)
            warm_started = time.perf_counter()
            for record in range(target + 1):
                if env.t == env.length:
                    env.reset_cursor()
                env.step_replay(authority.frames[record : record + 1])
                if record < warm_start:
                    continue
                controllers = controllers_from_policy_row(
                    authority.policy_controllers[record], num_players=num_players
                )
                games = _viewpoint_games(
                    env, controllers, num_players=num_players
                )
                animation_filter.filter(games, needs_reset)
                policy_record = min(record + delay, len(authority.frames) - 1)
                policy_controllers = controllers_from_policy_row(
                    authority.policy_controllers[policy_record],
                    num_players=num_players,
                )
                policy_frame = int(authority.frame_ids[policy_record])
                force_previous_controller(
                    agent,
                    [policy_controllers[1], policy_controllers[2]],
                    np.array(
                        [
                            policy_frame < analyzed_control_frame
                            if player == args.analyzed_player
                            else policy_frame < defender_control_frame
                            for player in range(num_players)
                        ],
                        dtype=np.bool_,
                    ),
                )
                outputs = agent.step(games, needs_reset)
                needs_reset[:] = False
            timings["warmupSeconds"] = time.perf_counter() - warm_started
            if outputs is None:
                raise RuntimeError("Phillip warmup produced no output")

            last_controllers = controllers_from_policy_row(
                authority.policy_controllers[target], num_players=num_players
            )
            rollout_started = time.perf_counter()
            current_record = target
            for step in range(args.rollout_frames):
                decoded = decoded_controllers(agent, outputs)
                next_record = min(current_record + 1, len(authority.frames) - 1)
                next_frame = int(authority.frame_ids[next_record])
                analyzed_active = next_frame >= analyzed_control_frame
                defender_active = next_frame >= defender_control_frame

                replay_controllers = controllers_from_policy_row(
                    authority.policy_controllers[next_record],
                    num_players=num_players,
                )
                applied_controllers = dict(replay_controllers)
                if analyzed_active:
                    applied_controllers[args.analyzed_player + 1] = decoded[
                        args.analyzed_player
                    ]
                if defender_active:
                    applied_controllers[defender + 1] = decoded[defender]

                if not analyzed_active and not defender_active:
                    if env.t == env.length:
                        env.reset_cursor()
                    env.step_replay(authority.frames[next_record : next_record + 1])
                else:
                    inputs = np.zeros(1, dtype=dtypes.input_dtype())
                    inputs["players"][0] = authority.frames[next_record]["input"][
                        "players"
                    ]
                    for player in range(num_players):
                        if (player == args.analyzed_player and analyzed_active) or (
                            player == defender and defender_active
                        ):
                            inputs["players"][0, player] = controller_to_input_player(
                                applied_controllers[player + 1]
                            )
                    if env.t == env.length:
                        env.reset_cursor()
                    env.raw_action_view[env.t] = inputs
                    env.step()

                if env.t == env.length:
                    env.reset_cursor()
                env.observe_viewpoints(np.array([0], dtype=np.uint8))
                trace.append(
                    {
                        "step": step,
                        "replayRecord": next_record,
                        "analyzedModelActive": analyzed_active,
                        "defenderModelActive": defender_active,
                        "state": _state_json(env.current_frame[0]),
                        "controllers": {
                            str(player): _controller_json(
                                applied_controllers[player + 1]
                            )
                            for player in range(num_players)
                        },
                    }
                )
                current_record = next_record
                last_controllers = applied_controllers
                games = _viewpoint_games(
                    env, last_controllers, num_players=num_players
                )
                animation_filter.filter(games, needs_reset)
                policy_record = min(
                    current_record + delay, len(authority.frames) - 1
                )
                policy_controllers = controllers_from_policy_row(
                    authority.policy_controllers[policy_record],
                    num_players=num_players,
                )
                policy_frame = int(authority.frame_ids[policy_record])
                force_previous_controller(
                    agent,
                    [policy_controllers[1], policy_controllers[2]],
                    np.array(
                        [
                            policy_frame < analyzed_control_frame
                            if player == args.analyzed_player
                            else policy_frame < defender_control_frame
                            for player in range(num_players)
                        ],
                        dtype=np.bool_,
                    ),
                )
                outputs = agent.step(games, needs_reset)
            timings["rolloutSeconds"] = time.perf_counter() - rollout_started
    finally:
        agent.stop()

    timings["totalSeconds"] = time.perf_counter() - started
    payload = {
        "format": "MSL_PHILLIP_CHECKPOINT_PROBE1",
        "replay": str(args.replay.resolve()),
        "takeoverFrame": args.takeover_frame,
        "analyzedPlayer": args.analyzed_player,
        "defenderPlayer": defender,
        "policyDelay": delay,
        "analyzedControlFrame": analyzed_control_frame,
        "defenderTakeoverFrame": defender_takeover_frame,
        "defenderControlFrame": defender_control_frame,
        "warmupFrames": args.warmup_frames,
        "rolloutFrames": args.rollout_frames,
        "timings": {key: round(value, 6) for key, value in timings.items()},
        "trace": trace,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in payload.items() if key != "trace"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
