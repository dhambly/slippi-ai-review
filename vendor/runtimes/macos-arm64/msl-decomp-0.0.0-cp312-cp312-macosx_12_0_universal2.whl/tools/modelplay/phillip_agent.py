from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np


def import_eval_lib(slippi_ai_root: str | Path, *, disable_gpus: bool = False):
    root = str(Path(slippi_ai_root))
    if root not in sys.path:
        sys.path.insert(0, root)
    from slippi_ai import eval_lib  # type: ignore

    if disable_gpus:
        eval_lib.disable_gpus()
    return eval_lib


def load_state(eval_lib: Any, model_path: str | Path):
    try:
        return eval_lib.load_state(path=str(model_path))
    except TypeError as exc:
        if "unexpected keyword argument" not in str(exc):
            raise
        return eval_lib.load_state({"path": str(model_path)})


def build_agent(
    eval_lib: Any,
    *,
    state: Any,
    batch_size: int,
    sample_temperature: float = 1.0,
):
    if sample_temperature < 0.5:
        raise ValueError("normal Phillip rollout temperature must be at least 0.5")
    return eval_lib.build_delayed_agent(
        state=state,
        console_delay=0,
        batch_size=int(batch_size),
        async_inference=False,
        name=None,
        sample_temperature=float(sample_temperature),
    )


def batch_games(games: list[object]):
    from slippi_ai import utils  # type: ignore

    return utils.batch_nest_nt(games)


def batch_controllers(controllers: list[object]):
    from slippi_ai import utils  # type: ignore

    return utils.batch_nest_nt(controllers)


def force_previous_controller(
    delayed_agent: Any, controllers: list[object], force_mask: np.ndarray
) -> bool:
    basic_agent = getattr(delayed_agent, "_agent", None)
    policy = getattr(delayed_agent, "policy", None)
    if basic_agent is None or policy is None or not hasattr(basic_agent, "_prev_controller"):
        return False
    force_mask = np.asarray(force_mask, dtype=np.bool_)
    if not bool(np.any(force_mask)):
        return True
    forced = policy.controller_head.controller_embedding.from_state(
        batch_controllers(controllers)
    )
    current = basic_agent._prev_controller

    def merge(current_value: object, forced_value: object):
        current_array = np.asarray(current_value)
        forced_array = np.asarray(forced_value)
        shape = (force_mask.shape[0],) + (1,) * max(0, forced_array.ndim - 1)
        return np.where(force_mask.reshape(shape), forced_array, current_array)

    basic_agent._prev_controller = _map_two(merge, current, forced)
    return True


def decoded_controllers(delayed_agent: Any, outputs: Any) -> list[object]:
    embedding = getattr(delayed_agent, "embed_controller", None)
    decoded = (
        embedding.decode(outputs.controller_state)
        if embedding is not None
        else delayed_agent.decode_controller(outputs.controller_state)
    )
    batch_size = int(np.asarray(decoded.shoulder).shape[0])
    return [_map_one(lambda value, i=i: value[i], decoded) for i in range(batch_size)]


class AnimationFilter:
    def __init__(self, batch_size: int, *, enabled: bool) -> None:
        from slippi_ai import observations  # type: ignore

        self.enabled = bool(enabled)
        self.tech_actions = np.asarray(observations.TECH_ACTIONS, dtype=np.uint16)
        self.mask_frames = int(observations.DEFAULT_TECH_MASK_WINDOW)
        self.previous_action = np.zeros(batch_size, dtype=np.uint16)
        self.count = np.zeros(batch_size, dtype=np.int16)

    def filter(self, game: Any, needs_reset: np.ndarray) -> None:
        if not self.enabled:
            return
        reset = np.asarray(needs_reset, dtype=np.bool_)
        self.previous_action[reset] = np.uint16(0)
        self.count[reset] = np.int16(0)
        action = np.asarray(game.p1.action, dtype=np.uint16)
        same = action == self.previous_action
        self.count = np.where(same, self.count + 1, 0).astype(np.int16)
        self.previous_action = action.copy()
        should_mask = np.isin(action, self.tech_actions) & (
            self.count < self.mask_frames
        )
        game.p1.action[...] = np.where(
            should_mask, self.tech_actions[0], action
        )


def _map_one(function, value):
    if isinstance(value, tuple) and hasattr(value, "_fields"):
        return type(value)(*(_map_one(function, child) for child in value))
    return function(value)


def _map_two(function, left, right):
    if isinstance(left, tuple) and hasattr(left, "_fields"):
        return type(left)(
            *(
                _map_two(function, left_child, right_child)
                for left_child, right_child in zip(left, right, strict=True)
            )
        )
    return function(left, right)
