from __future__ import annotations

import importlib
from collections.abc import Mapping

import numpy as np

from melee_sim import dtypes


STAGE_TO_LIBMELEE = {
    2: 8,
    3: 18,
    8: 6,
    28: 26,
    31: 24,
    32: 25,
}
BUTTON_BITS = {
    "A": 0x0100,
    "B": 0x0200,
    "X": 0x0400,
    "Y": 0x0800,
    "Z": 0x0010,
    "L": 0x0040,
    "R": 0x0020,
    "D_UP": 0x0008,
}


def _types():
    return importlib.import_module("slippi_ai.types")


def empty_controller():
    types = _types()
    return types.Controller(
        main_stick=types.Stick(np.float32(0.5), np.float32(0.5)),
        c_stick=types.Stick(np.float32(0.5), np.float32(0.5)),
        shoulder=np.float32(0.0),
        buttons=types.Buttons(
            **{name: np.bool_(False) for name in types.Buttons._fields}
        ),
    )


def controller_from_policy_player(player: np.void):
    types = _types()
    buttons = int(player["buttons"])
    return types.Controller(
        main_stick=types.Stick(
            np.float32(player["main_x"]), np.float32(player["main_y"])
        ),
        c_stick=types.Stick(
            np.float32(player["c_x"]), np.float32(player["c_y"])
        ),
        shoulder=np.float32(player["shoulder"]),
        buttons=types.Buttons(
            **{
                name: np.bool_(bool(buttons & BUTTON_BITS.get(name, 0)))
                for name in types.Buttons._fields
            }
        ),
    )


def controllers_from_policy_row(
    row: np.void, *, num_players: int
) -> dict[int, object]:
    return {
        player + 1: controller_from_policy_player(row["players"][player])
        for player in range(num_players)
    }


def _empty_nana():
    types = _types()
    return types.Nana(
        exists=np.bool_(False),
        percent=np.uint16(0),
        facing=np.bool_(False),
        x=np.float32(0.0),
        y=np.float32(0.0),
        action=np.uint16(0),
        invulnerable=np.bool_(False),
        character=np.uint8(0),
        jumps_left=np.uint8(0),
        shield_strength=np.float32(0.0),
        on_ground=np.bool_(False),
    )


def _empty_item():
    types = _types()
    return types.Item(
        exists=np.bool_(False),
        type=np.uint16(0),
        state=np.uint8(0),
        x=np.float32(0.0),
        y=np.float32(0.0),
    )


def _empty_player():
    types = _types()
    values = {
        "percent": np.uint16(0),
        "facing": np.bool_(False),
        "x": np.float32(0.0),
        "y": np.float32(0.0),
        "action": np.uint16(0),
        "invulnerable": np.bool_(False),
        "character": np.uint8(0),
        "jumps_left": np.uint8(0),
        "shield_strength": np.float32(0.0),
        "on_ground": np.bool_(False),
        "controller": empty_controller(),
        "nana": _empty_nana(),
        "is_dead": np.bool_(True),
        "stocks_left": np.uint8(0),
    }
    return types.Player(
        **{name: values[name] for name in types.Player._fields}
    )


def _player(slot: np.void, controllers: Mapping[int, object]):
    types = _types()
    if not bool(slot["present"]):
        return _empty_player()
    source = int(slot["source_player"])
    values = {
        "percent": np.uint16(max(0, min(999, int(float(slot["percent"]))))),
        "facing": np.bool_(bool(slot["facing"])),
        "x": np.float32(slot["pos_x"]),
        "y": np.float32(slot["pos_y"]),
        "action": np.uint16(slot["action_id"]),
        "invulnerable": np.bool_(bool(slot["invulnerable"])),
        "character": np.uint8(slot["char_id"]),
        "jumps_left": _libmelee_jumps_left(slot),
        "shield_strength": np.float32(slot["shield_hp"]),
        "on_ground": np.bool_(bool(slot["on_ground"])),
        "controller": controllers.get(source + 1, empty_controller()),
        "nana": _empty_nana(),
        "is_dead": np.bool_(int(slot["stocks"]) == 0),
        "stocks_left": np.uint8(slot["stocks"]),
    }
    return types.Player(
        **{name: values[name] for name in types.Player._fields}
    )


def game_from_observation(
    observation: np.void, controllers: Mapping[int, object]
):
    types = _types()
    slots = observation["slots"]
    self_player = _player(slots[0], controllers)
    allies = [slot for slot in slots[1:] if slot["present"] and slot["team_relation"] == 1]
    opponents = [
        slot for slot in slots[1:] if slot["present"] and slot["team_relation"] == 2
    ]

    items = {}
    for index, item in enumerate(_canonical_items(observation["items"])):
        name = f"item_{index}"
        if name not in types.Items._fields:
            continue
        items[name] = types.Item(
            exists=np.bool_(bool(item["exists"])),
            type=np.uint16(item["type"]),
            state=np.uint8(item["state"]),
            x=np.float32(item["pos_x"]),
            y=np.float32(item["pos_y"]),
        )
    for name in types.Items._fields:
        items.setdefault(name, _empty_item())

    def selected(rows: list[np.void], index: int):
        return _player(rows[index], controllers) if index < len(rows) else _empty_player()

    values = {
        "p0": self_player,
        "p1": selected(allies, 0),
        "p2": selected(opponents, 0),
        "p3": selected(opponents, 1),
        "stage": np.uint8(STAGE_TO_LIBMELEE.get(int(observation["stage_id"]), 0)),
        "randall_phase": np.float32(int(observation["frame_id"]) % 1200),
        "randall": types.Randall(
            x=np.float32(observation["stage"]["randall"]["x"]),
            y=np.float32(observation["stage"]["randall"]["y"]),
        ),
        "fod_platforms": types.FoDPlatforms(
            left=np.float32(observation["stage"]["fod_platforms"]["left"]),
            right=np.float32(observation["stage"]["fod_platforms"]["right"]),
        ),
        "items": types.Items(**items),
        "is_teams": np.bool_(bool(observation["is_teams"])),
    }
    if "p2" not in types.Game._fields:
        values["p1"] = selected(opponents, 0)
    return types.Game(**{name: values[name] for name in types.Game._fields})


def _libmelee_jumps_left(slot: np.void) -> np.uint8:
    """Convert MSL's total remaining jumps to libmelee's aerial-jump count."""
    raw = int(slot["jumps_left"])
    if not bool(slot["on_ground"]) and raw > 1:
        raw -= 1
    return np.uint8(max(raw, 0))


def _canonical_items(items: np.ndarray) -> np.ndarray:
    """Return stable policy-facing item order independent of allocator slots."""
    order = sorted(
        range(len(items)),
        key=lambda index: (
            -int(bool(items[index]["exists"])),
            -int(items[index]["type"]),
            index,
        ),
    )
    return items[np.asarray(order, dtype=np.intp)]


def controller_to_input_player(controller) -> np.void:
    output = np.zeros((), dtype=dtypes.input_player_dtype())
    buttons = 0
    for name, bit in BUTTON_BITS.items():
        if name in controller.buttons._fields and bool(getattr(controller.buttons, name)):
            buttons |= bit
    output["buttons"] = np.uint16(buttons)
    output["main_x"] = _axis_to_i8(controller.main_stick.x)
    output["main_y"] = _axis_to_i8(controller.main_stick.y)
    output["c_x"] = _axis_to_i8(controller.c_stick.x)
    output["c_y"] = _axis_to_i8(controller.c_stick.y)
    output["l"] = np.uint8(
        np.clip(np.rint(float(controller.shoulder) * 255.0), 0, 255)
    )
    return output


def controllers_to_input(
    controllers: Mapping[int, object], *, num_players: int
) -> np.ndarray:
    output = np.zeros(1, dtype=dtypes.input_dtype())
    for player in range(num_players):
        output["players"][0, player] = controller_to_input_player(
            controllers.get(player + 1, empty_controller())
        )
    return output


def _axis_to_i8(value: object) -> np.int8:
    return np.int8(np.clip(np.rint(float(value) * 160.0 - 80.0), -80, 80))
