"""Policy adapters for running external Melee agents on canonical MSL state."""
