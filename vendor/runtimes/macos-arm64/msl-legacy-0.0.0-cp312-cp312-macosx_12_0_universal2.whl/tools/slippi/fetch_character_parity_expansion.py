"""Fetch a diverse held-out ranked corpus for one character parity target.

The primary ranked-character corpus samples one Master-Master shard per character. This tool
adds independent shards without changing that established benchmark. Selection is deterministic
and round-robins legal-stage/opponent buckets so the retained games emphasize coverage rather
than simply taking another filename-hash prefix.
"""

from __future__ import annotations

import argparse
from collections import defaultdict, deque
from dataclasses import dataclass
import json
from pathlib import Path
import sys
import tarfile
import tempfile

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tools.extraction.char_registry import CHARS
from tools.slippi.fetch_ranked_character_coverage import (
    _extract_selected,
    _header_metadata,
    _retained_bytes,
    _stable_key,
)
from tools.slippi.fetch_ranked_falcon_corpus import DATASET_REPO, _download_shard


TARGETS = {
    "FOX": CHARS["fox"].external_id,
    "FALCO": CHARS["falco"].external_id,
    "MARTH": CHARS["marth"].external_id,
    "SHEIK": CHARS["sheik"].external_id,
    "FALCON": CHARS["falcon"].external_id,
    "GANONDORF": CHARS["ganon"].external_id,
    "JIGGLYPUFF": CHARS["puff"].external_id,
    "PIKACHU": CHARS["pikachu"].external_id,
    "SAMUS": CHARS["samus"].external_id,
    "PEACH": CHARS["peach"].external_id,
}

# The primary corpus uses a2 for Fox, Falco, Marth, Sheik, Jigglypuff, and Pikachu; a3 for Samus;
# a6 for Peach and Ganondorf; and Falcon's large corpus uses a5. These partitions are intentionally
# disjoint and remain Master-Master so expansion measures coverage, not skill-rank distribution
# drift. The registry calls Captain Falcon "falcon", while the dataset bucket is CPTFALCON.
DEFAULT_SHARDS = {
    target: tuple(
        f"{source_bucket}/{source_bucket}_master-master_{partition}.tar.gz"
        for partition in partitions
    )
    for target, source_bucket, partitions in (
        ("FOX", "FOX", ("a1", "a4", "a5")),
        ("FALCO", "FALCO", ("a1", "a4", "a5")),
        ("MARTH", "MARTH", ("a1", "a4", "a5")),
        ("SHEIK", "SHEIK", ("a1", "a4", "a5")),
        ("FALCON", "CPTFALCON", ("a1", "a3", "a4")),
        ("GANONDORF", "GANONDORF", ("a1", "a4", "a5")),
        ("JIGGLYPUFF", "JIGGLYPUFF", ("a1", "a4", "a5")),
        ("PIKACHU", "PIKACHU", ("a1", "a4", "a5")),
        ("SAMUS", "SAMUS", ("a1", "a4", "a5")),
        ("PEACH", "PEACH", ("a1", "a4", "a5")),
    )
}


@dataclass(frozen=True)
class Candidate:
    member_name: str
    ports: list[int]
    stage_id: int
    character_ids: dict[str, int]
    opponent_id: int


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _opponent_id(character_ids: dict[str, int], target_id: int) -> int | None:
    values = list(character_ids.values())
    if len(values) != 2 or target_id not in values:
        return None
    opponents = [value for value in values if value != target_id]
    return opponents[0] if opponents else target_id


def _scan_target_shard(
    archive: Path,
    *,
    shard: str,
    target_id: int,
    scratch: Path,
) -> list[Candidate]:
    candidates: list[Candidate] = []
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            if not member.isfile() or not member.name.lower().endswith(".slp"):
                continue
            handle = tar.extractfile(member)
            if handle is None:
                continue
            metadata = _header_metadata(handle.read(), scratch)
            if metadata is None:
                continue
            ports, stage_id, character_ids = metadata
            opponent_id = _opponent_id(character_ids, target_id)
            if opponent_id is None:
                continue
            candidates.append(
                Candidate(
                    member_name=member.name,
                    ports=ports,
                    stage_id=stage_id,
                    character_ids=character_ids,
                    opponent_id=opponent_id,
                )
            )
    candidates.sort(key=lambda candidate: _stable_key(shard, candidate.member_name))
    return candidates


def _select_diverse(candidates: list[Candidate], *, shard: str, target: int) -> list[Candidate]:
    grouped: dict[tuple[int, int], deque[Candidate]] = defaultdict(deque)
    for candidate in candidates:
        grouped[(candidate.stage_id, candidate.opponent_id)].append(candidate)
    for group in grouped.values():
        ordered = sorted(group, key=lambda candidate: _stable_key(shard, candidate.member_name))
        group.clear()
        group.extend(ordered)

    selected: list[Candidate] = []
    keys = sorted(grouped)
    while len(selected) < target:
        added = False
        for key in keys:
            if grouped[key]:
                selected.append(grouped[key].popleft())
                added = True
                if len(selected) == target:
                    break
        if not added:
            break
    return selected


def _manifest_path(output: Path, target: str) -> Path:
    return output / f"{target.lower()}_parity_expansion.json"


def _load_manifest(path: Path, target: str) -> tuple[list[dict[str, object]], set[str]]:
    if not path.exists():
        return [], set()
    data = json.loads(path.read_text(encoding="utf-8"))
    if str(data.get("target")) != target:
        raise RuntimeError(f"Manifest target mismatch in {path}")
    return list(data.get("replays", [])), set(data.get("completed_shards", []))


def _write_manifest(
    path: Path,
    *,
    target: str,
    per_shard: int,
    max_retained_gib: float,
    records: list[dict[str, object]],
    completed_shards: set[str],
) -> None:
    payload = {
        "name": f"{target.lower()}_parity_expansion",
        "notes": (
            "Deterministic held-out Master-Master corpus with round-robin legal-stage/opponent "
            "selection; disjoint from the primary ranked-character shard."
        ),
        "source": DATASET_REPO,
        "target": target,
        "target_external_id": TARGETS[target],
        "per_shard": per_shard,
        "max_retained_gib": max_retained_gib,
        "completed_shards": sorted(completed_shards),
        "replays": sorted(records, key=lambda record: str(record["replay"])),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as output_file:
        output_file.write(json.dumps(payload, indent=2) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", required=True, choices=sorted(TARGETS))
    parser.add_argument("--out", type=Path)
    parser.add_argument("--per-shard", type=int, default=300)
    parser.add_argument("--max-retained-gb", type=float, default=20.0)
    parser.add_argument("--shard", action="append", default=[], help="Dataset tarball path; repeat to override defaults.")
    parser.add_argument("--keep-archives", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.per_shard <= 0 or args.max_retained_gb <= 0:
        parser.error("--per-shard and --max-retained-gb must be positive")

    root = _repo_root()
    output = args.out or root / "datasets" / "slippi" / "character_parity_expansion" / args.target.lower()
    if not output.is_absolute():
        output = root / output
    shards = tuple(args.shard) if args.shard else DEFAULT_SHARDS[args.target]
    limit_bytes = int(args.max_retained_gb * 1024**3)
    manifest_path = _manifest_path(output, args.target)
    records, completed_shards = _load_manifest(manifest_path, args.target)

    missing = [record["replay"] for record in records if not (root / str(record["replay"])).exists()]
    if missing:
        raise RuntimeError(f"Expansion manifest has {len(missing)} missing replay files; repair it before resuming")

    print(f"Target: {args.target} (external id {TARGETS[args.target]})")
    print(f"Dataset: {DATASET_REPO}")
    print(f"Output: {output}")
    print(f"Selection: {len(shards)} shards x up to {args.per_shard} games")
    for shard in shards:
        suffix = " (complete)" if shard in completed_shards else ""
        print(f"  {shard}{suffix}")
    if args.dry_run:
        return 0

    output.mkdir(parents=True, exist_ok=True)
    cache_dir = output / "_archives"
    with tempfile.TemporaryDirectory(prefix=f"msl_{args.target.lower()}_expansion_") as temp_dir:
        scratch = Path(temp_dir) / "header.slp"
        for shard in shards:
            if shard in completed_shards:
                continue
            remaining = limit_bytes - _retained_bytes(output)
            if remaining <= 0:
                raise RuntimeError(f"Retained-data cap reached before {shard}")
            print(f"Downloading {shard}...", flush=True)
            archive = _download_shard(DATASET_REPO, shard, cache_dir)
            print(f"Scanning {archive.name} for {args.target} games...", flush=True)
            candidates = _scan_target_shard(
                archive,
                shard=shard,
                target_id=TARGETS[args.target],
                scratch=scratch,
            )
            selected = _select_diverse(candidates, shard=shard, target=args.per_shard)
            print(
                f"Extracting {len(selected)}/{len(candidates)} eligible games across "
                f"{len({(row.stage_id, row.opponent_id) for row in selected})} stage/opponent buckets...",
                flush=True,
            )
            tuples = [
                (row.member_name, row.ports, row.stage_id, row.character_ids)
                for row in selected
            ]
            new_records = _extract_selected(
                archive,
                shard,
                args.target,
                tuples,
                output,
                root,
                remaining,
            )
            if len(new_records) != len(selected):
                raise RuntimeError(f"Extracted {len(new_records)}/{len(selected)} selected games from {shard}")
            for record in new_records:
                record["bucket"] = args.target
            records.extend(new_records)
            completed_shards.add(shard)
            _write_manifest(
                manifest_path,
                target=args.target,
                per_shard=args.per_shard,
                max_retained_gib=args.max_retained_gb,
                records=records,
                completed_shards=completed_shards,
            )
            if not args.keep_archives:
                archive.unlink(missing_ok=True)
            print(
                f"{shard}: retained {len(new_records)} games; "
                f"target corpus is {_retained_bytes(output) / 1024**3:.2f} GiB",
                flush=True,
            )

    print(f"Done: {len(records)} held-out {args.target} replays")
    print(f"Manifest: {manifest_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
