"""Fetch a reproducible modern Slippi validation corpus for Captain Falcon.

The ranked dataset is published as large gzip tarballs, not individual replay
objects.  This tool scans selected source shards, chooses games deterministically
by filename hash, and writes only the supported two-player legal-stage games to
the local-only ``datasets/`` tree.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tarfile
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote

from peppi_py import _read_slippi


DATASET_REPO = "erickfm/melee-ranked-replays"
DEFAULT_SHARDS = (
    "CPTFALCON/CPTFALCON_diamond-diamond_a1.tar.gz",
    "CPTFALCON/CPTFALCON_diamond-diamond_a2.tar.gz",
    "CPTFALCON/CPTFALCON_diamond-diamond_a3.tar.gz",
    "CPTFALCON/CPTFALCON_master-master_a5.tar.gz",
    "CPTFALCON/CPTFALCON_master-platinum_a1.tar.gz",
)
LEGAL_STAGES = {2, 3, 8, 28, 31, 32}
CHARACTER_NAMES = {
    0: "Fox",
    2: "Captain Falcon",
    7: "Sheik",
    18: "Marth",
    22: "Falco",
}
SUPPORTED_OPPONENT_IDS = frozenset({0, 7, 18, 22})


@dataclass(frozen=True)
class SelectedReplay:
    source_shard: str
    member_name: str
    replay: str
    ports: list[int]
    stage_id: int
    characters: dict[str, str]


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _normalise_output(root: Path, output: Path) -> Path:
    return output if output.is_absolute() else root / output


def _stable_key(shard: str, member_name: str) -> str:
    return hashlib.sha256(f"{shard}\0{member_name}".encode("utf-8")).hexdigest()


def _port_number(value: object) -> int | None:
    text = str(value)
    if len(text) == 2 and text.startswith("P") and text[1].isdigit():
        port = int(text[1])
        return port if 1 <= port <= 4 else None
    return None


def _header_metadata(raw: bytes, scratch: Path) -> tuple[list[int], int, dict[str, str]] | None:
    """Return the fields needed by a suite without retaining replay frames."""
    scratch.write_bytes(raw)
    try:
        game = _read_slippi(str(scratch), True)
        start: dict[str, Any] = game.start
    except Exception:
        return None

    stage_id = int(start.get("stage", -1))
    if stage_id not in LEGAL_STAGES or bool(start.get("is_teams", False)):
        return None

    human_players: list[tuple[int, int]] = []
    for player in start.get("players", []):
        if str(player.get("type")) != "Human":
            continue
        port = _port_number(player.get("port"))
        if port is None:
            return None
        human_players.append((port, int(player.get("character", -1))))
    if len(human_players) != 2:
        return None

    character_ids = {character for _, character in human_players}
    if 2 not in character_ids or len(character_ids) != 2:
        return None
    opponent_id = next(character for character in character_ids if character != 2)
    if opponent_id not in SUPPORTED_OPPONENT_IDS:
        return None

    ports = sorted(port for port, _ in human_players)
    characters = {
        str(port): CHARACTER_NAMES[character]
        for port, character in sorted(human_players)
    }
    return ports, stage_id, characters


def _iter_slp_members(archive: Path) -> Iterable[tarfile.TarInfo]:
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            if member.isfile() and member.name.lower().endswith(".slp"):
                yield member


def _scan_shard(archive: Path, shard: str, target: int, scratch: Path) -> list[tuple[str, list[int], int, dict[str, str]]]:
    selected: list[tuple[str, list[int], int, dict[str, str]]] = []
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            if not member.isfile() or not member.name.lower().endswith(".slp"):
                continue
            handle = tar.extractfile(member)
            if handle is None:
                continue
            metadata = _header_metadata(handle.read(), scratch)
            if metadata is None:
                continue
            ports, stage_id, characters = metadata
            selected.append((member.name, ports, stage_id, characters))

    selected.sort(key=lambda row: _stable_key(shard, row[0]))
    return selected[:target]


def _extract_selection(
    archive: Path,
    shard: str,
    selected: list[tuple[str, list[int], int, dict[str, str]]],
    output: Path,
    root: Path,
) -> list[SelectedReplay]:
    by_member = {member: (ports, stage_id, characters) for member, ports, stage_id, characters in selected}
    archive_tag = Path(shard).stem.removesuffix(".tar")
    records: list[SelectedReplay] = []
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            metadata = by_member.get(member.name)
            if metadata is None:
                continue
            handle = tar.extractfile(member)
            if handle is None:
                raise RuntimeError(f"Could not read selected member {member.name} from {archive}")
            output_name = f"{archive_tag}__{Path(member.name).name}"
            destination = output / "replays" / output_name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("wb") as stream:
                shutil.copyfileobj(handle, stream)
            ports, stage_id, characters = metadata
            try:
                replay_path = destination.relative_to(root).as_posix()
            except ValueError:
                replay_path = str(destination)
            records.append(
                SelectedReplay(
                    source_shard=shard,
                    member_name=member.name,
                    replay=replay_path,
                    ports=ports,
                    stage_id=stage_id,
                    characters=characters,
                )
            )
    if len(records) != len(selected):
        raise RuntimeError(f"Expected {len(selected)} selected replays from {shard}, extracted {len(records)}")
    return records


def _download_shard(repo_id: str, shard: str, cache_dir: Path) -> Path:
    try:
        import lz4.frame
        import requests
    except ImportError as exc:
        raise RuntimeError(
            "This tool needs lz4 and requests. Install them with `python -m pip install lz4 requests`."
        ) from exc

    destination = cache_dir / shard
    if destination.exists() and destination.stat().st_size > 0:
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".partial")
    partial.unlink(missing_ok=True)

    nonce = str(time.time_ns())
    resolve_url = (
        f"https://huggingface.co/datasets/{repo_id}/resolve/main/"
        f"{quote(shard, safe='/')}?download=true&cachebust={nonce}"
    )
    request_headers = {"Cache-Control": "no-cache"}
    resolve = requests.get(resolve_url, headers=request_headers, allow_redirects=False, timeout=60)
    resolve.raise_for_status()
    file_hash = resolve.headers.get("x-xet-hash")
    commit = resolve.headers.get("x-repo-commit")
    expected_size = int(resolve.headers.get("x-linked-size", "0"))
    if not file_hash or not commit or expected_size <= 0:
        raise RuntimeError(f"{shard} did not return Xet reconstruction metadata")

    reconstruction: dict[str, Any] | None = None
    for attempt in range(3):
        refresh = f"cachebust={time.time_ns()}&attempt={attempt}"
        token_response = requests.get(
            f"https://huggingface.co/api/datasets/{repo_id}/xet-read-token/{commit}?{refresh}",
            headers=request_headers,
            timeout=60,
        )
        token_response.raise_for_status()
        token = token_response.json()
        headers = {"Authorization": f"Bearer {token['accessToken']}", "X-Xet-Cas-Uid": "public", **request_headers}
        reconstruction_response = requests.get(
            f"{token['casUrl']}/v2/reconstructions/{file_hash}?{refresh}",
            headers=headers,
            timeout=60,
        )
        if reconstruction_response.status_code != 401:
            reconstruction_response.raise_for_status()
            reconstruction = reconstruction_response.json()
            break
        time.sleep(1 + attempt)
    if reconstruction is None:
        raise RuntimeError(f"Xet reconstruction authorization repeatedly failed for {shard}")
    fetch_by_hash = reconstruction.get("xorbs") or reconstruction.get("fetch_info")
    if not isinstance(fetch_by_hash, dict):
        raise RuntimeError(f"{shard} has no Xet fetch information")

    def decompress_xorb(data: bytes) -> list[bytes]:
        chunks: list[bytes] = []
        offset = 0
        while offset < len(data):
            if offset + 8 > len(data):
                raise RuntimeError(f"Truncated Xet chunk header in {shard}")
            version = data[offset]
            compressed_size = int.from_bytes(data[offset + 1 : offset + 4], "little")
            compression = data[offset + 4]
            unpacked_size = int.from_bytes(data[offset + 5 : offset + 8], "little")
            offset += 8
            compressed = data[offset : offset + compressed_size]
            offset += compressed_size
            if version != 0 or len(compressed) != compressed_size:
                raise RuntimeError(f"Invalid Xet chunk in {shard}")
            if compression == 0:
                unpacked = compressed
            elif compression in (1, 2):
                unpacked = lz4.frame.decompress(compressed)
            else:
                raise RuntimeError(f"Unsupported Xet compression {compression} in {shard}")
            if len(unpacked) != unpacked_size:
                raise RuntimeError(f"Invalid Xet decompressed chunk length in {shard}")
            if compression == 2:
                group_sizes = [unpacked_size // 4 + (1 if index < unpacked_size % 4 else 0) for index in range(4)]
                group_starts = [0]
                for group_size in group_sizes[:-1]:
                    group_starts.append(group_starts[-1] + group_size)
                unpacked = bytes(unpacked[group_starts[index % 4] + index // 4] for index in range(unpacked_size))
            chunks.append(unpacked)
        return chunks

    with partial.open("wb") as stream:
        for term in reconstruction["terms"]:
            required = term["range"]
            entries = fetch_by_hash[term["hash"]]
            match = None
            for entry in entries:
                for item in entry.get("ranges", [entry]):
                    chunk_range = item.get("chunks") or item.get("range")
                    if (
                        chunk_range["start"] <= required["start"]
                        and chunk_range["end"] >= required["end"]
                    ):
                        match = (entry, item, chunk_range)
                        break
                if match is not None:
                    break
            if match is None:
                raise RuntimeError(f"No Xet fetch range covers a reconstruction term in {shard}")
            entry, item, chunk_range = match
            byte_range = item.get("bytes") or item.get("url_range")
            response = requests.get(
                entry["url"],
                headers={"Range": f"bytes={byte_range['start']}-{byte_range['end']}"},
                timeout=120,
            )
            response.raise_for_status()
            all_chunks = decompress_xorb(response.content)
            start = required["start"] - chunk_range["start"]
            end = required["end"] - chunk_range["start"]
            payload = b"".join(all_chunks[start:end])
            if len(payload) != int(term["unpacked_length"]):
                raise RuntimeError(f"Invalid Xet reconstruction term length in {shard}")
            stream.write(payload)
    actual_size = partial.stat().st_size
    if actual_size != expected_size:
        partial.unlink(missing_ok=True)
        raise RuntimeError(
            f"Xet reconstruction size mismatch for {shard}: got {actual_size}, expected {expected_size}"
        )
    partial.replace(destination)
    return destination


def _write_manifest(output: Path, records: list[SelectedReplay], per_shard: int, repo_id: str) -> Path:
    manifest = {
        "name": "falcon_ranked_modern_large",
        "notes": (
            "Deterministic modern ranked Captain Falcon validation corpus. "
            f"Source: {repo_id}; selected by SHA-256 filename order from each source shard."
        ),
        "source": {"dataset": repo_id, "per_shard": per_shard},
        "ucf_enabled": True,
        "ucf_cardinals_1_0_enabled": False,
        "replays": [asdict(record) for record in sorted(records, key=lambda row: row.replay)],
    }
    path = output / "falcon_ranked_modern_large.json"
    path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return path


def _existing_manifest(path: Path) -> list[SelectedReplay] | None:
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    try:
        return [SelectedReplay(**record) for record in data["replays"]]
    except (KeyError, TypeError) as exc:
        raise RuntimeError(f"Malformed existing corpus manifest: {path}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("datasets/slippi/falcon_ranked_modern_large"))
    parser.add_argument("--per-shard", type=int, default=400)
    parser.add_argument("--shard", action="append", default=[], help="Dataset tarball path; repeat to override defaults.")
    parser.add_argument("--repo-id", default=DATASET_REPO)
    parser.add_argument("--keep-archives", action="store_true")
    parser.add_argument("--force", action="store_true", help="Rescan and replace the existing selection manifest.")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.per_shard <= 0:
        parser.error("--per-shard must be positive")

    root = _repo_root()
    output = _normalise_output(root, args.out)
    shards = tuple(args.shard) if args.shard else DEFAULT_SHARDS
    manifest_path = output / "falcon_ranked_modern_large.json"
    existing = _existing_manifest(manifest_path)
    if existing is not None and not args.force:
        missing = [record.replay for record in existing if not (root / record.replay).exists()]
        if not missing:
            print(f"Corpus already complete: {len(existing)} replays at {output}")
            print(f"Suite: {manifest_path}")
            return 0
        raise RuntimeError(f"Existing corpus manifest has {len(missing)} missing replay files; rerun with --force.")

    print(f"Dataset: {args.repo_id}")
    print(f"Output: {output}")
    print(f"Selection: {len(shards)} shards x {args.per_shard} games = {len(shards) * args.per_shard} target games")
    for shard in shards:
        print(f"  {shard}")
    if args.dry_run:
        return 0

    output.mkdir(parents=True, exist_ok=True)
    cache_dir = output / "_archives"
    records: list[SelectedReplay] = []
    with tempfile.TemporaryDirectory(prefix="msl_ranked_header_") as temp_dir:
        scratch = Path(temp_dir) / "header.slp"
        for shard in shards:
            print(f"Downloading {shard}...", flush=True)
            archive = _download_shard(args.repo_id, shard, cache_dir)
            print(f"Scanning {archive.name}...", flush=True)
            selected = _scan_shard(archive, shard, args.per_shard, scratch)
            if len(selected) < args.per_shard:
                print(
                    f"{shard} has {len(selected)} eligible supported games; retaining all of them.",
                    flush=True,
                )
            print(f"Extracting {len(selected)} selected games...", flush=True)
            records.extend(_extract_selection(archive, shard, selected, output, root))
            if not args.keep_archives:
                archive.unlink(missing_ok=True)

    manifest = _write_manifest(output, records, args.per_shard, args.repo_id)
    print(f"Done: {len(records)} replays")
    print(f"Suite: {manifest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
