"""Fully validate held-out character-parity replay corpora."""

from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import statistics
from typing import Any

import numpy as np
from peppi_py import _read_slippi

from tools.extraction.char_registry import CHARS


ROOT = Path(__file__).resolve().parents[2]
TARGETS = (
    "fox",
    "falco",
    "marth",
    "sheik",
    "falcon",
    "ganon",
    "puff",
    "pikachu",
    "samus",
    "peach",
)
CORPUS_NAMES = {
    "ganon": "ganondorf",
    "puff": "jigglypuff",
}
DEFAULT_PRIMARY_MANIFEST = ROOT / "datasets/slippi/ranked_character_coverage/ranked_character_coverage.json"
DEFAULT_COMPARISON_MANIFESTS = (
    ROOT / "datasets/slippi/falcon_ranked_modern_large/falcon_ranked_modern_large.json",
)
DISPLAY_NAMES = {
    "falcon": "Captain Falcon",
    "falco": "Falco",
    "fox": "Fox",
    "ganon": "Ganondorf",
    "marth": "Marth",
    "peach": "Peach",
    "pikachu": "Pikachu",
    "puff": "Jigglypuff",
    "samus": "Samus",
    "sheik": "Sheik",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as replay_file:
        while chunk := replay_file.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _target_ports(record: dict[str, Any], target_external_id: int) -> list[int]:
    return sorted(
        int(port)
        for port, character in record["character_ids"].items()
        if int(character) == target_external_id
    )


def _record_contains_target(record: dict[str, Any], target: str) -> bool:
    character_ids = record.get("character_ids")
    if isinstance(character_ids, dict):
        return any(int(value) == CHARS[target].external_id for value in character_ids.values())

    characters = record.get("characters")
    if isinstance(characters, dict):
        display_name = DISPLAY_NAMES[target]
        return any(str(value).casefold() == display_name.casefold() for value in characters.values())

    return False


def _comparison_replay_paths(manifest_paths: tuple[Path, ...], *, target: str) -> list[str]:
    paths: list[str] = []
    for manifest_path in manifest_paths:
        if not manifest_path.is_file():
            continue
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        paths.extend(
            str(ROOT / str(record["replay"]))
            for record in manifest.get("replays", [])
            if _record_contains_target(record, target)
        )
    return paths


def _audit_one(task: tuple[str, list[int], int]) -> dict[str, Any]:
    replay, target_ports, target_internal_id = task
    path = Path(replay)
    result: dict[str, Any] = {
        "replay": replay,
        "bytes": 0,
        "sha256": None,
        "frames": 0,
        "has_game_end": False,
        "error": None,
    }
    try:
        result["bytes"] = path.stat().st_size
        result["sha256"] = _sha256(path)
        game = _read_slippi(str(path), False)
        if game.frames is None:
            raise ValueError("replay has no frame stream")
        result["frames"] = len(game.frames)
        result["has_game_end"] = game.end is not None
        ports = game.frames.field("ports")
        for port in target_ports:
            post = ports.field(f"P{port}").field("leader").field("post")
            values = post.field("character").to_numpy(zero_copy_only=False)
            if isinstance(values, np.ma.MaskedArray):
                values = values.compressed()
            observed = set(np.unique(np.asarray(values, dtype=np.uint8)))
            if observed != {target_internal_id}:
                raise ValueError(
                    f"target port P{port} post-frame character ids {sorted(observed)} "
                    f"!= [{target_internal_id}]"
                )
    except Exception as exc:  # Keep auditing the rest of a large corpus.
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def _hash_path(path: str) -> tuple[str, str | None]:
    replay = Path(path)
    try:
        return path, _sha256(replay)
    except OSError:
        return path, None


def _comparison_hashes(
    manifest_paths: tuple[Path, ...],
    *,
    target: str,
    workers: int,
) -> set[str]:
    paths = _comparison_replay_paths(manifest_paths, target=target)
    with ProcessPoolExecutor(max_workers=workers) as executor:
        return {
            digest
            for _, digest in executor.map(_hash_path, paths, chunksize=8)
            if digest is not None
        }


def _counter_dict(counter: Counter[int]) -> dict[str, int]:
    return {str(key): counter[key] for key in sorted(counter)}


def _corpus_manifest_path(corpus_root: Path, target: str) -> Path:
    corpus_name = CORPUS_NAMES.get(target, target)
    return corpus_root / corpus_name / f"{corpus_name}_parity_expansion.json"


def _audit_target(
    target: str,
    *,
    corpus_root: Path,
    comparison_manifests: tuple[Path, ...],
    workers: int,
    short_frames: int,
) -> tuple[dict[str, Any], bool]:
    manifest_path = _corpus_manifest_path(corpus_root, target)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    records = list(manifest["replays"])
    target_info = CHARS[target]

    identities = [
        (str(record.get("source_shard", "")), str(record.get("member_name", "")))
        for record in records
    ]
    duplicate_identities = sorted(
        f"{shard}:{member}"
        for (shard, member), count in Counter(identities).items()
        if count > 1
    )
    missing_target_metadata = [
        str(record["replay"])
        for record in records
        if not _target_ports(record, target_info.external_id)
    ]
    tasks = [
        (
            str(ROOT / str(record["replay"])),
            _target_ports(record, target_info.external_id),
            target_info.internal_id,
        )
        for record in records
        if _target_ports(record, target_info.external_id)
    ]
    with ProcessPoolExecutor(max_workers=workers) as executor:
        audited = list(executor.map(_audit_one, tasks, chunksize=4))

    failures = [row for row in audited if row["error"] is not None]
    successful = [row for row in audited if row["error"] is None]
    hash_counts = Counter(str(row["sha256"]) for row in successful)
    duplicate_hashes = sorted(digest for digest, count in hash_counts.items() if count > 1)
    comparison_hashes = _comparison_hashes(comparison_manifests, target=target, workers=workers)
    primary_duplicates = sorted(
        row["replay"] for row in successful if str(row["sha256"]) in comparison_hashes
    )
    short_games = sorted(row["replay"] for row in successful if int(row["frames"]) < short_frames)
    missing_game_end = sorted(row["replay"] for row in successful if not row["has_game_end"])
    frame_counts = [int(row["frames"]) for row in successful]

    stage_counts = Counter(int(record["stage_id"]) for record in records)
    opponent_counts: Counter[int] = Counter()
    for record in records:
        characters = [int(value) for value in record["character_ids"].values()]
        opponents = [value for value in characters if value != target_info.external_id]
        opponent_counts[opponents[0] if opponents else target_info.external_id] += 1

    summary = {
        "target": target,
        "manifest": str(manifest_path),
        "records": len(records),
        "fully_parsed": len(successful),
        "bytes": sum(int(row["bytes"]) for row in audited),
        "completed_shards": list(manifest.get("completed_shards", [])),
        "stage_counts": _counter_dict(stage_counts),
        "opponent_counts": _counter_dict(opponent_counts),
        "frames": {
            "minimum": min(frame_counts) if frame_counts else None,
            "median": statistics.median(frame_counts) if frame_counts else None,
            "maximum": max(frame_counts) if frame_counts else None,
        },
        "short_threshold_frames": short_frames,
        "short_games": short_games,
        "missing_game_end": missing_game_end,
        "missing_target_metadata": missing_target_metadata,
        "duplicate_identities": duplicate_identities,
        "duplicate_content_hashes": duplicate_hashes,
        "duplicates_with_primary_corpus": primary_duplicates,
        "parse_or_target_failures": failures,
    }
    hard_failure = bool(
        failures
        or missing_target_metadata
        or duplicate_identities
        or duplicate_hashes
        or primary_duplicates
    )
    return summary, hard_failure


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--corpus-root",
        type=Path,
        default=ROOT / "datasets/slippi/character_parity_expansion",
    )
    parser.add_argument(
        "--primary-manifest",
        type=Path,
        default=DEFAULT_PRIMARY_MANIFEST,
    )
    parser.add_argument(
        "--comparison-manifest",
        action="append",
        type=Path,
        default=list(DEFAULT_COMPARISON_MANIFESTS),
        help="Additional corpus manifest to compare for target replay overlap; repeatable.",
    )
    parser.add_argument("--target", action="append", choices=TARGETS, default=[])
    parser.add_argument("--workers", type=int, default=min(8, os.cpu_count() or 1))
    parser.add_argument("--short-frames", type=int, default=600)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.workers <= 0 or args.short_frames <= 0:
        parser.error("--workers and --short-frames must be positive")

    corpus_root = args.corpus_root.resolve()
    comparison_manifests = tuple(
        dict.fromkeys(
            path.resolve() for path in (args.primary_manifest, *args.comparison_manifest)
        )
    )
    targets = tuple(args.target or TARGETS)
    summaries: dict[str, Any] = {}
    failed = False
    for target in targets:
        print(f"Auditing {target}...", flush=True)
        summary, target_failed = _audit_target(
            target,
            corpus_root=corpus_root,
            comparison_manifests=comparison_manifests,
            workers=args.workers,
            short_frames=args.short_frames,
        )
        summaries[target] = summary
        failed |= target_failed
        print(
            f"{target}: {summary['fully_parsed']}/{summary['records']} parsed, "
            f"{len(summary['short_games'])} short, "
            f"{len(summary['parse_or_target_failures'])} failures",
            flush=True,
        )

    payload = {
        "name": "character_parity_expansion_audit",
        "targets": summaries,
        "hard_failure": failed,
    }
    out_path = args.out or corpus_root / "audit.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8", newline="\n") as output_file:
        output_file.write(json.dumps(payload, indent=2) + "\n")
    print(f"Audit: {out_path}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
