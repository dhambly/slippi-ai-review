"""Build a capped, high-skill Slippi corpus for character-port validation.

This intentionally samples one small Master-Master shard per character rather
than mirroring the 1.43 TB ranked dataset. Source tarballs are deleted after
sampling, while a hard retained-data budget prevents the local corpus growing
without bound.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Any

import requests
from peppi_py import _read_slippi

# Support both ``python -m`` and the direct script invocation used by the
# project tooling.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tools.slippi.fetch_ranked_falcon_corpus import DATASET_REPO, LEGAL_STAGES, _download_shard


EXCLUDED_DEFAULT = {"CPTFALCON"}


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _stable_key(shard: str, member_name: str) -> str:
    return hashlib.sha256(f"{shard}\0{member_name}".encode("utf-8")).hexdigest()


def _port_number(value: object) -> int | None:
    text = str(value)
    if len(text) == 2 and text.startswith("P") and text[1].isdigit():
        port = int(text[1])
        return port if 1 <= port <= 4 else None
    return None


def _header_metadata(raw: bytes, scratch: Path) -> tuple[list[int], int, dict[str, int]] | None:
    scratch.write_bytes(raw)
    try:
        game = _read_slippi(str(scratch), True)
        start: dict[str, Any] = game.start
    except Exception:
        return None
    stage = int(start.get("stage", -1))
    if stage not in LEGAL_STAGES or bool(start.get("is_teams", False)):
        return None
    players: list[tuple[int, int]] = []
    for player in start.get("players", []):
        if str(player.get("type")) != "Human":
            continue
        port = _port_number(player.get("port"))
        if port is None:
            return None
        players.append((port, int(player.get("character", -1))))
    if len(players) != 2:
        return None
    return sorted(port for port, _ in players), stage, {str(port): char for port, char in sorted(players)}


def _source_shards(repo_id: str, excluded: set[str]) -> dict[str, str]:
    response = requests.get(
        f"https://huggingface.co/api/datasets/{repo_id}/tree/main",
        params={"recursive": "true", "expand": "false", "limit": 1000},
        timeout=60,
    )
    response.raise_for_status()
    by_character: dict[str, list[tuple[str, int]]] = {}
    for item in response.json():
        path = str(item.get("path", ""))
        parts = path.split("/")
        if len(parts) != 2 or not path.endswith(".tar.gz"):
            continue
        character = parts[0]
        if character in excluded:
            continue
        size = int(item.get("size", 0))
        if size <= 0:
            continue
        by_character.setdefault(character, []).append((path, size))

    selected: dict[str, str] = {}
    for character, candidates in by_character.items():
        masters = [candidate for candidate in candidates if "_master-master_" in candidate[0]]
        choice = min(masters or candidates, key=lambda candidate: candidate[1])
        selected[character] = choice[0]
    return dict(sorted(selected.items()))


def _scan_shard(archive: Path, shard: str, target: int, scratch: Path) -> list[tuple[str, list[int], int, dict[str, int]]]:
    candidates: list[tuple[str, list[int], int, dict[str, int]]] = []
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            if not member.isfile() or not member.name.lower().endswith(".slp"):
                continue
            handle = tar.extractfile(member)
            if handle is None:
                continue
            metadata = _header_metadata(handle.read(), scratch)
            if metadata is None:
                continue
            ports, stage, characters = metadata
            candidates.append((member.name, ports, stage, characters))
    candidates.sort(key=lambda record: _stable_key(shard, record[0]))
    return candidates[:target]


def _retained_bytes(output: Path) -> int:
    replay_dir = output / "replays"
    return sum(path.stat().st_size for path in replay_dir.rglob("*.slp")) if replay_dir.exists() else 0


def _extract_selected(
    archive: Path,
    shard: str,
    character: str,
    selected: list[tuple[str, list[int], int, dict[str, int]]],
    output: Path,
    root: Path,
    available_bytes: int,
) -> list[dict[str, object]]:
    wanted = {name: (ports, stage, characters) for name, ports, stage, characters in selected}
    archive_tag = Path(shard).stem.removesuffix(".tar")
    records: list[dict[str, object]] = []
    with tarfile.open(archive, mode="r:gz") as tar:
        for member in tar:
            metadata = wanted.get(member.name)
            if metadata is None:
                continue
            handle = tar.extractfile(member)
            if handle is None:
                raise RuntimeError(f"Could not read selected member {member.name} from {archive}")
            raw = handle.read()
            if len(raw) > available_bytes:
                break
            output_path = output / "replays" / character / f"{archive_tag}__{Path(member.name).name}"
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(raw)
            available_bytes -= len(raw)
            ports, stage, characters = metadata
            records.append(
                {
                    "source_shard": shard,
                    "member_name": member.name,
                    "replay": output_path.relative_to(root).as_posix(),
                    "ports": ports,
                    "stage_id": stage,
                    "character_ids": characters,
                }
            )
    return records


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("datasets/slippi/ranked_character_coverage"))
    parser.add_argument("--per-character", type=int, default=300)
    parser.add_argument("--max-retained-gb", type=float, default=65.0)
    parser.add_argument("--include", action="append", default=[], help="Only fetch this dataset character bucket; repeatable.")
    parser.add_argument("--exclude", action="append", default=[], help="Exclude this dataset character bucket; repeatable.")
    parser.add_argument("--keep-archives", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.per_character <= 0 or args.max_retained_gb <= 0:
        parser.error("--per-character and --max-retained-gb must be positive")

    root = _repo_root()
    output = args.out if args.out.is_absolute() else root / args.out
    excluded = set(args.exclude) or set(EXCLUDED_DEFAULT)
    sources = _source_shards(DATASET_REPO, excluded)
    if args.include:
        requested = set(args.include)
        sources = {character: shard for character, shard in sources.items() if character in requested}
        missing = requested - set(sources)
        if missing:
            parser.error(f"Unknown or excluded character buckets: {', '.join(sorted(missing))}")

    limit_bytes = int(args.max_retained_gb * 1024**3)
    print(f"Output: {output}")
    print(f"Coverage: {len(sources)} character buckets x up to {args.per_character} games")
    print(f"Retained cap: {args.max_retained_gb:g} GiB")
    for character, shard in sources.items():
        print(f"  {character}: {shard}")
    if args.dry_run:
        return 0

    output.mkdir(parents=True, exist_ok=True)
    cache_dir = output / "_archives"
    manifest_path = output / "ranked_character_coverage.json"
    existing: list[dict[str, object]] = []
    complete_characters: set[str] = set()
    if manifest_path.exists():
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        existing = list(data.get("replays", []))
        for record in existing:
            replay = root / str(record["replay"])
            if replay.exists():
                complete_characters.add(str(record.get("bucket", "")))

    records = existing[:]
    with tempfile.TemporaryDirectory(prefix="msl_ranked_coverage_") as temp_dir:
        scratch = Path(temp_dir) / "header.slp"
        for character, shard in sources.items():
            if character in complete_characters:
                print(f"{character}: already present; skipping", flush=True)
                continue
            remaining = limit_bytes - _retained_bytes(output)
            if remaining <= 0:
                print("Retained-data cap reached; stopping.", flush=True)
                break
            print(f"{character}: downloading {shard}", flush=True)
            archive = _download_shard(DATASET_REPO, shard, cache_dir)
            print(f"{character}: scanning legal two-player games", flush=True)
            selected = _scan_shard(archive, shard, args.per_character, scratch)
            print(f"{character}: extracting {len(selected)} games", flush=True)
            new_records = _extract_selected(archive, shard, character, selected, output, root, remaining)
            for record in new_records:
                record["bucket"] = character
            records.extend(new_records)
            manifest_path.write_text(
                json.dumps(
                    {
                        "name": "ranked_character_coverage",
                        "notes": "Capped high-skill source corpus for Melee Sim Light character-port validation.",
                        "source": DATASET_REPO,
                        "per_character": args.per_character,
                        "max_retained_gib": args.max_retained_gb,
                        "replays": records,
                    },
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )
            if not args.keep_archives:
                archive.unlink(missing_ok=True)
            print(
                f"{character}: retained {len(new_records)} games; "
                f"corpus is {_retained_bytes(output) / 1024**3:.2f} GiB",
                flush=True,
            )
    return 0


if __name__ == "__main__":
    sys.exit(main())
