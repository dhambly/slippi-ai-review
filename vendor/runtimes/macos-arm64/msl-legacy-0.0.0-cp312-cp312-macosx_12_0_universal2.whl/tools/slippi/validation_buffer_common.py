from __future__ import annotations
import functools
import json
import struct  # noqa: F401
import subprocess
import warnings
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace  # noqa: F401
from typing import Any
import numpy as np
import pyarrow as pa  # noqa: F401
from peppi_py import _read_slippi  # noqa: F401
from tools.eval.validation_dtypes import COMPARE_DTYPE, INPUT_DTYPE, SEED_DTYPE
from tools.slippi.action_state_tables import load_action_state_tables  # noqa: F401
from tools.slippi.hitstun import hitstun_u16_from_misc_as_and_state_flags3  # noqa: F401
from tools.slippi.item_article_data import item_article_kind_set, item_article_values_by_sim_char  # noqa: F401
from tools.extraction.known_data_artifacts import STAGE_PLATFORM_TRANSFORM_KIND_HEIGHT, dream_whispy_metadata, fountain_of_dreams_default_platform_heights, fountain_of_dreams_platform_motion_params, read_mslstg01_v7, stage_metadata_path_for_stage_id, yoshi_shyguy_metadata  # noqa: F401
from tools.slippi.motion_state_owners import read_callback_manifest, read_mslmso01_v1  # noqa: F401
from tools.slippi.rollback import finalized_frame_indices  # noqa: F401
from tools.slippi.slpz import replay_path_for_peppi  # noqa: F401
from tools.extraction.known_data_artifacts import read_mslftsc1_v1  # noqa: F401
from tools.slippi.suite_io import team_attack_on_from_start  # noqa: F401
MSL_MS_CLASS_ATTACK_AIR = 1 << 0
# Motion-state ownership bits that prove a Fighter_ChangeMotionState ground branch.  The
# public Slippi `on_ground` bit is a collision observation, not the source motion state's
# ground_or_air argument: DamageFlyRoll and other airborne callbacks can report floor contact.
_PEACH_FLOAT_GROUND_CLASS_BITS = (
    (1 << 5)  # landing-air owner
    | (1 << 11)  # landing collision owner
    | (1 << 12)  # landing-air collision owner
    | (1 << 16)  # grounded stage-object carry owner
    | (1 << 17)  # grounded attack owner
    | (1 << 25)  # grounded damage owner
    | (1 << 31)  # basic landing collision owner
)
_PEACH_FLOAT_GROUND_CLASS2_BITS = (
    (1 << 0)  # common grounded collision
    | (1 << 1)  # common grounded B108 collision
    | (1 << 3)  # common grounded B2DC collision
    | (1 << 4)  # common grounded B4B0 collision
    | (1 << 10)  # ground locomotion floor-loss owner
    | (1 << 12)  # landing-root floor snap owner
)
FOD_SKIP_ECB_VERTICAL_UNIT = 1.0
FOD_TRANSFORMED_PLATFORM_SKIP_LOOKUP_SLOP = 2.0 * FOD_SKIP_ECB_VERTICAL_UNIT
FOD_FLOOR_X_END_CLAMP = 0.1
FOD_FLOOR_Y_BIAS = 0.0001
FOD_STAGE_LINE_DX_EPSILON = 1e-06
_STAGE_KIND_BY_ID = {0: 'floor', 1: 'ceiling', 2: 'right_wall', 3: 'left_wall', 4: 'dynamic'}
_MATCH_FLOW_ACTION_IDS = {0, 1, 2, 4, 6, 7, 8, 9, 10, 12, 13, 322, 323, 324}

def _ascontiguousarray(arr: Any, dtype: Any=None) -> np.ndarray:
    if isinstance(arr, np.ndarray):
        want = None if dtype is None else np.dtype(dtype)
        if arr.flags.c_contiguous and (want is None or arr.dtype == want):
            return arr
    return np.ascontiguousarray(arr, dtype=dtype)

@functools.lru_cache(maxsize=64)
def _u8_lut_from_items(items: tuple[int, ...]) -> np.ndarray:
    lut = np.zeros(65536, dtype=np.uint8)
    for item in items:
        lut[int(item) & 65535] = np.uint8(1)
    return lut

@functools.lru_cache(maxsize=64)
def _u8_lut_from_pairs(pairs: tuple[tuple[int, int], ...]) -> np.ndarray:
    lut = np.zeros(65536, dtype=np.uint8)
    for key, value in pairs:
        lut[int(key) & 65535] = np.uint8(value)
    return lut

def _path_cache_key(path: Path) -> str:
    return str(path)

@functools.lru_cache(maxsize=None)
def _load_json_file_cached(path_text: str) -> Any:
    return json.loads(Path(path_text).read_text(encoding='utf-8'))

@functools.lru_cache(maxsize=None)
def _load_bytes_file_cached(path_text: str) -> bytes:
    return Path(path_text).read_bytes()

@functools.lru_cache(maxsize=None)
def _read_mslstg01_v7_cached(path_text: str):
    return read_mslstg01_v7(Path(path_text))

def _load_json_file(path: Path) -> Any:
    return _load_json_file_cached(_path_cache_key(path))

def _load_bytes_file(path: Path) -> bytes:
    return _load_bytes_file_cached(_path_cache_key(path))

def _read_mslstg01(path: Path):
    return _read_mslstg01_v7_cached(_path_cache_key(path))

POLICY_CONTROLLER_PLAYER_DTYPE = np.dtype(
    [
        ('buttons', '<u2'),
        ('main_x', '<f4'),
        ('main_y', '<f4'),
        ('c_x', '<f4'),
        ('c_y', '<f4'),
        ('shoulder', '<f4'),
    ],
    align=False,
)
POLICY_CONTROLLER_DTYPE = np.dtype(
    [('p', POLICY_CONTROLLER_PLAYER_DTYPE, (4,))],
    align=False,
)


@dataclass
class ValidationReplayBuffers:
    seed_t: np.ndarray
    prev_input_t: np.ndarray
    input_t: np.ndarray
    ref_t1: np.ndarray
    num_players: int
    policy_controller_t: np.ndarray | None = None

    @property
    def num_records(self) -> int:
        return int(self.seed_t.shape[0])

    def seed_u8(self) -> np.ndarray:
        return self.seed_t.view(np.uint8).reshape(self.num_records, self.seed_t.dtype.itemsize)

    def prev_input_u8(self) -> np.ndarray:
        return self.prev_input_t.view(np.uint8).reshape(self.num_records, self.prev_input_t.dtype.itemsize)

    def input_u8(self) -> np.ndarray:
        return self.input_t.view(np.uint8).reshape(self.num_records, self.input_t.dtype.itemsize)

    def ref_u8(self) -> np.ndarray:
        return self.ref_t1.view(np.uint8).reshape(self.num_records, self.ref_t1.dtype.itemsize)

class _SampleParts:

    def __init__(self, n: int) -> None:
        self.seed_t = np.zeros(n, dtype=SEED_DTYPE)
        self.prev_input_t = np.zeros(n, dtype=INPUT_DTYPE)
        self.input_t = np.zeros(n, dtype=INPUT_DTYPE)
        self.ref_t1 = np.zeros(n, dtype=COMPARE_DTYPE)
        # Simulator inputs intentionally preserve physical L/R triggers.  The
        # policy was trained on Parser's logical shoulder and processed-button
        # representation, so retain that separate observation stream too.
        self.policy_controller_t = np.zeros(n, dtype=POLICY_CONTROLLER_DTYPE)
        self.shape = (n,)

    def __getitem__(self, key: str) -> np.ndarray:
        if key == 'seed_t':
            return self.seed_t
        if key == 'prev_input_t':
            return self.prev_input_t
        if key == 'input_t':
            return self.input_t
        if key == 'ref_t1':
            return self.ref_t1
        raise KeyError(key)

    def as_buffers(self, *, num_players: int) -> ValidationReplayBuffers:
        return ValidationReplayBuffers(
            seed_t=self.seed_t,
            prev_input_t=self.prev_input_t,
            input_t=self.input_t,
            ref_t1=self.ref_t1,
            num_players=int(num_players),
            policy_controller_t=self.policy_controller_t,
        )

    def seed_u8(self) -> np.ndarray:
        return self.seed_t.view(np.uint8).reshape(self.shape[0], self.seed_t.dtype.itemsize)

    def prev_input_u8(self) -> np.ndarray:
        return self.prev_input_t.view(np.uint8).reshape(self.shape[0], self.prev_input_t.dtype.itemsize)

    def input_u8(self) -> np.ndarray:
        return self.input_t.view(np.uint8).reshape(self.shape[0], self.input_t.dtype.itemsize)

    def ref_u8(self) -> np.ndarray:
        return self.ref_t1.view(np.uint8).reshape(self.shape[0], self.ref_t1.dtype.itemsize)

@dataclass(frozen=True)
class _ManifestPreprocessTables:
    manifest_chars: tuple[tuple[int, str], ...]
    char_landing_air_lag_frames: dict[int, dict[str, int]]
    char_fallspecial_origin_lag: dict[int, dict[int, float]]
    char_fallspecial_origin_allow_interrupt: dict[int, dict[int, tuple[int, int]]]
    char_walk_divisors: dict[int, tuple[float, float, float]]
    char_walk_max: dict[int, float]
    char_run_scaling: dict[int, float]
    char_gr_friction: dict[int, float]
    char_gr_friction_lut: np.ndarray
    char_rebound_anim_numerator_frames: dict[int, float]
    rebound_numerator_lut: np.ndarray
    char_can_walljump: dict[int, bool]
    char_walljump_setup_x_delta_threshold: dict[int, float]
    active_shield_hit_lut: np.ndarray
    sheik_char_id: int
    zelda_char_id: int
    sheik_vanish_travel_frames: int
    sheik_vanish_ground_contact_min_frames: float
    sheik_chain_release_min_frames: int

def _env_damage_int(dmg: float) -> int:
    if float(dmg) == 0.0:
        return 0
    i = int(dmg)
    return i if i != 0 else 1

def _load_character_attrs(data_root: Path, name: str) -> dict[str, Any]:
    return _load_json_file(Path(data_root) / 'characters' / f'{name}.json')

def _load_moves_file(data_root: Path, name: str) -> dict[str, Any]:
    return _load_json_file(Path(data_root) / 'moves' / f'{name}.json')

def _load_common_data(data_root: Path=Path('data')) -> dict[str, Any]:
    return _load_json_file(Path(data_root) / 'common' / 'ft_common_data.json')

@functools.lru_cache(maxsize=1)
def _checkout_extraction_tree() -> str | None:
    root = Path(__file__).resolve().parents[2]
    try:
        proc = subprocess.run(
            ['git', '-C', str(root), 'rev-parse', 'HEAD:tools/extraction'],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    return proc.stdout.strip() or None

@functools.lru_cache(maxsize=8)
def _warn_extraction_tree_stale(
    data_root_key: str,
    recorded_tree: str | None,
    recorded_revision: str | None,
) -> None:
    current = _checkout_extraction_tree()
    if not recorded_tree or not current or recorded_tree == current:
        return
    warnings.warn(
        f'{data_root_key}/manifest.json was generated at git revision '
        f'{recorded_revision or "unknown"} whose committed tools/extraction differs '
        'from this checkout; extracted data may be stale - run `make build_data`.',
        RuntimeWarning,
        stacklevel=3,
    )

def manifest_registry_chars(data_root: Path) -> list[tuple[int, str]]:
    """(internal_id, name) for every char in the data manifest, registry-verified.

    Fails loudly when manifest.json names a char missing from the extraction registry:
    silently skipping is exactly the per-char no-op class the de-spacie pass eliminated
    (a skipped char gets default/empty entries in every per-char preprocessor map).
    """
    from tools.extraction.char_registry import CHARS as registry_chars
    manifest = json.loads((data_root / 'manifest.json').read_text())
    manifest_chars = manifest.get('chars') or ['fox', 'falco']
    _warn_extraction_tree_stale(
        str(data_root),
        manifest.get('extraction_tree'),
        manifest.get('git_revision'),
    )
    out: list[tuple[int, str]] = []
    for key in manifest_chars:
        info = registry_chars.get(str(key))
        if info is None:
            raise ValueError(f'data manifest names char {key!r} not present in tools/extraction/char_registry.py - add the registry row before preprocessing')
        out.append((info.internal_id, info.name))
    return out

def require_replay_chars_in_manifest(replay_char_ids: 'np.ndarray', manifest_chars: list[tuple[int, str]]) -> None:
    """Refuse to build validation buffers for a replay whose character is absent from the manifest.

    A manifest without the replay's character means every per-character preprocessing map
    silently resolved empty for it (landing lag, walk/run anim rates, friction, motion-state
    owners) - validation buffers would build "successfully" with subtly wrong seed lanes.
    """
    manifest_ids = {cid for cid, _key in manifest_chars}
    vals = np.asarray(replay_char_ids)
    if np.issubdtype(vals.dtype, np.floating):
        vals = vals[np.isfinite(vals)]
    missing = sorted(set((int(c) for c in np.unique(vals))) - manifest_ids)
    if missing:
        raise ValueError(f'replay uses char internal id(s) {missing} not in data manifest chars {sorted(manifest_ids)} - regenerate data with `make build_data` (registry-driven) or add the character to tools/extraction/char_registry.py first')

@functools.lru_cache(maxsize=None)
def _manifest_preprocess_tables(data_root_text: str) -> _ManifestPreprocessTables:
    data_root = Path(data_root_text)
    manifest_chars = tuple(manifest_registry_chars(data_root))
    char_landing_air_lag_frames: dict[int, dict[str, int]] = {}
    char_fallspecial_origin_lag: dict[int, dict[int, float]] = {}
    char_fallspecial_origin_allow_interrupt: dict[int, dict[int, tuple[int, int]]] = {}
    char_walk_divisors: dict[int, tuple[float, float, float]] = {}
    char_walk_max: dict[int, float] = {}
    char_run_scaling: dict[int, float] = {}
    char_gr_friction: dict[int, float] = {}
    char_rebound_anim_numerator_frames: dict[int, float] = {}
    char_can_walljump: dict[int, bool] = {}
    char_walljump_setup_x_delta_threshold: dict[int, float] = {}
    char_active_shield_hit_int_damage: dict[int, dict[int, dict[int, int]]] = {}
    sheik_char_id = -1
    zelda_char_id = -1
    sheik_vanish_travel_frames = 0
    sheik_vanish_ground_contact_min_frames = 0.0
    sheik_chain_release_min_frames = 0
    for cid, key in manifest_chars:
        attrs = _load_character_attrs(data_root, key)
        if key == 'sheik':
            sheik_char_id = int(cid)
            sheik_vanish_travel_frames = int(attrs.get('sheik_vanish_travel_frames', 0))
            sheik_vanish_ground_contact_min_frames = float(attrs.get('sheik_vanish_ground_contact_min_frames', 0.0))
            sheik_chain_release_min_frames = int(attrs.get('sheik_chain_release_min_frames', 0))
        elif key == 'zelda':
            zelda_char_id = int(cid)
        move_file = _load_moves_file(data_root, key)
        move_data = move_file['moves']
        special_move_data = move_file.get('specials_by_msid', {})
        char_landing_air_lag_frames[int(cid)] = {'airn': int(attrs['landing_airn_lag_frames']), 'airf': int(attrs['landing_airf_lag_frames']), 'airb': int(attrs['landing_airb_lag_frames']), 'airhi': int(attrs['landing_airhi_lag_frames']), 'airlw': int(attrs['landing_airlw_lag_frames'])}
        origin_lag: dict[int, float] = {}
        origin_allow_interrupt: dict[int, tuple[int, int]] = {}
        owners_tbl = read_mslmso01_v1(data_root / 'motion_state' / 'owners' / f'{key}.bin')
        if 'illusion_landing_lag_frames' in attrs or 'firefox_landing_lag_frames' in attrs:
            from tools.extraction.extract_motion_state_owners import FX_SPECIAL_KIND_VALUES
            illusion_kind = FX_SPECIAL_KIND_VALUES['SPECIAL_AIR_S_END']
            firefox_kinds = {FX_SPECIAL_KIND_VALUES['SPECIAL_AIR_HI'], FX_SPECIAL_KIND_VALUES['SPECIAL_HI_FALL'], FX_SPECIAL_KIND_VALUES['SPECIAL_HI_BOUND']}
            for a in range(len(owners_tbl.fx_special_kind)):
                k = int(owners_tbl.fx_special_kind[a])
                if k == illusion_kind and 'illusion_landing_lag_frames' in attrs:
                    origin_lag[a] = float(attrs['illusion_landing_lag_frames'])
                    origin_allow_interrupt[a] = (1, 0)
                elif k in firefox_kinds and 'firefox_landing_lag_frames' in attrs:
                    origin_lag[a] = float(attrs['firefox_landing_lag_frames'])
                    direct_kinds = {FX_SPECIAL_KIND_VALUES['SPECIAL_HI_FALL'], FX_SPECIAL_KIND_VALUES['SPECIAL_HI_BOUND']}
                    origin_allow_interrupt[a] = (1, 1 if k in direct_kinds else 0)
        # Up-B LandingFallSpecial origin classification. ftMs_SpecialHi/ftPk_SpecialHi expose the
        # lag under the shared 'specialhi_landing_lag_frames' attribute; Samus's Screw Attack owns
        # the same ftCo_LandingFallSpecial_Enter(..., allow_interrupt=false, x50) callsite under its
        # character-scoped 'samus_specialhi_landing_lag_frames' key. Both the direct
        # ftSs_SpecialHi_Coll entry and the ftCo_80096900(...,allow_interrupt=0,...) FallSpecial
        # relay pass allow_interrupt=false, so the origin lookup must mark these msids (0, 0) rather
        # than falling back to the generic FallSpecial default of interruptible.
        # refs/melee/src/melee/ft/chara/ftSamus/ftSs_SpecialHi.c::{ftSs_SpecialHi_Coll,
        #   ftSs_SpecialAirHi_Coll,ftSs_SpecialHi_Anim}
        # refs/melee/src/melee/ft/chara/ftCommon/ftCo_Landing.c::ftCo_LandingFallSpecial_Enter
        # refs/melee/src/melee/ft/chara/ftCommon/ftCo_FallSpecial.c::{ftCo_80096900,ftCo_80096D28}
        specialhi_lag_key = next(
            (k for k in ('specialhi_landing_lag_frames', 'samus_specialhi_landing_lag_frames')
             if k in attrs),
            None,
        )
        if specialhi_lag_key is not None:
            sm_path = data_root / 'special_msids' / f'{key}.json'
            if sm_path.exists():
                sm = _load_json_file(sm_path)
                up_msids = set()
                for up_key in ('up_air', 'up_ground'):
                    main = (sm.get(up_key) or {}).get('main') or {}
                    for v in main.values():
                        if isinstance(v, int):
                            up_msids.add(int(v))
                for a in range(len(owners_tbl.submotion_id)):
                    if int(owners_tbl.submotion_id[a]) in up_msids:
                        origin_lag[a] = float(attrs[specialhi_lag_key])
                        origin_allow_interrupt[a] = (0, 0)
        char_fallspecial_origin_lag[int(cid)] = origin_lag
        char_fallspecial_origin_allow_interrupt[int(cid)] = origin_allow_interrupt
        char_walk_divisors[int(cid)] = (float(attrs['slow_walk_max']), float(attrs['mid_walk_point']), float(attrs['fast_walk_min']))
        char_walk_max[int(cid)] = float(attrs['walk_max_vel'])
        char_run_scaling[int(cid)] = float(attrs['run_animation_scaling'])
        char_gr_friction[int(cid)] = float(attrs['gr_friction'])
        char_rebound_anim_numerator_frames[int(cid)] = float(attrs['rebound_anim_numerator_frames'])
        char_can_walljump[int(cid)] = bool(attrs.get('can_walljump', False))
        char_walljump_setup_x_delta_threshold[int(cid)] = float(attrs['walljump_setup_x_delta_threshold'])
        active_int_damage_by_anim: dict[int, dict[int, int]] = {}
        for move in [*move_data.values(), *special_move_data.values()]:
            submotion_id = int(move.get('submotion_id', -1))
            if submotion_id < 0:
                continue
            events = sorted(move.get('events', []), key=lambda ev: (int(ev.get('frame', 0)), ev.get('kind', '')))
            events_by_frame: dict[int, list[dict]] = {}
            max_frame = 0
            for ev in events:
                frame = int(ev.get('frame', 0))
                events_by_frame.setdefault(frame, []).append(ev)
                max_frame = max(max_frame, frame)
            active_by_hitbox: dict[int, int] = {}
            frame_damage: dict[int, int] = {}
            for frame in range(0, max_frame + 2):
                for ev in events_by_frame.get(frame, []):
                    kind = ev.get('kind')
                    if kind == 'create_hitbox':
                        hb = ev.get('data', {}).get('hitbox', {})
                        hb_id = int(hb.get('hitbox_id', 0))
                        active_by_hitbox[hb_id] = _env_damage_int(float(hb.get('damage', 0.0)))
                    elif kind == 'set_hitbox_damage':
                        hb_id = int(ev.get('data', {}).get('idx', 0))
                        if hb_id in active_by_hitbox:
                            active_by_hitbox[hb_id] = _env_damage_int(float(ev.get('data', {}).get('damage', 0.0)))
                    elif kind == 'remove_hitbox':
                        active_by_hitbox.pop(int(ev.get('data', {}).get('idx', 0)), None)
                    elif kind == 'clear_hitboxes':
                        active_by_hitbox.clear()
                frame_damage[frame] = max(active_by_hitbox.values(), default=0)
            active_int_damage_by_anim[submotion_id] = frame_damage
        char_active_shield_hit_int_damage[int(cid)] = active_int_damage_by_anim
    max_anim_idx = max((max(v.keys(), default=0) for v in char_active_shield_hit_int_damage.values()), default=0)
    max_active_frame = 0
    for by_anim in char_active_shield_hit_int_damage.values():
        for by_frame in by_anim.values():
            if by_frame:
                max_active_frame = max(max_active_frame, max(by_frame.keys()))
    active_shield_hit_lut = np.zeros((256, max_anim_idx + 1, max_active_frame + 1), dtype=np.uint16)
    for cid, by_anim in char_active_shield_hit_int_damage.items():
        for anim_idx, by_frame in by_anim.items():
            for frame, dmg in by_frame.items():
                active_shield_hit_lut[int(cid) & 255, int(anim_idx), int(frame)] = np.uint16(int(dmg))
    char_gr_friction_lut = np.zeros(256, dtype=np.float32)
    for cid, value in char_gr_friction.items():
        char_gr_friction_lut[int(cid) & 255] = np.float32(float(value))
    rebound_numerator_lut = np.zeros(256, dtype=np.float32)
    for cid, numerator in char_rebound_anim_numerator_frames.items():
        rebound_numerator_lut[int(cid) & 255] = np.float32(float(numerator))
    return _ManifestPreprocessTables(manifest_chars=manifest_chars, char_landing_air_lag_frames=char_landing_air_lag_frames, char_fallspecial_origin_lag=char_fallspecial_origin_lag, char_fallspecial_origin_allow_interrupt=char_fallspecial_origin_allow_interrupt, char_walk_divisors=char_walk_divisors, char_walk_max=char_walk_max, char_run_scaling=char_run_scaling, char_gr_friction=char_gr_friction, char_gr_friction_lut=char_gr_friction_lut, char_rebound_anim_numerator_frames=char_rebound_anim_numerator_frames, rebound_numerator_lut=rebound_numerator_lut, char_can_walljump=char_can_walljump, char_walljump_setup_x_delta_threshold=char_walljump_setup_x_delta_threshold, active_shield_hit_lut=active_shield_hit_lut, sheik_char_id=sheik_char_id, zelda_char_id=zelda_char_id, sheik_vanish_travel_frames=sheik_vanish_travel_frames, sheik_vanish_ground_contact_min_frames=sheik_vanish_ground_contact_min_frames, sheik_chain_release_min_frames=sheik_chain_release_min_frames)

@functools.lru_cache(maxsize=None)
def _load_u8_character_attr_lut_cached(data_root_text: str, key: str) -> np.ndarray:
    """Load a per-character uint8 attr from data/characters/<char>.json.

    Source owner: runtime-required character attrs are registry/manifest scoped. Keeping
    preprocessing LUTs registry-backed prevents newly added characters from silently inheriting
    zero-valued hidden lanes when the runtime already has extracted character data.
    """
    data_root = Path(data_root_text)
    lut = np.zeros(256, dtype=np.uint8)
    for char_id, name in manifest_registry_chars(data_root):
        attrs = _load_character_attrs(data_root, name)
        if key not in attrs:
            raise ValueError(f'missing required character attr {key!r} for {name}')
        value = int(attrs[key])
        if value < 0 or value > 255:
            raise ValueError(f'character attr {key!r} for {name} out of uint8 range: {value}')
        lut[np.uint8(char_id)] = np.uint8(value)
    return lut

def _load_u8_character_attr_lut(data_root: Path, key: str) -> np.ndarray:
    return _load_u8_character_attr_lut_cached(_path_cache_key(data_root), str(key))

@functools.lru_cache(maxsize=None)
def _load_f32_character_attr_lut_cached(data_root_text: str, key: str) -> np.ndarray:
    """Load a per-character float attr from data/characters/<char>.json."""
    data_root = Path(data_root_text)
    lut = np.zeros(256, dtype=np.float32)
    for char_id, name in manifest_registry_chars(data_root):
        attrs = _load_character_attrs(data_root, name)
        if key not in attrs:
            raise ValueError(f'missing required character attr {key!r} for {name}')
        lut[np.uint8(char_id)] = np.float32(float(attrs[key]))
    return lut

def _load_f32_character_attr_lut(data_root: Path, key: str) -> np.ndarray:
    return _load_f32_character_attr_lut_cached(_path_cache_key(data_root), str(key))

def _derive_common_fall_blend_seed(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, speed_air_x_self_f32: np.ndarray, facing_dir_f32: np.ndarray, air_drift_max_by_char: np.ndarray, threshold: float, lerp: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Derive prefix-causal mv.co.{fall,fallaerial,fallspecial}.x4/smid seed lanes."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_common_fall_blend_seed is required; run `make build`') from exc
    return msl_binding.derive_common_fall_blend_seed(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(speed_air_x_self_f32, dtype=np.float32), _ascontiguousarray(facing_dir_f32, dtype=np.float32), _ascontiguousarray(air_drift_max_by_char, dtype=np.float32), float(threshold), float(lerp))

def _derive_pikachu_quick_attack_seed_lanes(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, action_frame_i16: np.ndarray, hitlag_u16: np.ndarray, speed_air_x_self_f32: np.ndarray, speed_ground_x_self_f32: np.ndarray, speed_y_self_f32: np.ndarray, pikachu_internal_id: int | None, zip_frames: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Derive prefix-causal Quick Attack cmd0/x4/x8/x10 seed lanes."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_pikachu_quick_attack_seed_lanes is required; run `make build`') from exc
    pikachu_id = -1 if pikachu_internal_id is None else int(pikachu_internal_id)
    return msl_binding.derive_pikachu_quick_attack_seed_lanes(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(action_frame_i16, dtype=np.int16), _ascontiguousarray(hitlag_u16, dtype=np.uint16), _ascontiguousarray(speed_air_x_self_f32, dtype=np.float32), _ascontiguousarray(speed_ground_x_self_f32, dtype=np.float32), _ascontiguousarray(speed_y_self_f32, dtype=np.float32), pikachu_id, int(zip_frames))

def _derive_pikachu_skull_bash_charge_seed(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, hitlag_u16: np.ndarray, pikachu_internal_id: int | None) -> tuple[np.ndarray, np.ndarray]:
    """Derive prefix-causal Skull Bash `mv.pk.unk3.x0` and provenance lanes."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_pikachu_skull_bash_charge_seed is required; run `make build`') from exc
    pikachu_id = -1 if pikachu_internal_id is None else int(pikachu_internal_id)
    return msl_binding.derive_pikachu_skull_bash_charge_seed(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(hitlag_u16, dtype=np.uint16), pikachu_id)

def _derive_peach_float_ground_reset_u8(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, on_ground_u8: np.ndarray, peach_internal_id: int | None, data_root: Path) -> np.ndarray:
    """Return causal Peach ground-entry reset rows for the float availability lane.

    `on_ground` is intentionally only a candidate.  The source resets `fv.pe.has_float` from
    Fighter_ChangeMotionState's grounded branch, while an airborne DamageFly callback can still
    publish a floor contact.  Generated MotionState owner bits let us distinguish those cases.
    """
    reset = np.zeros_like(on_ground_u8, dtype=np.uint8)
    if peach_internal_id is None:
        return reset
    owners = read_mslmso01_v1(Path(data_root) / 'motion_state' / 'owners' / 'peach.bin')
    action = np.asarray(action_id_u16, dtype=np.uint16)
    grounded_owner = np.zeros(action.shape, dtype=np.uint8)
    valid = action < np.uint16(len(owners.class_bits))
    grounded_owner[valid] = (
        ((owners.class_bits[action[valid]] & np.uint32(_PEACH_FLOAT_GROUND_CLASS_BITS)) != 0)
        | ((owners.class2_bits[action[valid]] & np.uint32(_PEACH_FLOAT_GROUND_CLASS2_BITS)) != 0)
    ).astype(np.uint8)
    char_id = np.asarray(char_id_u8, dtype=np.uint8)
    on_ground = np.asarray(on_ground_u8, dtype=np.uint8)
    grounded = (
        (char_id == np.uint8(peach_internal_id))
        & (on_ground != 0)
        & (grounded_owner != 0)
    )
    # Fighter_ChangeMotionState restores Peach's float on grounded entry, not on every
    # frame spent in the same grounded motion. Keep the reset lane transition-causal so
    # a later Fall row cannot regain a float just because the replay still says grounded.
    entered_grounded_motion = np.zeros(action.shape, dtype=bool)
    if action.shape[0] != 0:
        entered_grounded_motion[0] = True
    if action.shape[0] > 1:
        # CliffEscape can hand off to GuardOn while Slippi already publishes a floor contact, but
        # that ledge recovery path does not run the ordinary grounded Fighter_ChangeMotionState
        # reset for Peach's float latch. Keep this exception narrow; ordinary Landing/Wait and
        # grounded action transitions still restore availability.
        cliff_escape_guard_handoff = (action[:-1] == np.uint16(259)) & (action[1:] == np.uint16(178))
        cliff_escape_recovery = np.zeros(action.shape, dtype=bool)
        for row in range(1, action.shape[0]):
            entered_guard = cliff_escape_guard_handoff[row - 1]
            continued_guard_recovery = (
                cliff_escape_recovery[row - 1]
                & (action[row - 1] == np.uint16(178))
                & ((action[row] == np.uint16(178)) | (action[row] == np.uint16(235)))
            )
            cliff_escape_recovery[row] = entered_guard | continued_guard_recovery
        entered_grounded_motion[1:] = (
            (action[1:] != action[:-1])
            | (grounded_owner[1:] == 0)
            | (grounded_owner[:-1] == 0)
            | (char_id[1:] != char_id[:-1])
        ) & ~cliff_escape_recovery[1:]
    reset[:] = (grounded & entered_grounded_motion).astype(np.uint8)
    return reset

def _derive_peach_float_seed_lanes(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, stocks_u8: np.ndarray, hitlag_u16: np.ndarray, on_ground_u8: np.ndarray, peach_internal_id: int | None, duration_frames: int, ground_reset_u8: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Derive prefix-causal Peach `fv.pe.has_float` and `mv.pe.float_.x0` lanes."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_peach_float_seed_lanes is required; run `make build`') from exc
    peach_id = -1 if peach_internal_id is None else int(peach_internal_id)
    reset = on_ground_u8 if ground_reset_u8 is None else ground_reset_u8
    return msl_binding.derive_peach_float_seed_lanes(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(stocks_u8, dtype=np.uint8), _ascontiguousarray(hitlag_u16, dtype=np.uint16), _ascontiguousarray(reset, dtype=np.uint8), peach_id, int(duration_frames))

def _apply_peach_float_input_consumption(*, available_u8: np.ndarray, timer_u16: np.ndarray, char_id_u8: np.ndarray, action_id_u16: np.ndarray, ref_action_id_u16: np.ndarray, stocks_u8: np.ndarray, hitlag_u16: np.ndarray, buttons_u16: np.ndarray, main_y_i8: np.ndarray, ground_reset_u8: np.ndarray, peach_internal_id: int | None, duration_frames: int, fastfall_stick_threshold: float) -> tuple[np.ndarray, np.ndarray]:
    """Apply hidden Peach Float consumption that SLP cannot serialize.

    A Float entered by JumpAerial/Fall IASA can be replaced by DamageFly during the same frame's
    collision callback. In that case the visible action never shows 341, but `has_float` is still
    cleared. The native action-only derivation cannot see that callback ordering, so use the
    recorded current-frame raw down+X/Y input together with the next recorded damage action as the
    narrow causal witness and carry the consumed state until a grounded motion reset or stock
    change. The reference action is required so ordinary stage contacts and visible Float starts
    remain on the normal path.
    """
    out_available = np.asarray(available_u8, dtype=np.uint8).copy()
    out_timer = np.asarray(timer_u16, dtype=np.uint16).copy()
    chars = np.asarray(char_id_u8, dtype=np.uint8)
    actions = np.asarray(action_id_u16, dtype=np.uint16)
    ref_actions = np.asarray(ref_action_id_u16, dtype=np.uint16)
    stocks = np.asarray(stocks_u8, dtype=np.uint8)
    hitlag = np.asarray(hitlag_u16, dtype=np.uint16)
    buttons = np.asarray(buttons_u16, dtype=np.uint16)
    main_y = np.asarray(main_y_i8, dtype=np.int16)
    reset = np.asarray(ground_reset_u8, dtype=np.uint8)
    if peach_internal_id is None or actions.shape[0] < 1:
        return out_available, out_timer

    # ftPe_8011BA54 is called by the active JumpAerial/Fall IASA owner before combat. The SLP
    # input values are UCF-clamped to +/-80, matching stick_i8_to_unit in src/input_axis.h.
    float_start_actions = np.array([27, 28, 29, 30, 31, 32, 33, 34], dtype=np.uint16)
    damage_replacement_actions = np.array(
        [38, 84, 85, 86, 87, 88, 89, 90, 91], dtype=np.uint16
    )
    peach = np.uint8(peach_internal_id)
    down_xy = (main_y.astype(np.float32) / np.float32(80.0) <= -np.float32(fastfall_stick_threshold)) & ((buttons & np.uint16(1024 | 2048)) != 0)
    for player in range(actions.shape[1]):
        for frame in range(actions.shape[0]):
            if (chars[frame, player] != peach or actions[frame, player] not in float_start_actions or
                    hitlag[frame, player] != 0 or out_available[frame, player] == 0 or
                    not bool(down_xy[frame, player]) or
                    ref_actions[frame, player] not in damage_replacement_actions):
                continue
            if reset[frame, player] != 0:
                continue
            cursor = frame
            while cursor < actions.shape[0]:
                if (reset[cursor, player] != 0 or chars[cursor, player] != peach or
                        stocks[cursor, player] != stocks[frame, player]):
                    break
                out_available[cursor, player] = np.uint8(0)
                cursor += 1
    return out_available, out_timer

def _derive_peach_mechanic_seed_lanes(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, stocks_u8: np.ndarray, x673_u8: np.ndarray, peach_internal_id: int | None, bomber_threshold: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Derive Peach's f-smash row, Bomber phase, and Parasol-open origin."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_peach_mechanic_seed_lanes is required; run `make build`') from exc
    peach_id = -1 if peach_internal_id is None else int(peach_internal_id)
    return msl_binding.derive_peach_mechanic_seed_lanes(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(stocks_u8, dtype=np.uint8), _ascontiguousarray(x673_u8, dtype=np.uint8), peach_id, int(bomber_threshold))

def _derive_sheik_needle_seed_lanes(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, action_frame_i16: np.ndarray, chain_article_present_u8: np.ndarray, sheik_internal_id: int | None) -> tuple[np.ndarray, np.ndarray]:
    """Derive prefix-causal Sheik Needle `fv.sk.x0` count and End timer seed lanes.

    `chain_article_present_u8` is the prefix-visible per-player flag for a live Sheik Chain article
    (source `fv.sk.x8 != NULL`); the Side-B `ftSk_Init_80110198` take-damage callback that clears
    `fv.sk.x0` is installed during SpecialN, or during SpecialS only while that article exists.
    """
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_sheik_needle_seed_lanes is required; run `make build`') from exc
    sheik_id = -1 if sheik_internal_id is None else int(sheik_internal_id)
    return msl_binding.derive_sheik_needle_seed_lanes(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(action_frame_i16, dtype=np.int16), _ascontiguousarray(chain_article_present_u8, dtype=np.uint8), sheik_id)

def _derive_sheik_chain_seed_lanes(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray, buttons_u16: np.ndarray, hitlag_u16: np.ndarray, sheik_internal_id: int | None, b_mask: int, release_min_frames: int) -> tuple[np.ndarray, np.ndarray]:
    """Derive prefix-causal Sheik Chain `mv.sk.specials.x0/x4` seed lanes."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_sheik_chain_seed_lanes is required; run `make build`') from exc
    sheik_id = -1 if sheik_internal_id is None else int(sheik_internal_id)
    return msl_binding.derive_sheik_chain_seed_lanes(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(action_id_u16, dtype=np.uint16), _ascontiguousarray(buttons_u16, dtype=np.uint16), _ascontiguousarray(hitlag_u16, dtype=np.uint16), sheik_id, int(b_mask), int(release_min_frames))

def _derive_samus_specialhi_breverse_seed_lane(
    *,
    char_id_u8: np.ndarray,
    action_id_u16: np.ndarray,
    facing_u8: np.ndarray,
    stocks_u8: np.ndarray,
    samus_internal_id: int | None,
    ground_action: int,
    air_action: int,
) -> np.ndarray:
    """Reconstruct Samus Screw Attack's one-shot reversal latch from public history.

    `mv.ss.unk5.x0` is set only when SpecialHi IASA reverses facing and survives ground/air
    action swaps. A facing edge inside one contiguous 353/354 episode is therefore sufficient
    causal evidence; no future row or input-dependent replay gate is consulted.
    """
    char_arr = np.asarray(char_id_u8, dtype=np.uint8)
    action_arr = np.asarray(action_id_u16, dtype=np.uint16)
    facing_arr = np.asarray(facing_u8, dtype=np.uint8)
    stocks_arr = np.asarray(stocks_u8, dtype=np.uint8)
    latch = np.zeros(action_arr.shape, dtype=np.uint8)
    if samus_internal_id is None:
        return latch

    upb_actions = {int(ground_action), int(air_action)}
    for player in range(action_arr.shape[1]):
        episode_active = False
        episode_latched = False
        previous_facing = 0
        previous_stocks = 0
        for replay_frame in range(action_arr.shape[0]):
            is_upb = (
                int(char_arr[replay_frame, player]) == int(samus_internal_id)
                and int(action_arr[replay_frame, player]) in upb_actions
            )
            stocks = int(stocks_arr[replay_frame, player])
            continues = episode_active and is_upb and stocks == previous_stocks
            if not continues:
                episode_latched = False
            elif int(facing_arr[replay_frame, player]) != previous_facing:
                episode_latched = True

            if is_upb:
                latch[replay_frame, player] = np.uint8(episode_latched)
            episode_active = is_upb
            previous_facing = int(facing_arr[replay_frame, player])
            previous_stocks = stocks

    return latch

def _derive_samus_charge_seed_lanes(*, char_id_u8: np.ndarray, action_id_u16: np.ndarray,
                                    stocks_u8: np.ndarray, hitlag_u16: np.ndarray,
                                    items: np.ndarray,
                                    samus_internal_id: int | None, charge_kind: int,
                                    start_action: int,
                                    hold_action: int,
                                    level_period_frames: int,
                                    max_level: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Derive Samus Charge Hold's persistent level and counter from replay prefix history.

    `fv.ss.x2230` survives Hold cancels, while `mv.ss.unk3.x4` is reset by SpecialNStart. Neither
    field is serialized for a held Charge Shot. Scan only prior/current public rows, mirror
    Hold_Anim's `> period` increment, and use an owned fired Charge Shot as reset proof.
    """
    char_arr = np.asarray(char_id_u8, dtype=np.uint8)
    action_arr = np.asarray(action_id_u16, dtype=np.uint16)
    stocks_arr = np.asarray(stocks_u8, dtype=np.uint8)
    hitlag_arr = np.asarray(hitlag_u16, dtype=np.uint16)
    item_arr = np.asarray(items)
    valid = np.zeros(action_arr.shape, dtype=np.uint8)
    level = np.zeros(action_arr.shape, dtype=np.uint8)
    counter = np.zeros(action_arr.shape, dtype=np.uint8)
    if samus_internal_id is None or charge_kind <= 0 or level_period_frames < 0:
        return valid, level, counter

    for player in range(action_arr.shape[1]):
        persistent_level = 0
        hidden_counter = 0
        previous_action = -1
        previous_stocks = 0
        for frame in range(action_arr.shape[0]):
            is_samus = int(char_arr[frame, player]) == int(samus_internal_id)
            stocks = int(stocks_arr[frame, player])
            if not is_samus or stocks < previous_stocks:
                persistent_level = 0
                hidden_counter = 0

            # Hold_Anim precedes IASA, so the final Hold frame advances even when this public row
            # has already become Cancel, fire, or a roll.
            if (
                is_samus
                and stocks >= previous_stocks
                and previous_action == int(hold_action)
                and int(hitlag_arr[frame, player]) == 0
            ):
                hidden_counter += 1
                if hidden_counter > int(level_period_frames):
                    hidden_counter = 0
                    persistent_level = min(int(max_level), persistent_level + 1)

            action = int(action_arr[frame, player])
            if is_samus and action != int(hold_action) and previous_action != action:
                if action == int(start_action):
                    hidden_counter = 0

            owned_charge = (
                (item_arr[frame]["exists"] != 0)
                & (item_arr[frame]["type"] == np.uint16(charge_kind))
                & (item_arr[frame]["owner"] == np.int8(player))
            )
            fired_slots = np.flatnonzero(owned_charge & (item_arr[frame]["state"] != np.uint8(0)))
            if fired_slots.size != 0:
                persistent_level = 0
                hidden_counter = 0

            is_samus_hold = (
                is_samus and action == int(hold_action)
            )
            held = owned_charge & (item_arr[frame]["state"] == np.uint8(0))
            slots = np.flatnonzero(held)
            if not is_samus_hold or slots.size == 0:
                previous_action = action if is_samus else -1
                previous_stocks = stocks
                continue

            valid[frame, player] = np.uint8(1)
            level[frame, player] = np.uint8(persistent_level)
            counter[frame, player] = np.uint8(min(hidden_counter, 255))
            previous_action = action
            previous_stocks = stocks
    return valid, level, counter


def _derive_samus_tether_ecb_seed_lanes(
    *,
    char_id_u8: np.ndarray,
    action_id_u16: np.ndarray,
    animation_index_u32: np.ndarray,
    anim_frame_f32: np.ndarray,
    facing_u8: np.ndarray,
    stocks_u8: np.ndarray,
    samus_internal_id: int | None,
    aircatch_action: int,
    aircatch_hit_action: int,
    ecb_side_y_offset: float,
) -> tuple[np.ndarray, ...]:
    """Carry AirCatch's last live CollData ECB through its empty collision callback.

    `ftCo_800C3A14` copies the fighter's CollData when Grapple state 7 finishes. AirCatchHit has an
    empty collision callback, so that packet is the final source-action ECB sampled immediately
    before AirCatch admission. This scan uses only the replay prefix and leaves mid-action buffer
    starts invalid instead of inventing an ECB from AirCatch's absent animation table rows.
    """
    char_arr = np.asarray(char_id_u8, dtype=np.uint8)
    action_arr = np.asarray(action_id_u16, dtype=np.uint16)
    animation_arr = np.asarray(animation_index_u32, dtype=np.uint32)
    frame_arr = np.asarray(anim_frame_f32, dtype=np.float32)
    facing_arr = np.asarray(facing_u8, dtype=np.uint8)
    stocks_arr = np.asarray(stocks_u8, dtype=np.uint8)
    valid = np.zeros(action_arr.shape, dtype=np.uint8)
    bottom = np.zeros(action_arr.shape, dtype=np.float32)
    top = np.zeros(action_arr.shape, dtype=np.float32)
    left = np.zeros(action_arr.shape, dtype=np.float32)
    right = np.zeros(action_arr.shape, dtype=np.float32)
    side = np.zeros(action_arr.shape, dtype=np.float32)
    if samus_internal_id is None:
        return valid, bottom, top, left, right, side

    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError(
            "native msl_binding ECB queries are required; run `make build`"
        ) from exc

    tether_actions = {int(aircatch_action), int(aircatch_hit_action)}
    for player in range(action_arr.shape[1]):
        cached: tuple[float, float, float, float, float] | None = None
        previous_stocks = 0
        for replay_frame in range(action_arr.shape[0]):
            is_samus = int(char_arr[replay_frame, player]) == int(samus_internal_id)
            stocks = int(stocks_arr[replay_frame, player])
            action = int(action_arr[replay_frame, player])
            previous_action = (
                int(action_arr[replay_frame - 1, player]) if replay_frame > 0 else -1
            )
            if not is_samus or stocks < previous_stocks:
                cached = None

            entering_aircatch = (
                is_samus
                and action == int(aircatch_action)
                and previous_action not in tether_actions
                and replay_frame > 0
            )
            if entering_aircatch:
                source_frame = replay_frame - 1
                source_anim = int(animation_arr[source_frame, player])
                source_tick_f32 = float(frame_arr[source_frame, player])
                source_tick = max(0, int(np.floor(source_tick_f32))) if np.isfinite(source_tick_f32) else 0
                ext = msl_binding.ecb_extents_rel(
                    int(samus_internal_id), source_anim, source_tick
                )
                bottom_rel = float(
                    msl_binding.ecb_bottom_rel_y(
                        int(samus_internal_id), source_anim, source_tick
                    )
                )
                facing_dir = 1.0 if int(facing_arr[source_frame, player]) != 0 else -1.0
                left_rel = min(facing_dir * float(ext[0]), facing_dir * float(ext[1]))
                right_rel = max(facing_dir * float(ext[0]), facing_dir * float(ext[1]))
                top_rel = float(ext[3])
                side_rel = float(ecb_side_y_offset) + 0.5 * (bottom_rel + top_rel)
                values = (bottom_rel, top_rel, left_rel, right_rel, side_rel)
                cached = values if all(np.isfinite(value) for value in values) and any(
                    value != 0.0 for value in values[:4]
                ) else None

            if is_samus and action in tether_actions and cached is not None:
                valid[replay_frame, player] = np.uint8(1)
                bottom[replay_frame, player] = np.float32(cached[0])
                top[replay_frame, player] = np.float32(cached[1])
                left[replay_frame, player] = np.float32(cached[2])
                right[replay_frame, player] = np.float32(cached[3])
                side[replay_frame, player] = np.float32(cached[4])
            elif action not in tether_actions:
                cached = None
            previous_stocks = stocks

    return valid, bottom, top, left, right, side


def _derive_samus_grapple_seed_lanes(
    *,
    char_id_u8: np.ndarray,
    action_id_u16: np.ndarray,
    stocks_u8: np.ndarray,
    on_ground_u8: np.ndarray,
    pos_x_f32: np.ndarray,
    pos_y_f32: np.ndarray,
    fighter_scale_y_f32: np.ndarray,
    buttons_u16: np.ndarray,
    hitlag_u16: np.ndarray,
    items: np.ndarray,
    samus_internal_id: int | None,
    grapple_kind: int,
    catch_action: int,
    catch_dash_action: int,
    aircatch_action: int,
    aircatch_hit_action: int,
    catch_links: int,
    catch_dash_links: int,
    aircatch_links: int,
    segment_length: float,
    ground_retract_speed: float,
    air_retract_speed: float,
    alt_retract_speed: float,
    swing_frames: int,
    button_mask_a: int,
    button_mask_z: int,
    button_mask_l: int,
    button_mask_dpad_up: int,
    button_mask_dpad_down: int,
) -> tuple[np.ndarray, ...]:
    """Reconstruct Samus Grapple source-owned hidden state from causal public history.

    Item identity and state transitions own the compact article seed. Link activation mirrors the
    fixed-distance source solve, attachment is captured on the public transition to state 6, and
    the swing counter follows `mv.ss.grapple.x4`. No future replay row is inspected.
    """
    char_arr = np.asarray(char_id_u8, dtype=np.uint8)
    action_arr = np.asarray(action_id_u16, dtype=np.uint16)
    stocks_arr = np.asarray(stocks_u8, dtype=np.uint8)
    ground_arr = np.asarray(on_ground_u8, dtype=np.uint8)
    pos_x_arr = np.asarray(pos_x_f32, dtype=np.float32)
    pos_y_arr = np.asarray(pos_y_f32, dtype=np.float32)
    scale_arr = np.asarray(fighter_scale_y_f32, dtype=np.float32)
    buttons_arr = np.asarray(buttons_u16, dtype=np.uint16)
    hitlag_arr = np.asarray(hitlag_u16, dtype=np.uint16)
    item_arr = np.asarray(items)
    fighter_shape = action_arr.shape
    item_shape = item_arr.shape[:2]

    tether_used = np.zeros(fighter_shape, dtype=np.uint8)
    anim_tick = np.zeros(fighter_shape, dtype=np.uint8)
    input_phase = np.zeros(fighter_shape, dtype=np.uint8)
    seed_valid = np.zeros(item_shape, dtype=np.uint8)
    active_links = np.zeros(item_shape, dtype=np.uint8)
    mode = np.zeros(item_shape, dtype=np.uint8)
    retract_latch = np.zeros(item_shape, dtype=np.uint8)
    tip_wall_line = np.full(item_shape, -1, dtype=np.int16)
    swing_timer = np.zeros(item_shape, dtype=np.uint16)
    attach_valid = np.zeros(item_shape, dtype=np.uint8)
    attach_x = np.zeros(item_shape, dtype=np.float32)
    attach_y = np.zeros(item_shape, dtype=np.float32)

    if samus_internal_id is None or grapple_kind <= 0 or segment_length <= 0.0:
        return (
            tether_used,
            anim_tick,
            input_phase,
            seed_valid,
            active_links,
            mode,
            retract_latch,
            tip_wall_line,
            swing_timer,
            attach_valid,
            attach_x,
            attach_y,
        )

    owner_actions = {catch_action, catch_dash_action, aircatch_action}
    phase_by_player = np.zeros(fighter_shape[1], dtype=np.uint8)
    tether_by_player = np.zeros(fighter_shape[1], dtype=np.uint8)
    tick_by_player = np.zeros(fighter_shape[1], dtype=np.uint8)
    previous_action = np.full(fighter_shape[1], 0xFFFF, dtype=np.uint16)
    previous_char = np.full(fighter_shape[1], 0xFF, dtype=np.uint8)
    previous_buttons = np.zeros(fighter_shape[1], dtype=np.uint16)
    article_state: dict[tuple[int, int, int], dict[str, int | float]] = {}

    def effective_a_edge(buttons: int, previous: int) -> bool:
        pressed = buttons & ~previous
        return (pressed & (int(button_mask_a) | int(button_mask_z))) != 0

    def link_capacity(owner_action: int) -> int:
        if owner_action == catch_action:
            return catch_links
        if owner_action == catch_dash_action:
            return catch_dash_links
        return aircatch_links

    for frame in range(fighter_shape[0]):
        for player in range(fighter_shape[1]):
            is_samus = int(char_arr[frame, player]) == int(samus_internal_id)
            alive = int(stocks_arr[frame, player]) != 0
            if not is_samus or not alive or previous_char[player] != char_arr[frame, player]:
                phase_by_player[player] = 0
                tether_by_player[player] = 0
                tick_by_player[player] = 0
            action = int(action_arr[frame, player])
            if is_samus and alive:
                if int(ground_arr[frame, player]) != 0:
                    tether_by_player[player] = 0
                if action in (aircatch_action, aircatch_hit_action):
                    tether_by_player[player] = 1
                if action in owner_actions:
                    if int(previous_action[player]) != action:
                        tick_by_player[player] = 0
                    elif int(hitlag_arr[frame, player]) == 0 and tick_by_player[player] < 255:
                        tick_by_player[player] += 1
                else:
                    tick_by_player[player] = 0
                tether_used[frame, player] = tether_by_player[player]
                anim_tick[frame, player] = tick_by_player[player]
            previous_action[player] = np.uint16(action)
            previous_char[player] = char_arr[frame, player]

        live_for_player: list[list[tuple[int, tuple[int, int, int]]]] = [
            [] for _ in range(fighter_shape[1])
        ]
        for slot in range(item_shape[1]):
            item = item_arr[frame, slot]
            if int(item["exists"]) == 0 or int(item["type"]) != int(grapple_kind):
                continue
            owner = int(item["owner"])
            if owner < 0 or owner >= fighter_shape[1]:
                continue
            key = (owner, int(item["spawn_id"]), int(item["instance_id"]))
            live_for_player[owner].append((slot, key))
            source = article_state.get(key)
            new_article = source is None
            if source is None:
                source = {
                    "state": -1,
                    "active": 0,
                    "mode": 0,
                    "latch": 0,
                    "swing": 0,
                    "attach_valid": 0,
                    "attach_x": 0.0,
                    "attach_y": 0.0,
                }
                article_state[key] = source
                if int(phase_by_player[owner]) >= 4:
                    source["mode"] = 1 if int(ground_arr[frame, owner]) != 0 else 2
                else:
                    phase_by_player[owner] = 0

            state = int(item["state"])
            previous_item_state = int(source["state"])
            capacity = max(2, min(90, link_capacity(int(action_arr[frame, owner]))))
            scale = max(float(scale_arr[frame, owner]), 0.0001)
            source_segment = float(segment_length) * scale
            if state == 0:
                source["active"] = 0
            elif state in (1, 2, 6, 7):
                endpoint_x = (
                    float(source["attach_x"])
                    if int(source["attach_valid"]) != 0
                    else float(item["pos_x"])
                )
                endpoint_y = (
                    float(source["attach_y"])
                    if int(source["attach_valid"]) != 0
                    else float(item["pos_y"])
                )
                dx = endpoint_x - float(pos_x_arr[frame, owner])
                dy = endpoint_y - float(pos_y_arr[frame, owner])
                distance_links = max(1, int(np.ceil(np.hypot(dx, dy) / source_segment)))
                if state in (1, 2, 6):
                    source["active"] = max(int(source["active"]), distance_links)
                else:
                    source["active"] = distance_links
                source["active"] = min(capacity, int(source["active"]))
            elif state == 3:
                source["active"] = capacity
            elif state in (4, 5):
                if previous_item_state not in (4, 5):
                    source["active"] = max(1, int(source["active"]))
                speed = (
                    float(alt_retract_speed)
                    if state == 5
                    else (
                        float(ground_retract_speed)
                        if int(ground_arr[frame, owner]) != 0
                        else float(air_retract_speed)
                    )
                )
                consumed = max(1, int(np.floor(speed / source_segment)))
                source["active"] = max(0, int(source["active"]) - consumed)
                if state == 5 and int(source["active"]) == 0:
                    source["latch"] = 1

            if state == 6 and previous_item_state != 6:
                source["attach_valid"] = 1
                source["attach_x"] = float(item["pos_x"])
                source["attach_y"] = float(item["pos_y"])
            if (
                state in (1, 2, 3)
                and int(ground_arr[frame, owner]) != 0
                and int(source["mode"]) == 1
                and effective_a_edge(
                    int(buttons_arr[frame, owner]), int(previous_buttons[owner])
                )
            ):
                source["mode"] = 2
            if state == 8:
                source["active"] = capacity
                if previous_item_state != 8:
                    source["swing"] = max(0, min(0xFFFF, int(swing_frames)))
                elif int(source["swing"]) > 0:
                    held_l = (int(buttons_arr[frame, owner]) & int(button_mask_l)) != 0
                    if int(source["mode"]) == 0 or not held_l:
                        source["swing"] = int(source["swing"]) - 1
            else:
                source["swing"] = 0

            source["state"] = state
            seed_valid[frame, slot] = np.uint8(1)
            active_links[frame, slot] = np.uint8(min(255, int(source["active"])))
            mode[frame, slot] = np.uint8(min(2, int(source["mode"])))
            retract_latch[frame, slot] = np.uint8(int(source["latch"]) != 0)
            swing_timer[frame, slot] = np.uint16(int(source["swing"]))
            attach_valid[frame, slot] = np.uint8(int(source["attach_valid"]) != 0)
            attach_x[frame, slot] = np.float32(float(source["attach_x"]))
            attach_y[frame, slot] = np.float32(float(source["attach_y"]))

            if new_article and state > 0 and int(source["active"]) == 0:
                active_links[frame, slot] = np.uint8(1)

        for player, live in enumerate(live_for_player):
            if not live or int(char_arr[frame, player]) != int(samus_internal_id):
                input_phase[frame, player] = phase_by_player[player]
                previous_buttons[player] = buttons_arr[frame, player]
                continue
            for slot, key in live:
                if int(item_arr[frame, slot]["state"]) not in (0, 1):
                    continue
                phase = int(phase_by_player[player])
                held = int(buttons_arr[frame, player])
                if (
                    (phase == 0 and held & int(button_mask_dpad_up))
                    or (phase == 1 and held & int(button_mask_dpad_down))
                    or (phase == 2 and held & int(button_mask_dpad_up))
                    or (
                        phase == 3
                        and effective_a_edge(held, int(previous_buttons[player]))
                    )
                ):
                    phase_by_player[player] = np.uint8(min(4, phase + 1))
                break
            input_phase[frame, player] = phase_by_player[player]
            previous_buttons[player] = buttons_arr[frame, player]

    return (
        tether_used,
        anim_tick,
        input_phase,
        seed_valid,
        active_links,
        mode,
        retract_latch,
        tip_wall_line,
        swing_timer,
        attach_valid,
        attach_x,
        attach_y,
    )

def _derive_zelda_twin_state_flags_2218(*, char_id_u8: np.ndarray, state_flags_u8: np.ndarray, zelda_internal_id: int | None) -> np.ndarray:
    """Derive the hidden Zelda twin fp+0x2218 byte used by Sheik/Zelda transform handoff."""
    try:
        import msl_binding
    except ImportError as exc:
        raise RuntimeError('native msl_binding.derive_zelda_twin_state_flags_2218 is required; run `make build`') from exc
    zelda_id = -1 if zelda_internal_id is None else int(zelda_internal_id)
    return msl_binding.derive_zelda_twin_state_flags_2218(_ascontiguousarray(char_id_u8, dtype=np.uint8), _ascontiguousarray(state_flags_u8, dtype=np.uint8), zelda_id)

@dataclass(frozen=True)
class PortStatic:
    team_id: int
    char_id: int
    handicap: int

def _to_numpy(arr) -> np.ndarray:
    x = arr.to_numpy(zero_copy_only=False)
    if isinstance(x, np.ma.MaskedArray):
        x = x.filled(0)
    if isinstance(x, np.ndarray) and x.dtype.kind == 'f':
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return x
