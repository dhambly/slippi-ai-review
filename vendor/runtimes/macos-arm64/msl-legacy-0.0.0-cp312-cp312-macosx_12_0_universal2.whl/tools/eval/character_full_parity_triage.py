from __future__ import annotations

import argparse
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from tools.eval.character_mismatch_triage import _run_one_step
from tools.eval.one_step_report import DISCRETE_FIELDS, FLOAT_FIELDS
from tools.extraction.char_registry import CHARS
from tools.slippi.slpz import replay_path_for_peppi
from tools.slippi.suite_io import repo_root
from tools.slippi.validation_buffer_builder import build_validation_buffers_from_slp


FIGHTER_DISCRETE_FIELDS = tuple(
    field for field in DISCRETE_FIELDS if not field.startswith("item_")
)
FIGHTER_BOOKKEEPING_FIELDS = (
    "instance_hit_by",
    "instance_id",
    "last_attack_landed",
    "combo_count",
    "last_hit_by",
)
FIGHTER_GAMEPLAY_FIELDS = tuple(
    field for field in FIGHTER_DISCRETE_FIELDS if field not in FIGHTER_BOOKKEEPING_FIELDS
)
FIGHTER_FLOAT_FIELDS = tuple(field for field in FLOAT_FIELDS if not field.startswith("item_"))
ITEM_CORE_DISCRETE_FIELDS = ("exists", "type", "state", "owner", "instance_id")
ITEM_PAYLOAD_DISCRETE_FIELDS = (
    "attack_id",
    "attack_instance",
    "damage",
    "spawn_id",
    "misc0",
    "misc1",
    "misc2",
    "misc3",
)
ITEM_FLOAT_FIELDS = ("direction", "pos_x", "pos_y", "vel_x", "vel_y", "timer")
CHARACTER_ITEM_PREFIXES = {
    "falco": ("It_Kind_Falco_",),
    "fox": ("It_Kind_Fox_",),
    "peach": ("It_Kind_Peach_",),
    "pikachu": ("It_Kind_Pikachu_",),
    "samus": ("It_Kind_Samus_",),
    "sheik": ("It_Kind_Seak_",),
}
CHARACTER_OWNED_COMMON_ITEMS = {
    # Vegetable pull can source these common-item kinds in addition to Peach_Turnip.
    "peach": frozenset(("It_Kind_BombHei", "It_Kind_Dosei", "It_Kind_Sword")),
}


def _fighter_identity_fields_recorded(ref: np.ndarray, num_players: int) -> bool:
    """Whether this replay version actually exposes fighter instance identity.

    Older Slippi event versions parse into the current dtype with zero-filled ``instance_id`` and
    ``instance_hit_by`` lanes. Treating those placeholders as authoritative penalizes the simulator
    for producing the native nonzero identity values. A recorded identity stream has a nonzero
    fighter instance id on ordinary live frames.
    """

    return bool(np.any(ref["instance_id"][:, :num_players] != np.uint16(0)))


def _item_identity_field_recorded(items: np.ndarray) -> bool:
    """Whether live replay items carry the optional instance-id field."""

    live = items["exists"] != 0
    return not np.any(live) or bool(np.any(items["instance_id"][live] != np.uint16(0)))


def _article_transition_label(
    seed_exists: bool, ref_exists: bool, seed_state: int, ref_state: int
) -> str:
    if not seed_exists and ref_exists:
        return "spawn"
    if seed_exists and not ref_exists:
        return "despawn"
    if seed_exists and ref_exists and seed_state != ref_state:
        return "state"
    return "identity"


def _logical_item_slot_map(
    items: np.ndarray, owned: np.ndarray, frame: int
) -> dict[tuple[str, int, int], int]:
    """Map character articles to stable per-frame identities across fixed-slot movement.

    Slippi's item spawn id is global and remains attached across reflection and state changes. The
    occurrence suffix is only a defensive fallback for malformed/legacy rows with duplicate ids.
    """

    result: dict[tuple[str, int, int], int] = {}
    seen: Counter[tuple[str, int]] = Counter()
    for slot in np.flatnonzero(owned[frame]):
        base = ("spawn", int(items["spawn_id"][frame, slot]))
        occurrence = int(seen[base])
        seen[base] += 1
        result[(base[0], base[1], occurrence)] = int(slot)
    return result


def _owned_item_mask(
    items: np.ndarray, fighter_char_ids: np.ndarray, *, char_id: int, num_players: int
) -> np.ndarray:
    """Return item slots whose current owner is the requested character.

    Slippi item owners are local player slots after validation preprocessing. The mask deliberately
    requires a live item: empty slots retain zero-valued owner bytes and must never be attributed to
    player zero.
    """

    if items.ndim != 2 or fighter_char_ids.ndim != 2:
        raise ValueError("items and fighter_char_ids must both be two-dimensional")
    if items.shape[0] != fighter_char_ids.shape[0]:
        raise ValueError("items and fighter_char_ids must have matching frame counts")
    if num_players <= 0 or fighter_char_ids.shape[1] < num_players:
        raise ValueError("num_players is incompatible with fighter_char_ids")

    owner = np.asarray(items["owner"], dtype=np.int16)
    valid = (items["exists"] != 0) & (owner >= 0) & (owner < int(num_players))
    safe_owner = np.clip(owner, 0, int(num_players) - 1)
    rows = np.arange(items.shape[0], dtype=np.intp)[:, None]
    owner_char = fighter_char_ids[rows, safe_owner]
    return valid & (owner_char == np.uint8(char_id))


def _character_article_mask(
    items: np.ndarray,
    fighter_char_ids: np.ndarray,
    *,
    char_name: str,
    char_id: int,
    num_players: int,
    kind_names: dict[int, str],
) -> np.ndarray:
    """Identify articles authored by the target character.

    Character-prefixed item kinds retain their source family after reflection, so their current
    owner is not required. Peach's rare common-item vegetable pulls are ambiguous by kind and are
    admitted only while the target player owns them.
    """

    prefixes = CHARACTER_ITEM_PREFIXES.get(char_name, ())
    common_names = CHARACTER_OWNED_COMMON_ITEMS.get(char_name, frozenset())
    native_kinds = np.zeros(65536, dtype=bool)
    common_kinds = np.zeros(65536, dtype=bool)
    for kind, name in kind_names.items():
        if any(name.startswith(prefix) for prefix in prefixes):
            native_kinds[int(kind)] = True
        if name in common_names:
            common_kinds[int(kind)] = True
    exists = items["exists"] != 0
    types = items["type"].astype(np.uint16)
    owned = _owned_item_mask(
        items, fighter_char_ids, char_id=char_id, num_players=num_players
    )
    return exists & (native_kinds[types] | (common_kinds[types] & owned))


def _state_flag_diff(out: np.ndarray, ref: np.ndarray, player: int) -> np.ndarray:
    out_flags = out["state_flags"][:, player].copy()
    ref_flags = ref["state_flags"][:, player].copy()
    # RL1 gameplay excludes only the camera-subject bit.
    out_flags[:, 4] &= np.uint8(0x7F)
    ref_flags[:, 4] &= np.uint8(0x7F)
    return np.any(out_flags != ref_flags, axis=1)


def _fighter_field_diff(out: np.ndarray, ref: np.ndarray, field: str, player: int) -> np.ndarray:
    if field == "state_flags":
        return _state_flag_diff(out, ref, player)
    return out[field][:, player] != ref[field][:, player]


def _float_summary(values: Iterable[np.ndarray]) -> dict[str, float | int]:
    arrays = [np.asarray(value, dtype=np.float64).reshape(-1) for value in values if value.size]
    if not arrays:
        return {
            "count": 0,
            "nonzero": 0,
            "over_1e-4": 0,
            "over_1e-3": 0,
            "over_1e-2": 0,
            "over_1e-1": 0,
            "mae": 0.0,
            "p95": 0.0,
            "max": 0.0,
        }
    data = np.concatenate(arrays)
    return {
        "count": int(data.size),
        "nonzero": int(np.count_nonzero(data)),
        "over_1e-4": int(np.count_nonzero(data > 1.0e-4)),
        "over_1e-3": int(np.count_nonzero(data > 1.0e-3)),
        "over_1e-2": int(np.count_nonzero(data > 1.0e-2)),
        "over_1e-1": int(np.count_nonzero(data > 1.0e-1)),
        "mae": float(np.mean(data)),
        "p95": float(np.percentile(data, 95.0)),
        "max": float(np.max(data)),
    }


def _load_item_kind_names(path: Path) -> dict[int, str]:
    """Read the implicit ItemKind enum without maintaining a second numeric table."""

    text = path.read_text(encoding="utf-8")
    match = re.search(r"typedef\s+enum\s+ItemKind\s*\{(?P<body>.*?)\}\s*ItemKind\s*;", text, re.S)
    if match is None:
        raise ValueError(f"could not locate ItemKind enum in {path}")
    names: dict[int, str] = {}
    body = re.sub(r"/\*.*?\*/", "", match.group("body"), flags=re.S)
    body = re.sub(r"//.*", "", body)
    for line in body.splitlines():
        token = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*,", line)
        if token is not None:
            names[len(names)] = token.group(1)
    return names


def _counter_rows(counter: Counter[tuple[Any, ...]], labels: tuple[str, ...], limit: int) -> list[dict[str, Any]]:
    return [
        {"count": int(count), **dict(zip(labels, key, strict=True))}
        for key, count in counter.most_common(limit)
    ]


def _item_core_values(
    items: np.ndarray, frame: int, slot: int | None
) -> dict[str, bool | int | None]:
    """Return JSON-safe article-core values, preserving an absent logical article."""

    if slot is None:
        return {
            "exists": False,
            **{field: None for field in ITEM_CORE_DISCRETE_FIELDS if field != "exists"},
        }
    return {
        "exists": bool(items["exists"][frame, slot]),
        **{
            field: int(items[field][frame, slot])
            for field in ITEM_CORE_DISCRETE_FIELDS
            if field != "exists"
        },
    }


def _native_data_root_scope(data_root: Path):
    """Keep native table loaders on one root while a multi-replay triage is running."""

    import msl_binding
    from melee_sim._data_dir_override import native_data_dir_override

    return native_data_dir_override(msl_binding, data_root)


def _entries_with_native_data_root(entries: Iterable[dict[str, Any]], data_root: Path):
    """Yield replay entries while preserving the outer native data-root lease."""

    with _native_data_root_scope(data_root):
        yield from entries


def triage_suite(
    *,
    suite_path: Path,
    data_root: Path,
    char_name: str,
    char_id: int,
    chunk: int,
    limit: int,
    item_kind_header: Path,
    sample_limit: int = 0,
) -> dict[str, Any]:
    if sample_limit < 0:
        raise ValueError("sample_limit must be non-negative")
    data_root = data_root.expanduser().resolve()
    suite = json.loads(suite_path.read_text(encoding="utf-8"))
    ucf_enabled = bool(suite.get("ucf_enabled", True))
    cardinals = bool(suite.get("ucf_cardinals_1_0_enabled", False))
    for entry in suite["replays"]:
        declared_char_id = entry.get("target_post_frame_internal_id")
        if declared_char_id is not None and int(declared_char_id) != int(char_id):
            raise ValueError(
                "Character full-parity triage suite target ID does not match request: "
                f"character {char_name!r}, requested internal ID {int(char_id)}, "
                f"entry {entry['replay']!r} declares target_post_frame_internal_id "
                f"{int(declared_char_id)}, suite {suite_path}"
            )
    kind_names = _load_item_kind_names(item_kind_header)

    fighter_field_counts: Counter[str] = Counter()
    fighter_action_fields: Counter[tuple[int, str]] = Counter()
    item_core_counts: Counter[str] = Counter()
    item_payload_counts: Counter[str] = Counter()
    item_kind_fields: Counter[tuple[int, str]] = Counter()
    item_kind_observations: Counter[int] = Counter()
    item_kind_states: dict[int, Counter[int]] = defaultdict(Counter)
    item_kind_spawns: dict[int, set[tuple[str, int, int]]] = defaultdict(set)
    item_core_transitions: Counter[tuple[Any, ...]] = Counter()
    fighter_float_errors: dict[str, list[np.ndarray]] = defaultdict(list)
    item_float_errors: dict[str, list[np.ndarray]] = defaultdict(list)
    fighter_unscored_replays: Counter[str] = Counter()
    article_unscored_replays: Counter[str] = Counter()
    article_core_samples: dict[int, list[dict[str, Any]]] = defaultdict(list)

    total_target_frames = 0
    total_target_record_frames = 0
    fighter_gameplay_mismatch_frames = 0
    fighter_bookkeeping_mismatch_frames = 0
    fighter_all_discrete_mismatch_frames = 0
    article_relevant_frames = 0
    article_relevant_slots = 0
    article_core_mismatch_frames = 0
    article_payload_mismatch_frames = 0
    full_gameplay_mismatch_frames = 0
    full_exact_discrete_mismatch_frames = 0
    replay_rows: list[dict[str, Any]] = []

    for entry in _entries_with_native_data_root(suite["replays"], data_root):
        replay = (repo_root() / entry["replay"]).resolve()
        ports = [int(port) for port in entry.get("ports", [])] or None
        with replay_path_for_peppi(replay) as peppi_path:
            buffers = build_validation_buffers_from_slp(
                slp_path=str(peppi_path),
                ports=ports,
                ucf_enabled=ucf_enabled,
                ucf_cardinals_1_0_enabled=cardinals,
                data_root=data_root,
            )
        out = _run_one_step(
            buffers,
            chunk=chunk,
            ucf_enabled=ucf_enabled,
            cardinals=cardinals,
            data_root=data_root,
        )
        seed = buffers.seed_t
        ref = buffers.ref_t1
        n = buffers.num_records
        replay_target_mask = np.zeros(n, dtype=bool)
        replay_fighter_gameplay_bad = np.zeros(n, dtype=bool)
        replay_fighter_bookkeeping_bad = np.zeros(n, dtype=bool)

        animation_index_recorded = not np.array_equal(
            ref["animation_index"][:, : buffers.num_players],
            ref["action_id"][:, : buffers.num_players].astype(np.uint32),
        )
        fighter_identity_recorded = _fighter_identity_fields_recorded(
            ref, buffers.num_players
        )
        unscored_fighter_fields = set()
        if not fighter_identity_recorded:
            unscored_fighter_fields.update(("instance_id", "instance_hit_by"))
            fighter_unscored_replays.update(unscored_fighter_fields)
        fighter_fields = tuple(
            field
            for field in FIGHTER_DISCRETE_FIELDS
            if (field != "animation_index" or animation_index_recorded)
            and field not in unscored_fighter_fields
        )
        if not animation_index_recorded:
            unscored_fighter_fields.add("animation_index")
            fighter_unscored_replays["animation_index"] += 1
        for player in range(buffers.num_players):
            target = seed["char_id"][:, player] == np.uint8(char_id)
            replay_target_mask |= target
            total_target_frames += int(np.count_nonzero(target))
            if not np.any(target):
                continue
            seed_actions = seed["action_id"][:, player]
            for field in fighter_fields:
                diff = target & _fighter_field_diff(out, ref, field, player)
                if field in FIGHTER_BOOKKEEPING_FIELDS:
                    replay_fighter_bookkeeping_bad |= diff
                else:
                    replay_fighter_gameplay_bad |= diff
                count = int(np.count_nonzero(diff))
                fighter_field_counts[field] += count
                for action, action_count in Counter(seed_actions[diff].tolist()).items():
                    fighter_action_fields[(int(action), field)] += int(action_count)
            for field in FIGHTER_FLOAT_FIELDS:
                fighter_float_errors[field].append(
                    np.abs(
                        out[field][target, player].astype(np.float64)
                        - ref[field][target, player].astype(np.float64)
                    )
                )

        total_target_record_frames += int(np.count_nonzero(replay_target_mask))

        seed_owned = _character_article_mask(
            seed["items"],
            seed["char_id"],
            char_name=char_name,
            char_id=char_id,
            num_players=buffers.num_players,
            kind_names=kind_names,
        )
        ref_owned = _character_article_mask(
            ref["items"],
            ref["char_id"],
            char_name=char_name,
            char_id=char_id,
            num_players=buffers.num_players,
            kind_names=kind_names,
        )
        out_owned = _character_article_mask(
            out["items"],
            out["char_id"],
            char_name=char_name,
            char_id=char_id,
            num_players=buffers.num_players,
            kind_names=kind_names,
        )
        relevant = seed_owned | ref_owned | out_owned
        relevant_rows = np.any(relevant, axis=1)
        replay_article_core_bad = np.zeros(n, dtype=bool)
        replay_article_payload_bad = np.zeros(n, dtype=bool)

        article_relevant_frames += int(np.count_nonzero(relevant_rows))
        article_relevant_slots += int(np.count_nonzero(relevant))
        ref_items = ref["items"]
        out_items = out["items"]
        seed_items = seed["items"]
        kind = np.where(
            ref_owned,
            ref_items["type"],
            np.where(out_owned, out_items["type"], seed_items["type"]),
        ).astype(np.uint16)

        item_identity_recorded = _item_identity_field_recorded(ref_items)
        unscored_article_fields = set()
        if not item_identity_recorded and np.any(relevant):
            unscored_article_fields.add("instance_id")
            article_unscored_replays["instance_id"] += 1

        for field in ITEM_CORE_DISCRETE_FIELDS:
            if field in unscored_article_fields:
                continue
            diff = relevant & (out_items[field] != ref_items[field])
            replay_article_core_bad |= np.any(diff, axis=1)
            item_core_counts[field] += int(np.count_nonzero(diff))
            for item_kind, count in Counter(kind[diff].tolist()).items():
                item_kind_fields[(int(item_kind), field)] += int(count)
        for frame in np.flatnonzero(relevant_rows):
            seed_slots = _logical_item_slot_map(seed_items, seed_owned, int(frame))
            ref_slots = _logical_item_slot_map(ref_items, ref_owned, int(frame))
            out_slots = _logical_item_slot_map(out_items, out_owned, int(frame))
            item_keys = set(seed_slots) | set(ref_slots) | set(out_slots)
            if sample_limit > 0:
                item_keys = sorted(item_keys)
            for item_key in item_keys:
                seed_slot = seed_slots.get(item_key)
                ref_slot = ref_slots.get(item_key)
                out_slot = out_slots.get(item_key)
                seed_exists = seed_slot is not None
                ref_exists = ref_slot is not None
                out_exists = out_slot is not None
                differing_core_fields = ["exists"] if ref_exists != out_exists else []
                if ref_slot is not None and out_slot is not None:
                    differing_core_fields.extend(
                        field
                        for field in ITEM_CORE_DISCRETE_FIELDS
                        if field not in unscored_article_fields
                        and field != "exists"
                        and int(ref_items[field][frame, ref_slot])
                        != int(out_items[field][frame, out_slot])
                    )
                if not differing_core_fields:
                    continue
                seed_state = (
                    int(seed_items["state"][frame, seed_slot])
                    if seed_slot is not None
                    else 0
                )
                ref_state = (
                    int(ref_items["state"][frame, ref_slot]) if ref_slot is not None else 0
                )
                out_state = (
                    int(out_items["state"][frame, out_slot]) if out_slot is not None else 0
                )
                item_kind = 0
                for items, slot in (
                    (ref_items, ref_slot),
                    (seed_items, seed_slot),
                    (out_items, out_slot),
                ):
                    if slot is not None:
                        item_kind = int(items["type"][frame, slot])
                        break
                owner = -1
                for items, slot in (
                    (ref_items, ref_slot),
                    (seed_items, seed_slot),
                    (out_items, out_slot),
                ):
                    if slot is None:
                        continue
                    candidate = int(items["owner"][frame, slot])
                    if 0 <= candidate < buffers.num_players:
                        owner = candidate
                        break
                owner_action = int(seed["action_id"][frame, owner]) if owner >= 0 else -1
                owner_reference_action = (
                    int(ref["action_id"][frame, owner]) if owner >= 0 else -1
                )
                owner_seed_action_frame = (
                    int(seed["action_frame"][frame, owner]) if owner >= 0 else -1
                )
                owner_reference_action_frame = (
                    int(ref["action_frame"][frame, owner]) if owner >= 0 else -1
                )
                item_core_transitions[
                    (
                        item_kind,
                        _article_transition_label(
                            seed_exists, ref_exists, seed_state, ref_state
                        ),
                        owner_action,
                        owner_reference_action,
                        owner_seed_action_frame,
                        owner_reference_action_frame,
                        int(seed_exists),
                        seed_state,
                        int(ref_exists),
                        ref_state,
                        int(out_exists),
                        out_state,
                    )
                ] += 1
                if sample_limit > 0 and len(article_core_samples[item_kind]) < sample_limit:
                    article_core_samples[item_kind].append(
                        {
                            "replay": str(entry["replay"]),
                            "record_index": int(frame),
                            "logical_identity": {
                                "spawn_id": int(item_key[1]),
                                "occurrence": int(item_key[2]),
                                "seed_slot": seed_slot,
                                "reference_slot": ref_slot,
                                "output_slot": out_slot,
                            },
                            "differing_core_fields": differing_core_fields,
                            "seed": _item_core_values(seed_items, int(frame), seed_slot),
                            "reference": _item_core_values(ref_items, int(frame), ref_slot),
                            "output": _item_core_values(out_items, int(frame), out_slot),
                        }
                    )
        for field in ITEM_PAYLOAD_DISCRETE_FIELDS:
            diff = relevant & (out_items[field] != ref_items[field])
            replay_article_payload_bad |= np.any(diff, axis=1)
            item_payload_counts[field] += int(np.count_nonzero(diff))
            for item_kind, count in Counter(kind[diff].tolist()).items():
                item_kind_fields[(int(item_kind), field)] += int(count)
        # Float error is meaningful only against a reference article from this character family.
        # A missing/extra target article can shift an unrelated item into the same fixed slot; the
        # core existence/type mismatch already records that lifecycle error without polluting the
        # target article's trajectory distribution with another family's coordinates.
        ref_relevant = ref_owned
        for field in ITEM_FLOAT_FIELDS:
            item_float_errors[field].append(
                np.abs(
                    out_items[field][ref_relevant].astype(np.float64)
                    - ref_items[field][ref_relevant].astype(np.float64)
                )
            )

        for item_kind, count in Counter(ref_items["type"][ref_owned].tolist()).items():
            item_kind_observations[int(item_kind)] += int(count)
        for frame, slot in np.argwhere(ref_owned):
            item_kind = int(ref_items["type"][frame, slot])
            item_kind_states[item_kind][int(ref_items["state"][frame, slot])] += 1
            item_kind_spawns[item_kind].add(
                (
                    str(entry["replay"]),
                    int(ref_items["spawn_id"][frame, slot]),
                    int(ref_items["instance_id"][frame, slot]),
                )
            )

        replay_fighter_all_bad = replay_fighter_gameplay_bad | replay_fighter_bookkeeping_bad
        fighter_gameplay_bad_count = int(
            np.count_nonzero(replay_fighter_gameplay_bad & replay_target_mask)
        )
        fighter_bookkeeping_bad_count = int(
            np.count_nonzero(replay_fighter_bookkeeping_bad & replay_target_mask)
        )
        fighter_all_bad_count = int(
            np.count_nonzero(replay_fighter_all_bad & replay_target_mask)
        )
        article_core_bad_count = int(np.count_nonzero(replay_article_core_bad))
        article_payload_bad_count = int(np.count_nonzero(replay_article_payload_bad))
        full_gameplay_bad = (
            (replay_fighter_gameplay_bad & replay_target_mask) | replay_article_core_bad
        )
        full_exact_bad = (
            (replay_fighter_all_bad & replay_target_mask)
            | replay_article_core_bad
            | replay_article_payload_bad
        )
        fighter_gameplay_mismatch_frames += fighter_gameplay_bad_count
        fighter_bookkeeping_mismatch_frames += fighter_bookkeeping_bad_count
        fighter_all_discrete_mismatch_frames += fighter_all_bad_count
        article_core_mismatch_frames += article_core_bad_count
        article_payload_mismatch_frames += article_payload_bad_count
        full_gameplay_mismatch_frames += int(np.count_nonzero(full_gameplay_bad))
        full_exact_discrete_mismatch_frames += int(np.count_nonzero(full_exact_bad))
        replay_rows.append(
            {
                "replay": entry["replay"],
                "target_frames": int(np.count_nonzero(replay_target_mask)),
                "fighter_gameplay_mismatch_frames": fighter_gameplay_bad_count,
                "fighter_bookkeeping_mismatch_frames": fighter_bookkeeping_bad_count,
                "fighter_all_discrete_mismatch_frames": fighter_all_bad_count,
                "article_relevant_frames": int(np.count_nonzero(relevant_rows)),
                "article_core_mismatch_frames": article_core_bad_count,
                "article_payload_mismatch_frames": article_payload_bad_count,
                "full_gameplay_mismatch_frames": int(np.count_nonzero(full_gameplay_bad)),
                "full_exact_discrete_mismatch_frames": int(np.count_nonzero(full_exact_bad)),
                "unscored_fighter_fields": sorted(unscored_fighter_fields),
                "unscored_article_fields": sorted(unscored_article_fields),
            }
        )

    if total_target_record_frames == 0:
        raise ValueError(
            "Character full-parity triage produced zero target record frames "
            f"for character {char_name!r} (requested internal ID {int(char_id)}) "
            f"in suite {suite_path}"
        )

    kinds = []
    all_kinds = sorted(
        set(item_kind_observations) | {int(key[0]) for key in item_kind_fields.keys()}
    )
    for item_kind in all_kinds:
        kinds.append(
            {
                "item_kind": item_kind,
                "name": kind_names.get(item_kind, f"unknown_{item_kind}"),
                "reference_observations": int(item_kind_observations[item_kind]),
                "reference_unique_spawns": len(item_kind_spawns[item_kind]),
                "reference_states": {
                    str(state): int(count)
                    for state, count in item_kind_states[item_kind].most_common()
                },
                "mismatches_by_field": {
                    field: int(item_kind_fields[(item_kind, field)])
                    for field in ITEM_CORE_DISCRETE_FIELDS + ITEM_PAYLOAD_DISCRETE_FIELDS
                    if item_kind_fields[(item_kind, field)]
                },
            }
        )

    report = {
        "suite": str(suite_path),
        "character": {"name": char_name, "internal_id": int(char_id)},
        "games": len(suite["replays"]),
        "target_frames": total_target_frames,
        "target_record_frames": total_target_record_frames,
        "fighter_gameplay_mismatch_frames": fighter_gameplay_mismatch_frames,
        "fighter_gameplay_mismatch_rate": (
            fighter_gameplay_mismatch_frames / total_target_record_frames
            if total_target_record_frames
            else 0.0
        ),
        "fighter_bookkeeping_mismatch_frames": fighter_bookkeeping_mismatch_frames,
        "fighter_bookkeeping_mismatch_rate": (
            fighter_bookkeeping_mismatch_frames / total_target_record_frames
            if total_target_record_frames
            else 0.0
        ),
        "fighter_all_discrete_mismatch_frames": fighter_all_discrete_mismatch_frames,
        "fighter_all_discrete_mismatch_rate": (
            fighter_all_discrete_mismatch_frames / total_target_record_frames
            if total_target_record_frames
            else 0.0
        ),
        "article_relevant_frames": article_relevant_frames,
        "article_relevant_slots": article_relevant_slots,
        "article_core_mismatch_frames": article_core_mismatch_frames,
        "article_core_mismatch_rate": (
            article_core_mismatch_frames / article_relevant_frames
            if article_relevant_frames
            else 0.0
        ),
        "article_payload_mismatch_frames": article_payload_mismatch_frames,
        "full_gameplay_mismatch_frames": full_gameplay_mismatch_frames,
        "full_gameplay_mismatch_rate": (
            full_gameplay_mismatch_frames / total_target_record_frames
            if total_target_record_frames
            else 0.0
        ),
        "full_exact_discrete_mismatch_frames": full_exact_discrete_mismatch_frames,
        "full_exact_discrete_mismatch_rate": (
            full_exact_discrete_mismatch_frames / total_target_record_frames
            if total_target_record_frames
            else 0.0
        ),
        "fighter_discrete_mismatches_by_field": dict(fighter_field_counts.most_common()),
        "fighter_float_error": {
            field: _float_summary(fighter_float_errors[field]) for field in FIGHTER_FLOAT_FIELDS
        },
        "article_core_mismatches_by_field": dict(item_core_counts.most_common()),
        "article_payload_mismatches_by_field": dict(item_payload_counts.most_common()),
        "fighter_unscored_replays_by_field": dict(fighter_unscored_replays.most_common()),
        "article_unscored_replays_by_field": dict(article_unscored_replays.most_common()),
        "article_float_error": {
            field: _float_summary(item_float_errors[field]) for field in ITEM_FLOAT_FIELDS
        },
        "article_kinds": kinds,
        "top_fighter_seed_action_fields": _counter_rows(
            fighter_action_fields, ("seed_action", "field"), limit
        ),
        "top_article_kind_fields": [
            {
                "count": int(count),
                "item_kind": int(key[0]),
                "name": kind_names.get(int(key[0]), f"unknown_{int(key[0])}"),
                "field": str(key[1]),
            }
            for key, count in item_kind_fields.most_common(limit)
        ],
        "top_article_core_transitions": [
            {
                "count": int(count),
                "item_kind": int(key[0]),
                "name": kind_names.get(int(key[0]), f"unknown_{int(key[0])}"),
                "transition": str(key[1]),
                "owner_seed_action": int(key[2]),
                "owner_reference_action": int(key[3]),
                "owner_seed_action_frame": int(key[4]),
                "owner_reference_action_frame": int(key[5]),
                "seed_exists": bool(key[6]),
                "seed_state": int(key[7]),
                "reference_exists": bool(key[8]),
                "reference_state": int(key[9]),
                "output_exists": bool(key[10]),
                "output_state": int(key[11]),
            }
            for key, count in item_core_transitions.most_common(limit)
        ],
        "replays": replay_rows,
    }
    if sample_limit > 0:
        report["article_core_mismatch_samples"] = [
            {
                "item_kind": item_kind,
                "name": kind_names.get(item_kind, f"unknown_{item_kind}"),
                "samples": samples,
            }
            for item_kind, samples in sorted(article_core_samples.items())
        ]
    return report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Attribute fighter and owned-article one-step parity to one character."
    )
    parser.add_argument("--suite", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, default=Path("data"))
    parser.add_argument("--character", choices=sorted(CHARS), required=True)
    parser.add_argument("--character-id", type=int)
    parser.add_argument("--chunk", type=int, default=4096)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument(
        "--sample-limit",
        type=int,
        default=0,
        help="Persist up to this many exact article-core mismatch samples per item kind.",
    )
    parser.add_argument(
        "--item-kind-header", type=Path, default=Path("refs/melee/src/melee/it/forward.h")
    )
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    payload = triage_suite(
        suite_path=args.suite.resolve(),
        data_root=args.data_root.resolve(),
        char_name=args.character,
        char_id=(
            int(args.character_id)
            if args.character_id is not None
            else int(CHARS[args.character].internal_id)
        ),
        chunk=int(args.chunk),
        limit=int(args.limit),
        item_kind_header=args.item_kind_header.resolve(),
        sample_limit=int(args.sample_limit),
    )
    text = json.dumps(payload, indent=2) + "\n"
    if args.out is None:
        print(text, end="")
    else:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8", newline="\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
