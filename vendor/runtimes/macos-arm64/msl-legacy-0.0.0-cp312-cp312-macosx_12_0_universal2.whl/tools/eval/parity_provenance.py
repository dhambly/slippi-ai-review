from __future__ import annotations

import hashlib
import importlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any

from tools.slippi.slpz import resolve_replay_path
from tools.slippi.suite_io import display_path_under_repo, load_suite, repo_root


PROVENANCE_SCHEMA_VERSION = 1
_CHUNK_SIZE = 1024 * 1024


def canonical_data_root(data_root: Path | str) -> Path:
    """Return the one absolute runtime-data root used by a matrix invocation."""
    return Path(data_root).expanduser().resolve()


def sha256_file(path: Path) -> str:
    """Return the SHA256 of a file without loading replay or data files at once."""
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(_CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_sha256(payload: object) -> str:
    """Hash JSON content independently of formatting and object-key order."""
    canonical = json.dumps(
        payload,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _record_path(path: Path, *, root: Path) -> str:
    return display_path_under_repo(path, root)


def preflight_suite(path: Path, *, root: Path | None = None) -> dict[str, Any]:
    """Validate a suite and return its immutable manifest and replay provenance."""
    root = repo_root() if root is None else root
    if not path.is_file():
        raise FileNotFoundError(f"Suite manifest not found: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid suite manifest {path}: {exc}") from exc

    replays = payload.get("replays") if isinstance(payload, dict) else None
    if not isinstance(replays, list):
        raise ValueError(f"Suite manifest {path} must contain a replays list")

    for index, entry in enumerate(replays):
        if not isinstance(entry, dict):
            raise ValueError(f"Suite manifest {path} replay {index} must be an object")
        replay = entry.get("replay")
        if not isinstance(replay, str) or not replay:
            raise ValueError(f"Suite manifest {path} replay {index} must have a replay path")
        ports = entry.get("ports")
        if not isinstance(ports, list):
            raise ValueError(f"Suite replay ports must be a list: {replay}")
        if len(ports) not in (2, 4):
            raise ValueError(f"Suite replay ports must select 2 or 4 ports: {replay}")
        if any(type(port) is not int for port in ports):
            raise ValueError(f"Suite replay ports must contain integers: {replay}")
        if any(port < 1 or port > 4 for port in ports):
            raise ValueError(f"Suite replay ports must be in 1..4: {replay}")
        if len(set(ports)) != len(ports):
            raise ValueError(f"Suite replay ports must be unique: {replay}")

    # Keep required fields and doubles/team-attack behavior aligned with the shared
    # suite-loader contract used by the validation tooling.
    loaded_suite = load_suite(path)

    selected_replays: list[dict[str, str]] = []
    ordered_content = hashlib.sha256()
    for entry in loaded_suite.replays:
        configured = Path(entry.replay)
        configured = configured if configured.is_absolute() else root / configured
        replay_path = resolve_replay_path(configured)
        if not replay_path.is_file():
            raise FileNotFoundError(
                f"Suite replay not found: {entry.replay} (referenced by {path})"
            )
        replay_sha256 = sha256_file(replay_path)
        # The stream is intentionally ordered by suite selection. Include a separator so
        # adjacent digests cannot be ambiguously concatenated.
        ordered_content.update(replay_sha256.encode("ascii"))
        ordered_content.update(b"\0")
        selected_replays.append(
            {
                "path": _record_path(replay_path, root=root),
                "sha256": replay_sha256,
            }
        )

    return {
        "path": _record_path(path, root=root),
        "manifest_sha256": canonical_json_sha256(payload),
        "selected_replay_content_sha256": ordered_content.hexdigest(),
        "replays": selected_replays,
    }


def _hash_data_tree(data_root: Path, *, root: Path) -> dict[str, Any]:
    if not data_root.is_absolute():
        raise ValueError(f"Runtime data root must be canonical and absolute: {data_root}")
    if data_root == root.resolve():
        raise ValueError(f"Refusing to hash the repository root as runtime data: {data_root}")
    if not data_root.is_dir():
        raise FileNotFoundError(f"Runtime data root not found: {data_root}")

    manifest_path = data_root / "manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Runtime data manifest not found: {manifest_path}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Invalid runtime data manifest {manifest_path}: {exc}") from exc
    if not isinstance(manifest, dict) or manifest.get("magic") != "MSLDATA1":
        raise ValueError(f"Not a melee_sim runtime data root: {data_root}")
    if manifest.get("version") != 1 or not isinstance(manifest.get("schemas"), dict):
        raise ValueError(f"Unsupported melee_sim runtime data manifest: {manifest_path}")

    digest = hashlib.sha256()
    files = sorted(
        (path for path in data_root.rglob("*") if path.is_file()),
        key=lambda path: path.relative_to(data_root).as_posix(),
    )
    total_bytes = 0
    manifest_sha256: str | None = None
    for path in files:
        relative = path.relative_to(data_root).as_posix().encode("utf-8")
        file_sha256 = sha256_file(path)
        digest.update(relative)
        digest.update(b"\0")
        digest.update(bytes.fromhex(file_sha256))
        total_bytes += path.stat().st_size
        if path == manifest_path:
            manifest_sha256 = file_sha256
    if manifest_sha256 is None:
        raise RuntimeError(f"Runtime data manifest vanished while hashing: {manifest_path}")
    return {
        "path": str(data_root),
        "repo_relative_path": _record_path(data_root, root=root),
        "sha256": digest.hexdigest(),
        "files": len(files),
        "total_bytes": total_bytes,
        "manifest": {
            "path": str(manifest_path),
            "repo_relative_path": _record_path(manifest_path, root=root),
            "sha256": manifest_sha256,
        },
    }


def _git_provenance(root: Path) -> dict[str, Any]:
    def run_git(*args: str) -> bytes:
        completed = subprocess.run(
            ["git", *args],
            cwd=root,
            check=False,
            capture_output=True,
        )
        if completed.returncode != 0:
            detail = completed.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(f"git {' '.join(args)} failed: {detail or completed.returncode}")
        return completed.stdout

    head = run_git("rev-parse", "HEAD").decode("ascii").strip()
    diff = run_git("diff", "--binary", "HEAD")
    untracked_paths = sorted(
        path for path in run_git("ls-files", "--others", "--exclude-standard", "-z").split(b"\0") if path
    )
    untracked = hashlib.sha256()
    untracked_bytes = 0
    untracked_files = 0
    untracked_directories = 0
    for encoded_path in untracked_paths:
        path = root / os.fsdecode(encoded_path)
        # Git reports an untracked nested repository as its directory entry. It is
        # still useful provenance information, but cannot be opened as a file.
        if path.is_dir():
            untracked.update(b"D")
            untracked.update(len(encoded_path).to_bytes(8, "big"))
            untracked.update(encoded_path)
            untracked_directories += 1
            continue
        if not path.is_file():
            continue
        content_size = path.stat().st_size
        untracked.update(len(encoded_path).to_bytes(8, "big"))
        untracked.update(encoded_path)
        untracked.update(content_size.to_bytes(8, "big"))
        with path.open("rb") as source:
            for chunk in iter(lambda: source.read(_CHUNK_SIZE), b""):
                untracked.update(chunk)
        untracked_bytes += content_size
        untracked_files += 1
    return {
        "head": head,
        "dirty": bool(diff or untracked_paths),
        "diff_sha256": hashlib.sha256(diff).hexdigest(),
        "diff_bytes": len(diff),
        "untracked_sha256": untracked.hexdigest(),
        "untracked_files": untracked_files,
        "untracked_directories": untracked_directories,
        "untracked_bytes": untracked_bytes,
    }


def _native_provenance(root: Path) -> dict[str, Any]:
    native = importlib.import_module("melee_sim._native")
    location = getattr(native, "__file__", None)
    path = Path(location) if location is not None else None
    if path is None or not path.is_file():
        raise RuntimeError("Loaded melee_sim._native has no hashable extension path")
    stat = path.stat()
    return {
        "module": "melee_sim._native",
        "path": _record_path(path, root=root),
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "sha256": sha256_file(path),
    }


def global_provenance(
    *, data_root: Path, evaluator_path: Path, root: Path | None = None
) -> dict[str, Any]:
    """Build the shared matrix fingerprint once before evaluator subprocesses start."""
    root = repo_root() if root is None else root
    evaluator = evaluator_path.resolve()
    return {
        "schema_version": PROVENANCE_SCHEMA_VERSION,
        "native": _native_provenance(root),
        "evaluator": {
            "path": _record_path(evaluator, root=root),
            "sha256": sha256_file(evaluator),
        },
        "data": _hash_data_tree(data_root, root=root),
        "git": _git_provenance(root),
    }
