"""Build reproducible, stage-balanced validation suites for supported characters."""

from __future__ import annotations

import argparse
import hashlib
import json
import posixpath
from collections.abc import Iterable, Mapping
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable

import numpy as np
from peppi_py import _read_slippi

from tools.extraction.char_registry import CHARS


ROOT = Path(__file__).resolve().parents[2]
LEGAL_STAGES = (2, 3, 8, 28, 31, 32)
DISPLAY_NAMES = {
    "falcon": "Captain Falcon",
    "ganon": "Ganondorf",
    "fox": "Fox",
    "marth": "Marth",
    "peach": "Peach",
    "pikachu": "Pikachu",
    "puff": "Jigglypuff",
    "sheik": "Sheik",
    "samus": "Samus",
    "falco": "Falco",
    "yoshi": "Yoshi",
}
PARITY_CHARACTERS = tuple(DISPLAY_NAMES)
EXTERNAL_CHARACTERS = {
    CHARS[slug].external_id: (slug, DISPLAY_NAMES[slug]) for slug in PARITY_CHARACTERS
}
SUPPORTED_INTERNAL_IDS = frozenset(CHARS[slug].internal_id for slug in PARITY_CHARACTERS)


def _display_path(path: Path) -> str:
    try:
        return path.resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _replay_key(replay: str | Path) -> str:
    """Return a checkout-independent key for a manifest replay path."""
    normalized = posixpath.normpath(str(replay).replace("\\", "/"))
    parts = tuple(part for part in normalized.split("/") if part not in ("", "."))
    folded = tuple(part.casefold() for part in parts)
    anchors = [
        index
        for index in range(len(folded) - 1)
        if folded[index : index + 2] == ("datasets", "slippi")
    ]
    if not anchors:
        raise ValueError("Replay paths must contain a datasets/slippi/ stable anchor")
    return "/".join(folded[anchors[-1] :])


def _normalize_targets(targets: Iterable[str]) -> list[str]:
    requested = list(dict.fromkeys(target.strip().lower() for target in targets))
    unknown = sorted(set(requested) - set(PARITY_CHARACTERS))
    if unknown:
        raise ValueError(f"Unsupported target(s): {', '.join(unknown)}")
    return requested


def load_audit_exclusions(
    paths: Iterable[Path], *, targets: Iterable[str]
) -> dict[str, set[str]]:
    """Return checkout-independent replay keys grouped by requested target."""
    audit_paths = tuple(paths)
    requested = _normalize_targets(targets)
    if not audit_paths:
        return {}
    excluded = {target: set() for target in requested}
    represented: set[str] = set()
    for path in audit_paths:
        payload = json.loads(path.read_text(encoding="utf-8"))
        summaries = {
            str(target).strip().lower(): summary
            for target, summary in payload.get("targets", {}).items()
        }
        for target in requested:
            if target not in summaries:
                continue
            represented.add(target)
            for replay in summaries[target].get("duplicates_with_primary_corpus", []):
                try:
                    excluded[target].add(_replay_key(replay))
                except ValueError as error:
                    raise ValueError(
                        f"Invalid audit replay path for target '{target}' in {path}: "
                        f"{replay!r}: {error}"
                    ) from error
    missing = sorted(set(requested) - represented)
    if missing:
        raise ValueError(
            "Supplied audit files do not declare requested target(s): " + ", ".join(missing)
        )
    return excluded


def _stable_key(target: str, record: dict[str, Any]) -> str:
    identity = f"{target}\0{record.get('source_shard', '')}\0{record.get('member_name', '')}"
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()


def _canonical_record_key(record: dict[str, Any]) -> tuple[str, str, str]:
    return (
        str(record.get("source_shard", "")),
        str(record.get("member_name", "")),
        json.dumps(record, sort_keys=True, separators=(",", ":")),
    )


def _record_characters(record: dict[str, Any]) -> dict[str, int]:
    return {str(port): int(char_id) for port, char_id in record["character_ids"].items()}


def select_records(
    records: Iterable[dict[str, Any]],
    *,
    target_external_id: int,
    per_stage: int,
    record_filter: Callable[[dict[str, Any]], bool] | None = None,
) -> list[dict[str, Any]]:
    target_slug = EXTERNAL_CHARACTERS[target_external_id][0]
    by_stage_opponent: dict[int, dict[int, list[dict[str, Any]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    seen: set[tuple[str, str]] = set()

    for record in sorted(records, key=_canonical_record_key):
        stage = int(record["stage_id"])
        if stage not in LEGAL_STAGES:
            continue
        characters = _record_characters(record)
        ids = tuple(characters.values())
        if len(ids) != 2 or target_external_id not in ids:
            continue
        opponent = ids[0] if ids[1] == target_external_id else ids[1]
        if opponent not in EXTERNAL_CHARACTERS or opponent == target_external_id:
            continue
        identity = (str(record.get("source_shard", "")), str(record.get("member_name", "")))
        if identity in seen:
            continue
        seen.add(identity)
        by_stage_opponent[stage][opponent].append(record)

    for opponents in by_stage_opponent.values():
        for candidates in opponents.values():
            candidates.sort(key=lambda record: _stable_key(target_slug, record))

    selected: list[dict[str, Any]] = []
    global_counts: Counter[int] = Counter()
    for stage in LEGAL_STAGES:
        pools = by_stage_opponent[stage]
        stage_counts: Counter[int] = Counter()
        for _ in range(per_stage):
            available = []
            for opponent, candidates in pools.items():
                while candidates and record_filter is not None and not record_filter(candidates[0]):
                    candidates.pop(0)
                if candidates:
                    available.append(opponent)
            if not available:
                raise RuntimeError(
                    f"Only found {sum(stage_counts.values())}/{per_stage} usable {target_slug} "
                    f"games on stage {stage}"
                )
            opponent = min(
                available,
                key=lambda value: (
                    stage_counts[value],
                    global_counts[value],
                    EXTERNAL_CHARACTERS[value][0],
                ),
            )
            selected.append(pools[opponent].pop(0))
            stage_counts[opponent] += 1
            global_counts[opponent] += 1
    return selected


def _replay_uses_only_supported_characters(
    record: dict[str, Any],
    *,
    target_external_id: int,
    target_internal_id: int,
    require_game_end: bool = False,
    minimum_frames: int = 0,
) -> bool:
    replay_path = ROOT / str(record["replay"])
    try:
        game = _read_slippi(str(replay_path), False)
        if game.frames is None:
            return False
        if len(game.frames) < minimum_frames:
            return False
        if require_game_end and game.end is None:
            return False
        ports = game.frames.field("ports")
        target_ports = [
            int(port)
            for port, character in _record_characters(record).items()
            if character == target_external_id
        ]
        if len(target_ports) != 1:
            return False
        for port in record["ports"]:
            post = ports.field(f"P{int(port)}").field("leader").field("post")
            values = post.field("character").to_numpy(zero_copy_only=False)
            if isinstance(values, np.ma.MaskedArray):
                values = values.compressed()
            values = np.asarray(values, dtype=np.uint8)
            if not set(np.unique(values)).issubset(SUPPORTED_INTERNAL_IDS):
                return False
            if int(port) == target_ports[0] and set(np.unique(values)) != {target_internal_id}:
                return False
    except (AttributeError, OSError, ValueError):
        return False
    return True


def _replay_is_in_source_bucket(record: dict[str, Any], bucket: str) -> bool:
    return Path(str(record["replay"])).parent.name.upper() == bucket.upper()


def _suite_entry(
    record: dict[str, Any], *, target_external_id: int, target_internal_id: int
) -> dict[str, Any]:
    characters = _record_characters(record)
    target_ports = [
        int(port) for port, character in characters.items() if character == target_external_id
    ]
    return {
        "replay": str(record["replay"]),
        "ports": [int(port) for port in record["ports"]],
        "stage_id": int(record["stage_id"]),
        "target_ports": target_ports,
        "target_post_frame_internal_id": target_internal_id,
        "characters": {
            port: EXTERNAL_CHARACTERS[char_id][1] for port, char_id in sorted(characters.items())
        },
    }


def _write_suite(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(payload, indent=2) + "\n")


def _prepare_target_exclusions(
    excluded_replays: Mapping[str, Iterable[str | Path]] | Iterable[str | Path],
    *,
    targets: Iterable[str],
) -> dict[str, set[str]]:
    selectable_targets = [target for target in targets if target != "falcon"]
    if isinstance(excluded_replays, Mapping):
        if not excluded_replays:
            return {}
        prepared: dict[str, set[str]] = {}
        for raw_target, raw_replays in excluded_replays.items():
            target = _normalize_targets([raw_target])[0]
            replays = (
                (raw_replays,)
                if isinstance(raw_replays, (str, Path))
                else raw_replays
            )
            prepared.setdefault(target, set()).update(_replay_key(replay) for replay in replays)
        missing = sorted(set(selectable_targets) - set(prepared))
        unexpected = sorted(set(prepared) - set(selectable_targets))
        if missing:
            raise ValueError(
                "Exclusions do not cover requested target(s): " + ", ".join(missing)
            )
        if unexpected:
            raise ValueError(
                "Exclusions were supplied for unrequested target(s): "
                + ", ".join(unexpected)
            )
        return prepared

    replays = (
        (excluded_replays,)
        if isinstance(excluded_replays, (str, Path))
        else tuple(excluded_replays)
    )
    if not replays:
        return {}
    if len(selectable_targets) != 1:
        raise ValueError(
            "Flat replay exclusions require exactly one non-Falcon target; "
            "use a target-to-replays mapping for multi-target builds"
        )
    return {selectable_targets[0]: {_replay_key(replay) for replay in replays}}


def build_suites(
    *,
    manifest_path: Path,
    falcon_suite_path: Path,
    out_dir: Path,
    targets: Iterable[str],
    per_stage: int,
    source_bucket: str | None = None,
    require_game_end: bool = False,
    minimum_frames: int = 0,
    excluded_replays: Mapping[str, Iterable[str | Path]] | Iterable[str | Path] = (),
) -> list[Path]:
    requested = tuple(_normalize_targets(targets))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    records = list(manifest["replays"])
    slug_to_external = {slug: char_id for char_id, (slug, _) in EXTERNAL_CHARACTERS.items()}
    declared_exclusions = _prepare_target_exclusions(
        excluded_replays,
        targets=requested,
    )
    matched_exclusions: dict[str, set[str]] = {}
    zero_match_targets: list[str] = []
    for target, declared in declared_exclusions.items():
        if not declared:
            matched_exclusions[target] = set()
            continue
        target_external_id = slug_to_external[target]
        manifest_keys = {
            _replay_key(str(record["replay"]))
            for record in records
            if target_external_id in _record_characters(record).values()
        }
        matched_exclusions[target] = declared & manifest_keys
        if not matched_exclusions[target]:
            zero_match_targets.append(f"{target} ({len(declared)} declared)")
    if zero_match_targets:
        raise ValueError(
            "Audit exclusions matched no manifest replays for target(s): "
            + ", ".join(zero_match_targets)
        )

    written: list[Path] = []
    for target in requested:
        out_path = out_dir / f"parity_{target}_ranked.json"
        if target == "falcon":
            payload = json.loads(falcon_suite_path.read_text(encoding="utf-8"))
            payload["name"] = "parity_falcon_ranked"
            payload["notes"] = (
                "Stage- and matchup-balanced modern ranked Falcon parity suite; "
                f"source entries copied from {_display_path(falcon_suite_path)}."
            )
        else:
            target_external_id = slug_to_external[target]
            target_exclusions = matched_exclusions.get(target, set())
            applied_exclusions: set[str] = set()

            def record_filter(record: dict[str, Any]) -> bool:
                if target_exclusions:
                    replay_key = _replay_key(str(record["replay"]))
                    if replay_key in target_exclusions:
                        applied_exclusions.add(replay_key)
                        return False
                return _replay_uses_only_supported_characters(
                    record,
                    target_external_id=target_external_id,
                    target_internal_id=CHARS[target].internal_id,
                    require_game_end=require_game_end,
                    minimum_frames=minimum_frames,
                ) and (
                    source_bucket is None
                    or _replay_is_in_source_bucket(record, source_bucket)
                )

            selected = select_records(
                records,
                target_external_id=target_external_id,
                per_stage=per_stage,
                record_filter=record_filter,
            )
            payload = {
                "name": f"parity_{target}_ranked",
                "notes": (
                    "Deterministic modern ranked parity sample: "
                    f"{per_stage} games per legal stage, supported opponents only, "
                    f"from {_display_path(manifest_path)}."
                    + (" Complete GameEnd records only." if require_game_end else "")
                    + (f" Minimum replay length: {minimum_frames} frames." if minimum_frames else "")
                    + (
                        f" Matched {len(target_exclusions)} audit exclusion(s) to this "
                        f"manifest; applied {len(applied_exclusions)} during selection."
                        if target in declared_exclusions
                        else ""
                    )
                ),
                "ucf_enabled": True,
                "ucf_cardinals_1_0_enabled": False,
                "replays": [
                    _suite_entry(
                        record,
                        target_external_id=target_external_id,
                        target_internal_id=CHARS[target].internal_id,
                    )
                    for record in selected
                ],
            }
        _write_suite(out_path, payload)
        written.append(out_path)
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--manifest",
        type=Path,
        required=True,
        help="Read-only replay manifest to select from.",
    )
    parser.add_argument(
        "--falcon-suite", type=Path, default=ROOT / "replays/suites/falcon_ranked.json"
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        required=True,
        help="Directory for newly built suites.",
    )
    parser.add_argument(
        "--per-stage",
        type=int,
        default=12,
        help="Number of selected games per legal stage (default: 12).",
    )
    parser.add_argument(
        "--source-bucket",
        type=str,
        default=None,
        help="optional ranked-corpus character bucket (for example GANONDORF)",
    )
    parser.add_argument(
        "--require-game-end",
        action="store_true",
        help="Exclude otherwise valid replay streams that do not publish a formal GameEnd event.",
    )
    parser.add_argument(
        "--minimum-frames",
        type=int,
        default=0,
        help="Exclude replay streams shorter than this many recorded frames.",
    )
    parser.add_argument(
        "--exclude-audit",
        action="append",
        type=Path,
        default=[],
        help="Corpus audit whose prior-corpus overlap paths should be excluded; repeatable.",
    )
    parser.add_argument(
        "--target",
        action="append",
        required=True,
        help="Character slug to build; repeatable.",
    )
    args = parser.parse_args()
    if args.per_stage <= 0 or args.minimum_frames < 0:
        parser.error("--per-stage must be positive and --minimum-frames must be non-negative")
    try:
        targets = _normalize_targets(args.target)
    except ValueError as error:
        parser.error(str(error))
    audit_targets = [target for target in targets if target != "falcon"]
    try:
        exclusions = (
            load_audit_exclusions(
                (path.resolve() for path in args.exclude_audit),
                targets=audit_targets,
            )
            if args.exclude_audit and audit_targets
            else {}
        )
        written = build_suites(
            manifest_path=args.manifest.resolve(),
            falcon_suite_path=args.falcon_suite.resolve(),
            out_dir=args.out_dir.resolve(),
            targets=targets,
            per_stage=args.per_stage,
            source_bucket=args.source_bucket,
            require_game_end=args.require_game_end,
            minimum_frames=args.minimum_frames,
            excluded_replays=exclusions,
        )
    except (OSError, ValueError) as error:
        parser.error(str(error))
    for path in written:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
