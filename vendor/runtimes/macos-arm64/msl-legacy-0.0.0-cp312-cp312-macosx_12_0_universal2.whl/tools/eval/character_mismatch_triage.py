from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from melee_sim._data_dir_override import native_data_dir_override
from tools.eval.validation_dtypes import COMPARE_DTYPE
from tools.extraction.char_registry import CHARS
from tools.slippi.motion_state_owners import read_callback_manifest, read_mslmso01_v1
from tools.slippi.slpz import replay_path_for_peppi
from tools.slippi.suite_io import repo_root
from tools.slippi.validation_buffer_builder import build_validation_buffers_from_slp


STANDARD_FIELDS = ("action_id", "animation_index", "on_ground", "hitlag", "hitstun", "state_flags")


def _run_one_step(
    buffers,
    *,
    chunk: int,
    ucf_enabled: bool,
    cardinals: bool,
    data_root: str | Path | None = None,
) -> np.ndarray:
    import msl_binding

    resolved_data_root = (
        repo_root() / "data" if data_root is None else Path(data_root).expanduser()
    ).resolve()
    with native_data_dir_override(msl_binding, resolved_data_root):
        handle = None
        records = buffers.num_records
        out = np.empty(records, dtype=COMPARE_DTYPE)
        seed = buffers.seed_u8()
        prev_input = buffers.prev_input_u8()
        cur_input = buffers.input_u8()
        capacity = min(max(1, int(chunk)), max(1, records))
        try:
            handle = msl_binding.init(
                batch_size=capacity,
                num_players=buffers.num_players,
                ucf_enabled=int(ucf_enabled),
                ucf_cardinals_1_0_enabled=int(cardinals),
            )
            for start in range(0, records, capacity):
                stop = min(records, start + capacity)
                count = stop - start
                seed_chunk = np.empty((capacity, seed.shape[1]), dtype=np.uint8)
                prev_chunk = np.empty((capacity, prev_input.shape[1]), dtype=np.uint8)
                cur_chunk = np.empty((capacity, cur_input.shape[1]), dtype=np.uint8)
                compare_chunk = np.empty((capacity, COMPARE_DTYPE.itemsize), dtype=np.uint8)
                seed_chunk[:count] = seed[start:stop]
                prev_chunk[:count] = prev_input[start:stop]
                cur_chunk[:count] = cur_input[start:stop]
                if count < capacity:
                    seed_chunk[count:] = seed_chunk[0]
                    prev_chunk[count:] = prev_chunk[0]
                    cur_chunk[count:] = cur_chunk[0]
                msl_binding.reseed_seed(handle, seed_chunk)
                msl_binding.step_input(handle, prev_chunk, cur_chunk)
                msl_binding.write_compare(handle, compare_chunk)
                out[start:stop] = compare_chunk.view(COMPARE_DTYPE).reshape(-1)[:count]
            return out
        finally:
            if handle is not None:
                msl_binding.destroy(handle)


def _owner_labels(data_root: Path, char_name: str) -> dict[int, str]:
    owners = read_mslmso01_v1(data_root / "motion_state" / "owners" / f"{char_name}.bin")
    symbols = read_callback_manifest(
        data_root / "motion_state" / "owners" / "callback_symbols.json"
    )
    result: dict[int, str] = {}
    for action_id in range(len(owners.anim_cb_id)):
        callbacks = []
        for label, ids in (
            ("anim", owners.anim_cb_id),
            ("iasa", owners.iasa_cb_id),
            ("phys", owners.phys_cb_id),
            ("coll", owners.coll_cb_id),
        ):
            callback_id = int(ids[action_id])
            symbol = symbols.get(callback_id)
            if symbol and symbol != "NULL":
                callbacks.append(f"{label}:{symbol}")
        result[action_id] = ", ".join(callbacks) or "no callbacks"
    return result


def _field_mask(out: np.ndarray, ref: np.ndarray, field: str, player: int) -> np.ndarray:
    if field == "state_flags":
        # RL1 gameplay profile ignores the replay-only high bit in byte four.
        out_flags = out[field][:, player].copy()
        ref_flags = ref[field][:, player].copy()
        out_flags[:, 4] &= np.uint8(0x7F)
        ref_flags[:, 4] &= np.uint8(0x7F)
        return np.any(out_flags != ref_flags, axis=1)
    return out[field][:, player] != ref[field][:, player]


def _counter_rows(counter: Counter, *, limit: int) -> list[dict[str, Any]]:
    return [
        {"count": int(count), **dict(zip(("seed_action", "ref_action", "out_action", "field"), key))}
        for key, count in counter.most_common(limit)
    ]


def _mismatch_example(
    *,
    replay: str,
    buffers,
    out: np.ndarray,
    ref: np.ndarray,
    index: int,
    player: int,
) -> dict[str, Any]:
    seed = buffers.seed_t[index]
    prev_input = buffers.prev_input_t["p"][index, player]
    cur_input = buffers.input_t["p"][index, player]
    hidden_fields = (
        "landing_fallspecial_allow_interrupt",
        "guard_reflect_timer_x14",
        "guard_reflect_timer_x18",
        "guard_reflect_origin_guardon_u8",
        "guard_special_enable_timer_x1c",
        "guard_release_latched_xc",
        "guard_x10",
        "lr_press_timer",
        "x672_input_timer",
        "pikachu_specialhi_timer_u8",
        "pikachu_specialhi_second_zip_u8",
        "pikachu_specialhi_cmd0_u8",
    )
    return {
        "replay": replay,
        "record_index": int(index),
        "frame_id": int(seed["frame_id"]),
        "player": int(player),
        "seed_action": int(seed["action_id"][player]),
        "reference_action": int(ref["action_id"][index, player]),
        "output_action": int(out["action_id"][index, player]),
        "seed_action_frame": int(seed["action_frame"][player]),
        "seed_anim_frame": float(seed["anim_frame_f32"][player]),
        "reference_action_frame": int(ref["action_frame"][index, player]),
        "output_action_frame": int(out["action_frame"][index, player]),
        "seed_animation_index": int(seed["animation_index"][player]),
        "reference_animation_index": int(ref["animation_index"][index, player]),
        "output_animation_index": int(out["animation_index"][index, player]),
        "on_ground": int(seed["on_ground"][player]),
        "ground_id": int(seed["ground_id"][player]),
        "previous_input": {
            name: int(prev_input[name]) for name in prev_input.dtype.names
        },
        "current_input": {name: int(cur_input[name]) for name in cur_input.dtype.names},
        "hidden": {name: int(seed[name][player]) for name in hidden_fields},
    }


def triage_suite(
    *, suite_path: Path, data_root: Path, char_name: str, char_id: int, chunk: int, limit: int
) -> dict[str, Any]:
    data_root = data_root.expanduser().resolve()
    suite = json.loads(suite_path.read_text(encoding="utf-8"))
    ucf_enabled = bool(suite.get("ucf_enabled", True))
    cardinals = bool(suite.get("ucf_cardinals_1_0_enabled", False))
    owners = _owner_labels(data_root, char_name)
    grouped: Counter = Counter()
    by_field: Counter = Counter()
    by_seed_action: Counter = Counter()
    state_flag_bits: Counter = Counter()
    examples_by_group: dict[tuple[int, int, int, str], list[dict[str, Any]]] = defaultdict(list)
    total_rows = 0
    mismatch_player_frames = 0
    replay_rows: list[dict[str, Any]] = []

    for entry in suite["replays"]:
        replay = (repo_root() / entry["replay"]).resolve()
        ports = [int(port) for port in entry.get("ports", [])] or None
        with replay_path_for_peppi(replay) as peppi_path:
            buffers = build_validation_buffers_from_slp(
                slp_path=str(peppi_path),
                ports=ports,
                ucf_enabled=ucf_enabled,
                ucf_cardinals_1_0_enabled=cardinals,
                data_root=data_root,
            )
        out = _run_one_step(
            buffers,
            chunk=chunk,
            ucf_enabled=ucf_enabled,
            cardinals=cardinals,
            data_root=data_root,
        )
        ref = buffers.ref_t1
        animation_index_recorded = not np.array_equal(
            ref["animation_index"][:, : buffers.num_players],
            ref["action_id"][:, : buffers.num_players].astype(np.uint32),
        )
        replay_fields = tuple(
            field
            for field in STANDARD_FIELDS
            if field != "animation_index" or animation_index_recorded
        )
        replay_mismatches = 0
        replay_char_frames = 0
        for player in range(buffers.num_players):
            char_rows = buffers.seed_t["char_id"][:, player] == np.uint8(char_id)
            replay_char_frames += int(np.count_nonzero(char_rows))
            if not np.any(char_rows):
                continue
            seed_actions = buffers.seed_t["action_id"][:, player]
            ref_actions = ref["action_id"][:, player]
            out_actions = out["action_id"][:, player]
            any_mismatch = np.zeros(buffers.num_records, dtype=bool)
            for field in replay_fields:
                mask = char_rows & _field_mask(out, ref, field, player)
                any_mismatch |= mask
                indices = np.flatnonzero(mask)
                by_field[field] += int(indices.size)
                for index in indices:
                    key = (
                        int(seed_actions[index]),
                        int(ref_actions[index]),
                        int(out_actions[index]),
                        field,
                    )
                    grouped[key] += 1
                    if len(examples_by_group[key]) < 3:
                        examples_by_group[key].append(
                            _mismatch_example(
                                replay=entry["replay"],
                                buffers=buffers,
                                out=out,
                                ref=ref,
                                index=int(index),
                                player=player,
                            )
                        )
                    if field == "state_flags":
                        ref_flags = ref[field][index, player]
                        out_flags = out[field][index, player]
                        for byte_index, differing in enumerate(ref_flags ^ out_flags):
                            for bit_index in range(8):
                                bit = 1 << bit_index
                                if int(differing) & bit:
                                    state_flag_bits[
                                        (
                                            int(seed_actions[index]),
                                            byte_index,
                                            bit_index,
                                            int(bool(int(ref_flags[byte_index]) & bit)),
                                            int(bool(int(out_flags[byte_index]) & bit)),
                                        )
                                    ] += 1
            mismatch_indices = np.flatnonzero(char_rows & any_mismatch)
            replay_mismatches += int(mismatch_indices.size)
            mismatch_player_frames += int(mismatch_indices.size)
            for index in mismatch_indices:
                by_seed_action[int(seed_actions[index])] += 1
        total_rows += replay_char_frames
        replay_rows.append(
            {
                "replay": entry["replay"],
                "target_player_frames": replay_char_frames,
                "mismatch_player_frames": replay_mismatches,
                "mismatch_rate": replay_mismatches / replay_char_frames if replay_char_frames else 0.0,
                "animation_index_recorded": animation_index_recorded,
                "compared_fields": list(replay_fields),
            }
        )

    top_actions = []
    for action_id, count in by_seed_action.most_common(limit):
        top_actions.append(
            {
                "seed_action": action_id,
                "count": int(count),
                "owner": owners.get(action_id, "action outside owner table"),
            }
        )
    return {
        "suite": str(suite_path),
        "character": {"name": char_name, "internal_id": char_id},
        "target_player_frames": total_rows,
        "mismatch_player_frames": mismatch_player_frames,
        "mismatch_player_frame_rate": mismatch_player_frames / total_rows if total_rows else 0.0,
        "field_mismatch_counts": dict(by_field.most_common()),
        "state_flag_bit_mismatches": [
            {
                "count": int(count),
                "seed_action": int(key[0]),
                "byte_index": int(key[1]),
                "bit_index": int(key[2]),
                "reference_bit": int(key[3]),
                "output_bit": int(key[4]),
            }
            for key, count in state_flag_bits.most_common(limit)
        ],
        "top_seed_actions": top_actions,
        "top_action_transitions_by_field": _counter_rows(grouped, limit=limit),
        "top_action_transition_examples": [
            {
                "count": int(count),
                **dict(zip(("seed_action", "ref_action", "out_action", "field"), key)),
                "examples": examples_by_group[key],
            }
            for key, count in grouped.most_common(limit)
        ],
        "replays": replay_rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Attribute one-step mismatches to one character.")
    parser.add_argument("--suite", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, default=Path("data"))
    parser.add_argument("--character", choices=sorted(CHARS), default="falcon")
    parser.add_argument(
        "--character-id",
        type=int,
        help="Override the registry internal ID for diagnostic use.",
    )
    parser.add_argument("--chunk", type=int, default=4096)
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    payload = triage_suite(
        suite_path=args.suite.resolve(),
        data_root=args.data_root.resolve(),
        char_name=args.character,
        char_id=(
            args.character_id
            if args.character_id is not None
            else CHARS[args.character].internal_id
        ),
        chunk=args.chunk,
        limit=args.limit,
    )
    text = json.dumps(payload, indent=2) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with args.out.open("w", encoding="utf-8", newline="\n") as f:
            f.write(text)
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
