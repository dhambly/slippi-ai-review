from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
from collections import Counter
from pathlib import Path
from typing import Any

from tools.eval.character_mismatch_triage import _owner_labels
from tools.eval.run_rollout_suite_eval import standard_rollout_fields
from tools.eval.streaming_validation import (
    default_players,
    scan_validation_buffers_with_native_float_rows,
)
from tools.extraction.char_registry import CHARS
from tools.slippi.slpz import replay_path_for_peppi
from tools.slippi.suite_io import repo_root
from tools.slippi.validation_buffer_builder import build_validation_buffers_from_slp


def _replay_task(task: dict[str, Any]) -> dict[str, Any]:
    replay = Path(str(task["replay"])).resolve()
    with replay_path_for_peppi(replay) as peppi_path:
        buffers = build_validation_buffers_from_slp(
            slp_path=str(peppi_path),
            ports=[int(port) for port in task["ports"]],
            ucf_enabled=bool(task["ucf_enabled"]),
            ucf_cardinals_1_0_enabled=bool(task["ucf_cardinals_1_0_enabled"]),
        )

    streaks, _float_rows, first_rows = scan_validation_buffers_with_native_float_rows(
        dataset_path=replay,
        buffers=buffers,
        fields=standard_rollout_fields(),
        players=default_players(buffers, None),
        max_records=0,
        ucf_enabled=bool(task["ucf_enabled"]),
        ucf_cardinals_1_0_enabled=bool(task["ucf_cardinals_1_0_enabled"]),
        profile="rl1_gameplay",
        first_mismatch_probe_limit=max(1, int(buffers.num_records) * buffers.num_players * 2),
    )

    target_id = int(task["character_id"])
    annotated: list[dict[str, Any]] = []
    for row in first_rows:
        record = int(row["record"])
        player = int(row["player"])
        ref_record = min(record + 1, int(buffers.num_records) - 1)
        seed_action = int(buffers.seed_t["action_id"][record, player])
        ref_action = int(buffers.ref_t1["action_id"][record, player])
        field = str(row["field"])
        annotated.append(
            {
                **dict(row),
                "target_character": bool(
                    int(buffers.seed_t["char_id"][record, player]) == target_id
                ),
                "seed_action": seed_action,
                "ref_action": ref_action,
                # action_id is the first rollout comparison lane. If another lane is the first
                # mismatch, the output action necessarily matched the reference action.
                "out_action": int(row["out"]) if field == "action_id" else ref_action,
                "seed_action_frame": int(buffers.seed_t["action_frame"][record, player]),
                "seed_anim_frame": float(buffers.seed_t["anim_frame_f32"][record, player]),
                "seed_frame_speed_mul": float(
                    buffers.seed_t["frame_speed_mul_f32"][record, player]
                ),
                "ref_action_frame": int(buffers.ref_t1["action_frame"][record, player]),
                "ref_anim_frame": float(
                    buffers.seed_t["anim_frame_f32"][ref_record, player]
                ),
            }
        )

    return {
        "replay": str(task["replay_label"]),
        "records": int(buffers.num_records),
        "first_mismatch_total": int(sum(streaks.first_mismatch_field_counts.values())),
        "first_mismatch_seeded_total": int(
            sum(streaks.first_mismatch_field_counts_seeded.values())
        ),
        "rows": annotated,
    }


def _counter_rows(
    counter: Counter[tuple[Any, ...]], names: tuple[str, ...], *, limit: int
) -> list[dict[str, Any]]:
    return [
        {"count": int(count), **dict(zip(names, key, strict=True))}
        for key, count in counter.most_common(limit)
    ]


def triage_suite(
    *,
    suite_path: Path,
    data_root: Path,
    char_name: str,
    char_id: int,
    workers: int,
    limit: int,
) -> dict[str, Any]:
    suite = json.loads(suite_path.read_text(encoding="utf-8"))
    root = repo_root()
    tasks = []
    for entry in suite["replays"]:
        replay = (root / entry["replay"]).resolve()
        tasks.append(
            {
                "replay": str(replay),
                "replay_label": entry["replay"],
                "ports": entry.get("ports", []),
                "ucf_enabled": bool(suite.get("ucf_enabled", True)),
                "ucf_cardinals_1_0_enabled": bool(
                    suite.get("ucf_cardinals_1_0_enabled", False)
                ),
                "character_id": int(char_id),
            }
        )

    worker_count = max(1, min(int(workers), len(tasks))) if tasks else 1
    if worker_count == 1:
        replay_results = [_replay_task(task) for task in tasks]
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=worker_count) as executor:
            replay_results = list(executor.map(_replay_task, tasks))

    owners = _owner_labels(data_root, char_name)
    target_action: Counter[int] = Counter()
    target_field: Counter[str] = Counter()
    target_transition: Counter[tuple[Any, ...]] = Counter()
    target_seeded_action: Counter[int] = Counter()
    target_first_rows: list[dict[str, Any]] = []
    target_first_total = 0
    target_seeded_total = 0
    all_first_total = 0
    all_seeded_total = 0

    per_replay: list[dict[str, Any]] = []
    for result in replay_results:
        replay_target = 0
        replay_target_seeded = 0
        for row in result.pop("rows"):
            seeded = bool(row["seeded_break"])
            if seeded:
                all_seeded_total += 1
            else:
                all_first_total += 1
            if not bool(row["target_character"]):
                continue
            action = int(row["seed_action"])
            if seeded:
                target_seeded_total += 1
                replay_target_seeded += 1
                target_seeded_action[action] += 1
                continue
            target_first_total += 1
            replay_target += 1
            target_action[action] += 1
            target_field[str(row["field"])] += 1
            target_transition[
                (
                    action,
                    int(row["ref_action"]),
                    int(row["out_action"]),
                    str(row["field"]),
                    int(row["seed"]),
                    int(row["ref"]),
                    int(row["out"]),
                )
            ] += 1
            target_first_rows.append({"replay": result["replay"], **dict(row)})
        per_replay.append(
            {
                **result,
                "target_first_mismatch_total": replay_target,
                "target_first_mismatch_seeded_total": replay_target_seeded,
            }
        )

    def action_rows(counter: Counter[int]) -> list[dict[str, Any]]:
        return [
            {
                "seed_action": int(action),
                "count": int(count),
                "owner": owners.get(int(action), "action outside owner table"),
            }
            for action, count in counter.most_common(limit)
        ]

    return {
        "suite": str(suite_path),
        "character": {"name": char_name, "internal_id": int(char_id)},
        "replays": len(replay_results),
        "records": int(sum(int(result["records"]) for result in replay_results)),
        "all_first_mismatch_total": all_first_total,
        "all_first_mismatch_seeded_total": all_seeded_total,
        "target_first_mismatch_total": target_first_total,
        "target_first_mismatch_seeded_total": target_seeded_total,
        "opponent_first_mismatch_total": all_first_total - target_first_total,
        "opponent_first_mismatch_seeded_total": all_seeded_total - target_seeded_total,
        "target_first_mismatch_fields": dict(target_field.most_common()),
        "top_target_seed_actions": action_rows(target_action),
        "top_target_seeded_actions": action_rows(target_seeded_action),
        "top_target_transitions": _counter_rows(
            target_transition,
            (
                "seed_action",
                "ref_action",
                "out_action",
                "field",
                "seed_value",
                "ref_value",
                "out_value",
            ),
            limit=limit,
        ),
        "target_first_mismatch_rows": target_first_rows,
        "per_replay": per_replay,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Attribute rollout first breaks to one character.")
    parser.add_argument("--suite", type=Path, required=True)
    parser.add_argument("--data-root", type=Path, default=Path("data"))
    parser.add_argument("--character", choices=sorted(CHARS), default="falcon")
    parser.add_argument("--character-id", type=int)
    parser.add_argument("--workers", type=int, default=min(4, int(os.cpu_count() or 1)))
    parser.add_argument("--limit", type=int, default=80)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()

    payload = triage_suite(
        suite_path=args.suite.resolve(),
        data_root=args.data_root.resolve(),
        char_name=args.character,
        char_id=(
            int(args.character_id)
            if args.character_id is not None
            else CHARS[args.character].internal_id
        ),
        workers=args.workers,
        limit=args.limit,
    )
    text = json.dumps(payload, indent=2) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with args.out.open("w", encoding="utf-8", newline="\n") as f:
            f.write(text)
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
