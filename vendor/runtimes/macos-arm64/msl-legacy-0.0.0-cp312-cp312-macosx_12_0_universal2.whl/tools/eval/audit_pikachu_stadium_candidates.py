"""Write a parser-backed Pokemon Stadium eligibility ledger for the Pikachu ranked lane."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from peppi_py import _read_slippi


TARGET_EXTERNAL_ID = 13
STADIUM_ID = 3
# These are the metadata opponent ids carried by the PIKACHU shard's original-five candidates.
# Post-frame character kinds, not this metadata, decide support below.
ORIGINAL_FIVE_METADATA_IDS = {0, 7, 9, 16}
SUPPORTED_INTERNAL_IDS = {1, 2, 7, 12, 18, 22}


def _post_character_ids(game, port: int) -> list[int]:
    ports = game.frames.field("ports")
    values = ports.field(f"P{port}").field("leader").field("post").field("character")
    array = values.to_numpy(zero_copy_only=False)
    if isinstance(array, np.ma.MaskedArray):
        array = array.compressed()
    return sorted(set(np.asarray(array, dtype=np.uint8).tolist()))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--corpus-root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    entries = []
    for record in manifest["replays"]:
        ids = {int(port): int(char_id) for port, char_id in record["character_ids"].items()}
        opponents = [value for value in ids.values() if value != TARGET_EXTERNAL_ID]
        if (
            record.get("bucket") != "PIKACHU"
            or int(record["stage_id"]) != STADIUM_ID
            or TARGET_EXTERNAL_ID not in ids.values()
            or len(ids) != 2
            or len(opponents) != 1
            or opponents[0] not in ORIGINAL_FIVE_METADATA_IDS
        ):
            continue

        result = {
            "member_name": record["member_name"],
            "replay": record["replay"],
            "metadata_character_ids": ids,
            "ports": record["ports"],
            "ucf_enabled": True,
            "ucf_cardinals_1_0_enabled": False,
        }
        try:
            game = _read_slippi(str(args.corpus_root / record["replay"]), False)
            if game.frames is None:
                raise ValueError("missing frames")
            post_ids = {str(port): _post_character_ids(game, int(port)) for port in record["ports"]}
            result["post_character_ids"] = post_ids
            result["frame_count"] = int(len(game.frames))
            actual_ids = set().union(*(set(value) for value in post_ids.values()))
            if result["frame_count"] <= 0:
                result["decision"] = "reject"
                result["reason"] = "invalid_frames"
            elif not actual_ids.issubset(SUPPORTED_INTERNAL_IDS):
                result["decision"] = "reject"
                result["reason"] = "unsupported_transformed_character"
            elif 12 not in actual_ids:
                result["decision"] = "reject"
                result["reason"] = "target_absent_from_post_frames"
            else:
                result["decision"] = "selectable"
                result["reason"] = "valid_supported_post_frames"
        except Exception as exc:  # Parser failures belong in the artifact, not an omitted row.
            result["decision"] = "reject"
            result["reason"] = "parser_failure"
            result["error"] = f"{type(exc).__name__}: {exc}"
        entries.append(result)

    entries.sort(key=lambda row: row["member_name"])
    payload = {
        "name": "pikachu_stadium_candidate_ledger",
        "selection_rule": "Pikachu bucket, Stadium metadata, original-five metadata opponent ids; post frames are authoritative.",
        "candidate_count": len(entries),
        "selectable_count": sum(row["decision"] == "selectable" for row in entries),
        "entries": entries,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
