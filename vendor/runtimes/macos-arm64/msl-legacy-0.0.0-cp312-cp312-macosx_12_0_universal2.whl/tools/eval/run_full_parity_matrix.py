from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from tools.extraction.char_registry import CHARS
from tools.eval.parity_provenance import canonical_data_root, global_provenance, preflight_suite
from tools.slippi.suite_io import repo_root


ESTABLISHED_CHARACTERS = ("fox", "falco", "marth", "sheik", "falcon")
DEFAULT_SUITES = {
    "fox": Path("replays/suites/parity_fox_ranked.json"),
    "falco": Path("replays/suites/parity_falco_ranked.json"),
    "marth": Path("replays/suites/parity_marth_ranked.json"),
    "sheik": Path("replays/suites/parity_sheik_ranked.json"),
    "falcon": Path("replays/suites/parity_falcon_ranked.json"),
    "ganon": Path("replays/suites/parity_ganon_ranked.json"),
    "puff": Path("replays/suites/parity_puff_ranked.json"),
    "pikachu": Path("replays/suites/parity_pikachu_ranked.json"),
    "samus": Path("replays/suites/parity_samus_ranked.json"),
    "peach": Path("replays/suites/parity_peach_ranked.json"),
    "yoshi": Path("replays/suites/parity_yoshi_ranked.json"),
}


@dataclass(frozen=True)
class MatrixResult:
    character: str
    report: dict[str, Any]
    elapsed_seconds: float
    baseline_rate: float | None
    suite_identity: str | None = None
    suite_manifest_sha256: str | None = None
    selected_replay_content_sha256: str | None = None
    baseline_label: str = "NO MATCHED BASELINE"


def _load_baselines(path: Path | None) -> dict[str, dict[str, Any]]:
    if path is None:
        return {}
    payloads: dict[str, dict[str, Any]] = {}
    for character in DEFAULT_SUITES:
        report_path = path / f"{character}.json"
        if report_path.is_file():
            payloads[character] = json.loads(report_path.read_text(encoding="utf-8"))
    return payloads


def _parse_suite_overrides(values: Iterable[str]) -> dict[str, Path]:
    overrides: dict[str, Path] = {}
    for value in values:
        character, separator, raw_path = value.partition("=")
        character = character.strip().lower()
        if separator != "=" or not raw_path.strip():
            raise ValueError(f"Invalid suite override {value!r}; expected CHARACTER=PATH")
        if character not in DEFAULT_SUITES:
            raise ValueError(f"Unknown suite override character: {character}")
        overrides[character] = Path(raw_path.strip())
    return overrides


def _resolve_suite_path(path: Path) -> Path:
    return path.resolve() if path.is_absolute() else (repo_root() / path).resolve()


def _baseline_for_suite(
    baseline: dict[str, Any] | None,
    manifest_sha256: str,
    selected_replay_content_sha256: str,
) -> tuple[float | None, str]:
    if baseline is None:
        return None, "NO MATCHED BASELINE"
    provenance = baseline.get("provenance")
    suite = provenance.get("suite") if isinstance(provenance, dict) else None
    baseline_manifest_sha256 = suite.get("manifest_sha256") if isinstance(suite, dict) else None
    baseline_replay_sha256 = (
        suite.get("selected_replay_content_sha256") if isinstance(suite, dict) else None
    )
    if (
        baseline_manifest_sha256 != manifest_sha256
        or baseline_replay_sha256 != selected_replay_content_sha256
    ):
        return None, "INCOMPARABLE CORPUS"
    return float(baseline["full_gameplay_mismatch_rate"]), "SAME-SUITE BASELINE"


def _historical_policy_band(
    baselines: dict[str, dict[str, Any]], suite_provenance: dict[str, dict[str, Any]]
) -> float | None:
    rates = [
        rate
        for character in ESTABLISHED_CHARACTERS
        if character in suite_provenance
        for rate, _label in [
            _baseline_for_suite(
                baselines.get(character),
                str(suite_provenance[character]["manifest_sha256"]),
                str(suite_provenance[character]["selected_replay_content_sha256"]),
            )
        ]
        if rate is not None
    ]
    return max(rates) if rates else None


def _rate(value: float | None) -> str:
    return "-" if value is None else f"{100.0 * value:.4f}%"


def _article_rate(report: dict[str, Any]) -> float | None:
    if int(report["article_relevant_frames"]) == 0:
        return None
    return float(report["article_core_mismatch_rate"])


def _status(
    result: MatrixResult,
    *,
    established_ceiling: float | None,
    regression_tolerance: float,
) -> str:
    rate = float(result.report["full_gameplay_mismatch_rate"])
    if result.character in ESTABLISHED_CHARACTERS:
        if result.baseline_rate is None:
            return result.baseline_label
        return "PASS" if rate <= result.baseline_rate + regression_tolerance else "REGRESSION"
    if established_ceiling is None:
        return "NO TARGET"
    return "PASS" if rate <= established_ceiling else "ABOVE BAND"


def render_markdown(
    results: Iterable[MatrixResult],
    *,
    established_ceiling: float | None,
    regression_tolerance: float,
    total_elapsed_seconds: float,
    provenance: dict[str, Any] | None = None,
) -> str:
    rows = list(results)
    lines = [
        "# Full Character Parity Matrix",
        "",
        (
            "The gameplay score combines target-fighter gameplay fields with character-owned "
            "article lifecycle/state fields. Bookkeeping and article payload fields remain "
            "visible separately."
        ),
        "",
        f"Historical policy band (cross-character): {_rate(established_ceiling)}",
        f"Total wall time: {total_elapsed_seconds:.2f}s",
    ]
    if provenance is not None:
        lines.extend(
            (
                "",
                "## Provenance",
                f"- Git HEAD: `{provenance['git']['head']}`",
                f"- Git dirty: `{provenance['git']['dirty']}`",
                f"- Git tracked diff SHA256: `{provenance['git']['diff_sha256']}`",
                (
                    "- Git untracked path/content SHA256: "
                    f"`{provenance['git']['untracked_sha256']}` "
                    f"({provenance['git']['untracked_files']} files, "
                    f"{provenance['git']['untracked_bytes']} bytes)"
                ),
                (
                    "- Native: "
                    f"`{provenance['native']['path']}` SHA256 "
                    f"`{provenance['native']['sha256']}` "
                    f"({provenance['native']['size']} bytes, "
                    f"mtime_ns {provenance['native']['mtime_ns']})"
                ),
                (
                    "- Evaluator: "
                    f"`{provenance['evaluator']['path']}` "
                    f"SHA256 `{provenance['evaluator']['sha256']}`"
                ),
                (
                    "- Data: "
                    f"`{provenance['data']['path']}` SHA256 `{provenance['data']['sha256']}` "
                    f"({provenance['data']['files']} files, "
                    f"{provenance['data']['total_bytes']} bytes)"
                ),
                (
                    "- Data manifest: "
                    f"`{provenance['data']['manifest']['path']}` SHA256 "
                    f"`{provenance['data']['manifest']['sha256']}`"
                ),
            )
        )
    suite_rows = [result for result in rows if result.suite_identity is not None]
    if suite_rows:
        lines.extend(("", "Suite identities:"))
        lines.extend(
            (
                f"- {result.character}: `{result.suite_identity}`; manifest SHA256 "
                f"`{result.suite_manifest_sha256 or 'unavailable'}`; selected replay-content "
                f"SHA256 `{result.selected_replay_content_sha256 or 'unavailable'}`"
            )
            for result in suite_rows
        )
    lines.extend(
        (
            "",
            (
                "| Character | Games | Fighter gameplay | Bookkeeping | Article core | "
                "Gameplay + article | Same-suite delta | Baseline match | Time | Status |"
            ),
            "|---|---:|---:|---:|---:|---:|---:|---|---:|---|",
        )
    )
    for result in rows:
        report = result.report
        current = float(report["full_gameplay_mismatch_rate"])
        delta = None if result.baseline_rate is None else current - result.baseline_rate
        delta_text = "-" if delta is None else f"{100.0 * delta:+.4f} pp"
        lines.append(
            "| "
            + " | ".join(
                (
                    result.character,
                    str(int(report["games"])),
                    _rate(float(report["fighter_gameplay_mismatch_rate"])),
                    _rate(float(report["fighter_bookkeeping_mismatch_rate"])),
                    _rate(_article_rate(report)),
                    _rate(current),
                    delta_text,
                    (
                        "SAME-SUITE BASELINE"
                        if result.baseline_rate is not None
                        else result.baseline_label
                    ),
                    f"{result.elapsed_seconds:.2f}s",
                    _status(
                        result,
                        established_ceiling=established_ceiling,
                        regression_tolerance=regression_tolerance,
                    ),
                )
            )
            + " |"
        )
    lines.append("")
    return "\n".join(lines)


def run_matrix(
    *,
    characters: Iterable[str],
    out_dir: Path,
    baseline_dir: Path | None,
    data_root: Path,
    item_kind_header: Path,
    chunk: int,
    limit: int,
    regression_tolerance: float,
    suite_paths: dict[str, Path] | None = None,
    jobs: int = 1,
) -> tuple[list[MatrixResult], str, bool]:
    data_root = canonical_data_root(data_root)
    baselines = _load_baselines(baseline_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    results: list[MatrixResult] = []
    matrix_started = time.perf_counter()

    character_list = tuple(characters)
    selected_suites = {
        character: _resolve_suite_path((suite_paths or {}).get(character, DEFAULT_SUITES[character]))
        for character in character_list
    }
    # Complete this phase before launching any evaluator so a late invalid suite cannot
    # leave the matrix with a partial set of reports.
    suite_provenance = {
        character: preflight_suite(suite, root=repo_root())
        for character, suite in selected_suites.items()
    }
    shared_provenance = global_provenance(
        data_root=data_root,
        evaluator_path=Path(__file__).with_name("character_full_parity_triage.py"),
        root=repo_root(),
    )
    ceiling = _historical_policy_band(baselines, suite_provenance)
    total = len(character_list)

    def _run_one(index: int, character: str) -> MatrixResult:
        suite = selected_suites[character]
        report_path = out_dir / f"{character}.json"
        print(
            f"[{index}/{total}] {character}: {suite}",
            file=sys.stderr,
            flush=True,
        )
        started = time.perf_counter()
        command = [
            sys.executable,
            "-m",
            "tools.eval.character_full_parity_triage",
            "--suite",
            str(suite),
            "--data-root",
            str(data_root),
            "--character",
            character,
            "--character-id",
            str(int(CHARS[character].internal_id)),
            "--chunk",
            str(chunk),
            "--limit",
            str(limit),
            "--item-kind-header",
            str(item_kind_header),
            "--out",
            str(report_path),
        ]
        completed = subprocess.run(
            command,
            cwd=repo_root(),
            check=False,
            capture_output=True,
            text=True,
        )
        elapsed = time.perf_counter() - started
        if completed.returncode != 0:
            detail = completed.stderr.strip() or completed.stdout.strip() or "no process output"
            raise RuntimeError(
                f"{character} parity process failed with exit {completed.returncode}: {detail}"
            )
        report = json.loads(report_path.read_text(encoding="utf-8"))
        report["suite"] = str(suite_provenance[character]["path"])
        report["provenance"] = {
            "schema_version": 1,
            "suite": suite_provenance[character],
            "global": shared_provenance,
        }
        report_path.write_text(
            json.dumps(report, indent=2, sort_keys=True), encoding="utf-8", newline="\n"
        )
        print(f"[{index}/{total}] {character}: {elapsed:.2f}s", file=sys.stderr)
        baseline_rate, baseline_label = _baseline_for_suite(
            baselines.get(character),
            str(suite_provenance[character]["manifest_sha256"]),
            str(suite_provenance[character]["selected_replay_content_sha256"]),
        )
        return MatrixResult(
            character=character,
            report=report,
            elapsed_seconds=elapsed,
            baseline_rate=baseline_rate,
            suite_identity=str(suite_provenance[character]["path"]),
            suite_manifest_sha256=str(suite_provenance[character]["manifest_sha256"]),
            selected_replay_content_sha256=str(
                suite_provenance[character]["selected_replay_content_sha256"]
            ),
            baseline_label=baseline_label,
        )

    # Each character is an independent subprocess; run up to `jobs` concurrently.
    # subprocess.run releases the GIL, so a thread pool yields true parallelism.
    workers = max(1, min(jobs, total))
    if workers == 1:
        results = [_run_one(i, c) for i, c in enumerate(character_list, start=1)]
    else:
        indexed: dict[str, MatrixResult] = {}
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(_run_one, i, c): c
                for i, c in enumerate(character_list, start=1)
            }
            for fut in as_completed(futures):
                res = fut.result()
                indexed[res.character] = res
        # preserve matrix (character_list) ordering for the rendered report
        results = [indexed[c] for c in character_list]

    total_elapsed = time.perf_counter() - matrix_started
    summary = render_markdown(
        results,
        established_ceiling=ceiling,
        regression_tolerance=regression_tolerance,
        total_elapsed_seconds=total_elapsed,
        provenance=shared_provenance,
    )
    (out_dir / "README.md").write_text(summary, encoding="utf-8", newline="\n")
    failed = any(
        _status(
            result,
            established_ceiling=ceiling,
            regression_tolerance=regression_tolerance,
        )
        in {"REGRESSION", "ABOVE BAND", "INCOMPARABLE CORPUS", "NO MATCHED BASELINE"}
        for result in results
    )
    return results, summary, failed


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run the repeatable fighter-plus-article parity matrix."
    )
    parser.add_argument(
        "--character",
        action="append",
        choices=tuple(DEFAULT_SUITES),
        help="Character to run; repeat as needed. Defaults to all ten in matrix order.",
    )
    parser.add_argument("--out-dir", type=Path, default=Path("reports/full_parity_current"))
    parser.add_argument(
        "--baseline-dir", type=Path, default=Path("reports/full_parity_baseline")
    )
    parser.add_argument("--data-root", type=Path, default=Path("data"))
    parser.add_argument(
        "--item-kind-header", type=Path, default=Path("refs/melee/src/melee/it/forward.h")
    )
    parser.add_argument("--chunk", type=int, default=4096)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument(
        "--suite",
        action="append",
        default=[],
        metavar="CHARACTER=PATH",
        help="Override a character's replay suite without changing the built-in baseline mapping.",
    )
    parser.add_argument(
        "--regression-tolerance",
        type=float,
        default=0.0,
        help="Allowed absolute mismatch-rate increase for the established characters.",
    )
    parser.add_argument(
        "--enforce",
        action="store_true",
        help=(
            "Exit nonzero on an established regression, a missing or incomparable established "
            "baseline, or a new character above the policy band."
        ),
    )
    parser.add_argument(
        "--jobs",
        "-j",
        type=int,
        default=1,
        help="Number of characters to evaluate concurrently (each is an independent subprocess).",
    )
    args = parser.parse_args()
    characters = tuple(args.character or DEFAULT_SUITES)
    _, summary, failed = run_matrix(
        characters=characters,
        out_dir=args.out_dir.resolve(),
        baseline_dir=args.baseline_dir.resolve(),
        data_root=(
            args.data_root if args.data_root.is_absolute() else repo_root() / args.data_root
        ),
        item_kind_header=args.item_kind_header.resolve(),
        chunk=int(args.chunk),
        limit=int(args.limit),
        regression_tolerance=float(args.regression_tolerance),
        suite_paths=_parse_suite_overrides(args.suite),
        jobs=int(args.jobs),
    )
    print(summary, end="")
    return 1 if args.enforce and failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
