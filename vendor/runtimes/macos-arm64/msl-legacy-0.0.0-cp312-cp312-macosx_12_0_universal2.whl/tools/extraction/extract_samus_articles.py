from __future__ import annotations

import argparse
import json
import struct
from pathlib import Path

from melee_sim.hsd_archive import parse_hsd_archive
from tools.extraction.extract_fighter_moves import (
    _decode_create_hitbox,
    _parse_subaction_events,
)
from tools.slippi.motion_state_owners import read_callback_manifest, read_mslmso01_v1


MAGIC = b"MSLSSAR1"
VERSION = 6

# ThrowN ("hand") joint local offset (facing-normalized x, y) at the AirCatch extend frame
# (action_frame 7 == grapple_extend_frame). The grapple beam launches from the ThrowN joint
# (refs/melee/src/melee/ft/chara/ftCommon/ftCo_AirCatch.c: lb_8000B1CC(fp->parts[FtPart_ThrowN])),
# but the samus AirCatch/AirCatchHit submotions (311/312) have no baked SSANIM01 collision matrix,
# so the runtime cannot resolve the animated hand and falls back to this fixed launch offset
# (see src/items_samus.c::ss_grapple_hand). The offset is an animation-fixed pose value; it was
# measured from the V14 RAM child-tip dumps (reports/oracle_dumps/samus): the flying tip launches
# at fighter_root + (facing*9.975, +9.06). A future full anim-pose extraction that bakes the
# AirCatch ThrowN matrix can replace this constant with the resolved joint.
GRAPPLE_LAUNCH_OFFSET_X = 9.975
GRAPPLE_LAUNCH_OFFSET_Y = 9.06

GRAPPLE_HITBOX_DOL_VA = 0x803B8660
GRAPPLE_HITBOX_RECORD_SIZE = 0x14

ARTICLE_HITBOX_FLAG_TARGET_GROUNDED = 1 << 0
ARTICLE_HITBOX_FLAG_TARGET_AERIAL = 1 << 1
ARTICLE_HITBOX_FLAG_BODY_ENABLED = 1 << 2
ARTICLE_HITBOX_FLAG_GRABBABLE_ONLY = 1 << 3
ARTICLE_HITBOX_FLAG_CLANK = 1 << 4

# Item kinds and Fighter_Part values are source enum constants, not archive attributes.
# refs/melee/src/melee/ft/chara/ftSamus/ftSs_Init.c::ftSs_Init_OnLoad
# refs/melee/src/melee/{it/forward.h,ft/forward.h}
SOURCE_U16 = {
    "bomb_kind": 93,
    "charge_kind": 94,
    "missile_kind": 95,
    "grapple_kind": 96,
    "charge_hold_part": 51,  # FtPart_RHandNb
    "charge_fire_part": 52,  # FtPart_ThrowN
    "missile_spawn_part": 56,  # FtPart_56
    "grapple_ground_spawn_part": 51,  # FtPart_RHandNb
    "grapple_spawn_part": 52,  # FtPart_ThrowN
    # ftSs_Submotion owners from the generated Init table. Runtime article callbacks consume
    # these identities instead of duplicating fighter action IDs.
    "charge_owner_ground_start": 297,
    "charge_owner_ground_hold": 298,
    "charge_owner_ground_fire": 300,
    "charge_owner_air_start": 301,
    "charge_owner_air_fire": 302,
}

GRAPPLE_OWNER_CALLBACK_FIELDS = {
    "grapple_owner_ground_catch_action": "ftCo_Catch_Anim",
    "grapple_owner_ground_catch_dash_action": "ftCo_CatchDash_Anim",
    "grapple_owner_aircatch_action": "ftCo_AirCatch_Anim",
    "grapple_owner_aircatch_hit_action": "ftCo_AirCatchHit_Anim",
}

GRAPPLE_OWNER_FIELDS = (
    "grapple_owner_aircatch",
    "grapple_owner_aircatch_hit",
    *GRAPPLE_OWNER_CALLBACK_FIELDS,
)

U16_FIELDS = (
    *SOURCE_U16,
    *GRAPPLE_OWNER_FIELDS,
    "bomb_lifetime_frames",
    "bomb_flash_start_frames",
    "charge_lifetime_frames",
    "missile_homing_lifetime_frames",
    "missile_homing_guidance_frames",
    "missile_smash_lifetime_frames",
    "missile_smash_accel_start_frames",
    "grapple_ground_spawn_frame",
    "grapple_ground_extend_frame",
    "grapple_ground_retract_frame",
    "grapple_ground_destroy_frame",
    "grapple_ground_dash_spawn_frame",
    "grapple_ground_dash_extend_frame",
    "grapple_ground_dash_retract_frame",
    "grapple_ground_dash_destroy_frame",
    "grapple_spawn_frame",
    "grapple_extend_frame",
    "grapple_retract_frame",
    "grapple_destroy_frame",
    "grapple_link_count_catch",
    "grapple_link_count_catch_dash",
    "grapple_link_count_aircatch",
    "grapple_swing_frames",
    "grapple_attr_xc",
    "grapple_attr_x34",
    "bomb_spawn_frame",
    "charge_spawn_frame",
    "charge_fire_frame",
    "missile_ground_normal_spawn_frame",
    "missile_ground_smash_spawn_frame",
    "missile_air_normal_spawn_frame",
    "missile_air_smash_spawn_frame",
    "destroyed_lifetime_frames",
    "bomb_explosion_size_frame_0",
    "bomb_explosion_size_frame_1",
    "bomb_explosion_remove_frame",
)

F32_FIELDS = (
    "bomb_flash_scale",
    "bomb_max_speed",
    "bomb_gravity",
    "bomb_terminal_velocity",
    "bomb_initial_velocity_y",
    "bomb_spawn_offset_x",
    "bomb_spawn_offset_y",
    "bomb_spawn_offset_z",
    "charge_air_recoil",
    "charge_speed_min",
    "charge_speed_max",
    "charge_damage_min",
    "charge_damage_max",
    "charge_scale_min",
    "charge_scale_max",
    "missile_spawn_offset_x",
    "missile_homing_speed",
    "missile_homing_slowdown",
    "missile_homing_min_speed",
    "missile_homing_turn_accel",
    "missile_homing_max_turn",
    "missile_homing_turn_threshold",
    "missile_smash_initial_speed",
    "missile_smash_accel",
    "missile_smash_max_speed",
    "grapple_pos_x_0",
    "grapple_pos_x_1",
    "grapple_ext_fallspecial_mul",
    "grapple_launch_offset_x",
    "grapple_launch_offset_y",
    "grapple_attr_x0",
    "grapple_attr_x4",
    "grapple_attr_x8",
    "grapple_attr_x10",
    "grapple_attr_x14",
    "grapple_attr_x18",
    "grapple_attr_x1c",
    "grapple_attr_x20",
    "grapple_attr_x24",
    "grapple_attr_x28",
    "grapple_attr_x2c",
    "grapple_attr_x30",
    "grapple_attr_x38",
    "grapple_attr_x3c",
    "grapple_attr_x40",
    "grapple_attr_x44",
    "grapple_attr_x48",
    "grapple_attr_x4c",
    "grapple_attr_x50",
    "grapple_attr_x54",
    "grapple_attr_x58",
    "grapple_attr_x5c",
    "grapple_attr_x60",
    "bomb_explosion_size_value_0",
    "bomb_explosion_size_value_1",
)


def _u32_be(buf: bytes, off: int) -> int:
    return int.from_bytes(buf[off : off + 4], "big", signed=False)


def _i32_be(buf: bytes, off: int) -> int:
    return int.from_bytes(buf[off : off + 4], "big", signed=True)


def _f32_be(buf: bytes, off: int) -> float:
    return struct.unpack_from(">f", buf, off)[0]


def _f32(v: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(v)))[0]


def _ptr(arc, off: int, label: str) -> int:
    raw = _u32_be(arc.buf, off)
    if raw == 0:
        raise ValueError(f"PlSs.dat has a null {label} pointer")
    out = arc.data_base + raw
    if out < arc.data_base or out + 4 > len(arc.buf):
        raise ValueError(f"PlSs.dat has an out-of-range {label} pointer")
    return out


def _dol_read_va(dol_path: Path, va: int, size: int) -> bytes:
    dol = dol_path.read_bytes()
    if len(dol) < 0x100:
        raise ValueError(f"{dol_path} is too small to be a GameCube DOL")
    sections = (
        (0x00, 0x48, 0x90, 7),
        (0x1C, 0x64, 0xAC, 11),
    )
    for file_base, addr_base, size_base, count in sections:
        for index in range(count):
            file_off = _u32_be(dol, file_base + index * 4)
            section_va = _u32_be(dol, addr_base + index * 4)
            section_size = _u32_be(dol, size_base + index * 4)
            if section_va <= va and va + size <= section_va + section_size:
                record_off = file_off + va - section_va
                if record_off + size > len(dol):
                    break
                return dol[record_off : record_off + size]
    raise ValueError(f"DOL virtual range 0x{va:08X}..0x{va + size:08X} is unavailable")


def _grapple_hitbox_record(dol_path: Path) -> tuple[bytes, dict]:
    record = _dol_read_va(dol_path, GRAPPLE_HITBOX_DOL_VA, GRAPPLE_HITBOX_RECORD_SIZE)
    words = [_u32_be(record, off) for off in range(0, GRAPPLE_HITBOX_RECORD_SIZE, 4)]
    hitbox = _decode_create_hitbox(words)
    parsed = {
        "hitbox_id": hitbox.hitbox_id,
        "hit_group": hitbox.hit_group,
        "bone": hitbox.bone,
        "use_common_bone_ids": hitbox.use_common_bone_ids,
        "damage": _f32(hitbox.damage),
        "size": _f32(hitbox.size),
        "x_offset": _f32(hitbox.x_offset),
        "y_offset": _f32(hitbox.y_offset),
        "z_offset": _f32(hitbox.z_offset),
        "angle": hitbox.angle,
        "kbg": hitbox.kbg,
        "wsk": hitbox.wsk,
        "bkb": hitbox.bkb,
        "element": hitbox.element,
        "shield_damage": hitbox.shield_damage,
        "sfx_severity": hitbox.sfx_severity,
        "sfx_kind": hitbox.sfx_kind,
        "hit_grounded": hitbox.hit_grounded,
        "hit_aerial": hitbox.hit_aerial,
        "item_hit_interaction": hitbox.item_hit_interaction,
        "ignore_thrown_fighters": hitbox.ignore_thrown_fighters,
        "ignore_fighter_scale": hitbox.ignore_fighter_scale,
        "clank": hitbox.clank,
        "rebound": hitbox.rebound,
        # it_802B7160 reads the custom record's x134_4 bit, not spawn_hitbox_0's
        # only_hit_grabbed field. PowerPC bitfield order maps x134_4 to byte 0x13 bit 3.
        "hit_grabbed_victim_only": bool(record[0x13] & 0x08),
    }
    return record, parsed


def _event_frame(moves: dict, msid: int, kind: str, *, cmd_idx: int | None = None) -> int:
    specials = moves.get("specials_by_msid")
    if not isinstance(specials, dict):
        raise ValueError("Samus moves JSON is missing specials_by_msid")
    row = specials.get(str(msid))
    if not isinstance(row, dict):
        raise ValueError(f"Samus moves JSON is missing special msid {msid}")
    frames: list[int] = []
    for ev in row.get("events", []):
        if not isinstance(ev, dict) or ev.get("kind") != kind:
            continue
        data = ev.get("data", {})
        if cmd_idx is not None and (
            not isinstance(data, dict)
            or int(data.get("idx", -1)) != cmd_idx
            or int(data.get("value", 0)) != 1
        ):
            continue
        frames.append(int(ev["frame"]))
    if len(frames) != 1:
        raise ValueError(
            f"expected one {kind} event for Samus msid {msid}, found {frames}"
        )
    return frames[0]


def _article_state_events(arc, article: int, state: int) -> list:
    states = _ptr(arc, article + 0x0C, "Article.xC_itemStates")
    script = _ptr(arc, states + state * 0x10 + 0x0C, f"ItemStateDesc[{state}].xC_script")
    return _parse_subaction_events(
        arc, script, max_frames=120, max_steps_per_frame=500, item_hitbox_layout=True
    )


def _first_hitbox(events: list, label: str) -> dict:
    for event in events:
        if event.kind == "create_hitbox" and isinstance(event.data.get("hitbox"), dict):
            hitbox = dict(event.data["hitbox"])
            return {
                "label": label,
                "damage": _f32(float(hitbox.get("damage", 0.0))),
                "size": _f32(float(hitbox.get("size", 0.0))),
                "angle": int(hitbox.get("angle", 0)),
                "kbg": int(hitbox.get("kbg", 0)),
                "wsk": int(hitbox.get("wsk", 0)),
                "bkb": int(hitbox.get("bkb", 0)),
                "shield_damage": int(hitbox.get("shield_damage", 0)),
                "element": int(hitbox.get("element", 0)),
                "flags": (
                    (ARTICLE_HITBOX_FLAG_TARGET_GROUNDED if hitbox.get("hit_grounded") else 0)
                    | (ARTICLE_HITBOX_FLAG_TARGET_AERIAL if hitbox.get("hit_aerial") else 0)
                    | (ARTICLE_HITBOX_FLAG_BODY_ENABLED if hitbox.get("item_body_enabled") else 0)
                    | (ARTICLE_HITBOX_FLAG_GRABBABLE_ONLY if hitbox.get("item_grabbable_only") else 0)
                    | (ARTICLE_HITBOX_FLAG_CLANK if hitbox.get("clank") else 0)
                ),
            }
    raise ValueError(f"{label} article state has no create_hitbox event")


def _grapple_owner_values(owners_path: Path, callbacks_path: Path) -> dict[str, int]:
    owners = read_mslmso01_v1(owners_path)
    callbacks = read_callback_manifest(callbacks_path)
    values: dict[str, int] = {}
    action_by_field: dict[str, int] = {}
    for field, symbol in GRAPPLE_OWNER_CALLBACK_FIELDS.items():
        matches = [
            action_id
            for action_id, callback_id in enumerate(owners.anim_cb_id)
            if callbacks.get(int(callback_id)) == symbol
        ]
        if len(matches) != 1:
            raise ValueError(
                f"expected one Samus motion-state owner for {symbol}, found {matches}"
            )
        action_by_field[field] = matches[0]
        values[field] = matches[0]
    values["grapple_owner_aircatch"] = int(
        owners.submotion_id[action_by_field["grapple_owner_aircatch_action"]]
    )
    values["grapple_owner_aircatch_hit"] = int(
        owners.submotion_id[action_by_field["grapple_owner_aircatch_hit_action"]]
    )
    return values


def extract(
    plss_path: Path,
    main_dol_path: Path,
    moves_path: Path,
    item_common_path: Path,
    owners_path: Path,
    callbacks_path: Path,
) -> tuple[dict[str, int], dict[str, float], list[dict], bytes, dict]:
    buf = plss_path.read_bytes()
    arc = parse_hsd_archive(buf)
    ftdata = arc.get_public_offset("ftDataSamus")
    if ftdata is None:
        raise ValueError("PlSs.dat is missing public symbol ftDataSamus")
    items = _ptr(arc, ftdata + 0x48, "ftData.x48_items")
    ext = _ptr(arc, ftdata + 0x04, "ftData.ext_attr")

    article_names = ("bomb", "charge", "missile", "grapple")
    articles: dict[str, tuple[int, int, int]] = {}
    raw_special: dict[str, list[float | int]] = {}
    special_sizes = (0x1C, 0x20, 0x40, 0x64)
    integer_offsets = {"charge": {0x04}, "grapple": {0x0C, 0x34}}
    for index, name in enumerate(article_names):
        article = _ptr(arc, items + index * 4, f"ftData.x48_items[{index}]")
        common = _ptr(arc, article + 0x00, f"{name} Article.x0_common_attr")
        special = _ptr(arc, article + 0x04, f"{name} Article.x4_specialAttributes")
        articles[name] = (article, common, special)
        ints = integer_offsets.get(name, set())
        raw_special[name] = [
            _u32_be(buf, special + off) if off in ints else _f32_be(buf, special + off)
            for off in range(0, special_sizes[index], 4)
        ]

    bomb_common = articles["bomb"][1]
    bomb = articles["bomb"][2]
    charge = articles["charge"][2]
    missile = articles["missile"][2]
    grapple = articles["grapple"][2]
    moves = json.loads(moves_path.read_text(encoding="utf-8"))
    item_common = json.loads(item_common_path.read_text(encoding="utf-8"))
    grapple_hitbox_record, grapple_hitbox = _grapple_hitbox_record(main_dol_path)

    bomb_spawn_ground = _event_frame(moves, 309, "set_throw_spawn_projectile")
    bomb_spawn_air = _event_frame(moves, 310, "set_throw_spawn_projectile")
    charge_spawn_ground = _event_frame(moves, 297, "set_cmd_var", cmd_idx=0)
    charge_spawn_air = _event_frame(moves, 301, "set_cmd_var", cmd_idx=0)
    charge_fire_ground = _event_frame(moves, 300, "set_cmd_var", cmd_idx=1)
    charge_fire_air = _event_frame(moves, 302, "set_cmd_var", cmd_idx=1)
    if bomb_spawn_ground != bomb_spawn_air:
        raise ValueError("ground/air Bomb spawn frames differ; bump the Samus article schema")
    if charge_spawn_ground != charge_spawn_air or charge_fire_ground != charge_fire_air:
        raise ValueError("ground/air Charge Shot command frames differ; bump the schema")

    bomb_active_events = _article_state_events(arc, articles["bomb"][0], 0)
    # ItemStateTable state 3 selects article animation/script id 1.
    # refs/melee/src/melee/it/items/itsamusbomb.c::it_803F7220
    bomb_explosion_events = _article_state_events(arc, articles["bomb"][0], 1)
    missile_normal_events = _article_state_events(arc, articles["missile"][0], 0)
    missile_smash_events = _article_state_events(arc, articles["missile"][0], 1)
    charge_events = [
        _article_state_events(arc, articles["charge"][0], state) for state in range(1, 9)
    ]
    hitboxes = [
        _first_hitbox(bomb_active_events, "bomb_active"),
        _first_hitbox(bomb_explosion_events, "bomb_explosion"),
        _first_hitbox(missile_normal_events, "missile_normal"),
        _first_hitbox(missile_smash_events, "missile_smash"),
        *[
            _first_hitbox(events, f"charge_level_{level}")
            for level, events in enumerate(charge_events)
        ],
    ]
    explosion_size_events = [
        (int(event.frame), _f32(float(event.data.get("size", 0.0))))
        for event in bomb_explosion_events
        if event.kind == "set_hitbox_size" and int(event.data.get("idx", -1)) == 0
    ]
    explosion_remove_frames = [
        int(event.frame)
        for event in bomb_explosion_events
        if event.kind == "clear_hitboxes"
        or (event.kind == "remove_hitbox" and int(event.data.get("idx", -1)) == 0)
    ]
    if len(explosion_size_events) != 2 or len(explosion_remove_frames) != 1:
        raise ValueError(
            "unexpected Samus Bomb explosion hitbox timeline: "
            f"sizes={explosion_size_events}, removes={explosion_remove_frames}"
        )

    u16: dict[str, int] = dict(SOURCE_U16)
    u16.update(_grapple_owner_values(owners_path, callbacks_path))
    u16.update(
        {
            "bomb_lifetime_frames": round(_f32_be(buf, bomb + 0x00)),
            "bomb_flash_start_frames": round(_f32_be(buf, bomb + 0x04)),
            "charge_lifetime_frames": round(_f32_be(buf, charge + 0x00)),
            "missile_homing_lifetime_frames": round(_f32_be(buf, missile + 0x04)),
            "missile_homing_guidance_frames": round(_f32_be(buf, missile + 0x08)),
            "missile_smash_lifetime_frames": round(_f32_be(buf, missile + 0x24)),
            "missile_smash_accel_start_frames": round(_f32_be(buf, missile + 0x28)),
            "grapple_ground_spawn_frame": _i32_be(buf, ext + 0x9C),
            "grapple_ground_extend_frame": _i32_be(buf, ext + 0xA0),
            "grapple_ground_retract_frame": _i32_be(buf, ext + 0xA4),
            "grapple_ground_destroy_frame": _i32_be(buf, ext + 0xA8),
            "grapple_ground_dash_spawn_frame": _i32_be(buf, ext + 0xAC),
            "grapple_ground_dash_extend_frame": _i32_be(buf, ext + 0xB0),
            "grapple_ground_dash_retract_frame": _i32_be(buf, ext + 0xB4),
            "grapple_ground_dash_destroy_frame": _i32_be(buf, ext + 0xB8),
            "grapple_spawn_frame": _i32_be(buf, ext + 0xBC),
            "grapple_extend_frame": _i32_be(buf, ext + 0xC0),
            "grapple_retract_frame": _i32_be(buf, ext + 0xC4),
            "grapple_destroy_frame": _i32_be(buf, ext + 0xC8),
            # Fixed ItemLink capacities from the three source constructors/timelines.
            # Index 0 of the runtime array is the free tip; n-1 is the hand side.
            "grapple_link_count_catch": 90,
            "grapple_link_count_catch_dash": 60,
            "grapple_link_count_aircatch": 30,
            "grapple_swing_frames": _i32_be(buf, ext + 0xD0),
            "grapple_attr_xc": _i32_be(buf, grapple + 0x0C),
            "grapple_attr_x34": _i32_be(buf, grapple + 0x34),
            "bomb_spawn_frame": bomb_spawn_ground,
            "charge_spawn_frame": charge_spawn_ground,
            "charge_fire_frame": charge_fire_ground,
            "missile_ground_normal_spawn_frame": _event_frame(
                moves, 303, "set_throw_spawn_projectile"
            ),
            "missile_ground_smash_spawn_frame": _event_frame(
                moves, 304, "set_throw_spawn_projectile"
            ),
            "missile_air_normal_spawn_frame": _event_frame(
                moves, 305, "set_throw_spawn_projectile"
            ),
            "missile_air_smash_spawn_frame": _event_frame(
                moves, 306, "set_throw_spawn_projectile"
            ),
            # it_8027518C installs ItemCommonData::xF8 when Bomb/Missile enter
            # their destroyed/explosion state.
            # refs/melee/src/melee/it/it_2725.c::{it_8027518C,it_802751D8}
            "destroyed_lifetime_frames": round(
                float(item_common["default_spawn_lifetime_frames"])
            ),
            "bomb_explosion_size_frame_0": explosion_size_events[0][0],
            "bomb_explosion_size_frame_1": explosion_size_events[1][0],
            "bomb_explosion_remove_frame": explosion_remove_frames[0],
        }
    )

    f32 = {
        "bomb_flash_scale": _f32_be(buf, bomb + 0x08),
        "bomb_max_speed": _f32_be(buf, bomb + 0x0C),
        "bomb_gravity": _f32_be(buf, bomb_common + 0x10),
        "bomb_terminal_velocity": _f32_be(buf, bomb_common + 0x14),
        "bomb_initial_velocity_y": _f32_be(buf, bomb_common + 0x18),
        "bomb_spawn_offset_x": _f32_be(buf, ext + 0x74),
        "bomb_spawn_offset_y": _f32_be(buf, ext + 0x78),
        "bomb_spawn_offset_z": _f32_be(buf, ext + 0x7C),
        "charge_air_recoil": _f32_be(buf, ext + 0x1C),
        "charge_speed_min": _f32_be(buf, charge + 0x08),
        "charge_speed_max": _f32_be(buf, charge + 0x0C),
        "charge_damage_min": _f32_be(buf, charge + 0x10),
        "charge_damage_max": _f32_be(buf, charge + 0x14),
        "charge_scale_min": _f32_be(buf, charge + 0x18),
        "charge_scale_max": _f32_be(buf, charge + 0x1C),
        "missile_spawn_offset_x": _f32_be(buf, ext + 0x34),
        "missile_homing_speed": _f32_be(buf, missile + 0x0C),
        "missile_homing_slowdown": _f32_be(buf, missile + 0x10),
        "missile_homing_min_speed": _f32_be(buf, missile + 0x14),
        "missile_homing_turn_accel": _f32_be(buf, missile + 0x18),
        "missile_homing_max_turn": _f32_be(buf, missile + 0x1C),
        "missile_homing_turn_threshold": _f32_be(buf, missile + 0x20),
        "missile_smash_initial_speed": _f32_be(buf, missile + 0x2C),
        "missile_smash_accel": _f32_be(buf, missile + 0x30),
        "missile_smash_max_speed": _f32_be(buf, missile + 0x34),
        # itSamusGrappleAttributes is also consumed through TetherAttributes aliases.
        # refs/melee/src/melee/ft/chara/ftCommon/ftCo_AirCatch.c::ftCo_AirCatch_Anim
        "grapple_pos_x_0": _f32_be(buf, grapple + 0x38),
        "grapple_pos_x_1": _f32_be(buf, grapple + 0x40),
        "grapple_ext_fallspecial_mul": _f32_be(buf, ext + 0xCC),
        # Animation-fixed ThrowN launch offset (see GRAPPLE_LAUNCH_OFFSET_* above).
        "grapple_launch_offset_x": GRAPPLE_LAUNCH_OFFSET_X,
        "grapple_launch_offset_y": GRAPPLE_LAUNCH_OFFSET_Y,
        **{
            f"grapple_attr_x{off:x}": _f32_be(buf, grapple + off)
            for off in (
                0x00,
                0x04,
                0x08,
                0x10,
                0x14,
                0x18,
                0x1C,
                0x20,
                0x24,
                0x28,
                0x2C,
                0x30,
                0x38,
                0x3C,
                0x40,
                0x44,
                0x48,
                0x4C,
                0x50,
                0x54,
                0x58,
                0x5C,
                0x60,
            )
        },
        "bomb_explosion_size_value_0": explosion_size_events[0][1],
        "bomb_explosion_size_value_1": explosion_size_events[1][1],
    }
    u16 = {name: int(u16[name]) for name in U16_FIELDS}
    f32 = {name: _f32(f32[name]) for name in F32_FIELDS}
    if any(v < 0 or v > 0xFFFF for v in u16.values()):
        raise ValueError(f"Samus article u16 field is out of range: {u16}")

    audit = {
        "magic": MAGIC.decode("ascii"),
        "version": VERSION,
        "character_id_domains": {"internal_post_frame": 13, "external_game_start": 16},
        "sources": {
            "archive": str(plss_path),
            "main_dol": str(main_dol_path),
            "grapple_hitbox_dol_va": f"0x{GRAPPLE_HITBOX_DOL_VA:08X}",
            "archive_symbol": "ftDataSamus",
            "moves": str(moves_path),
            "item_common": str(item_common_path),
            "motion_state_owners": str(owners_path),
            "callback_symbols": str(callbacks_path),
            "decomp": [
                "ft/chara/ftSamus/ftSs_Init.c",
                "ft/chara/ftSamus/ftSs_SpecialN.c",
                "ft/chara/ftSamus/ftSs_SpecialS.c",
                "ft/chara/ftCommon/ftCo_AirCatch.c",
                "ft/chara/ftCommon/ftCo_Attack100.c",
                "it/items/itsamusbomb.c",
                "it/items/itsamuschargeshot.c",
                "it/items/itsamusmissile.c",
                "it/items/itsamusgrapple.c",
            ],
        },
        "u16": u16,
        "f32": f32,
        "archive_offsets": {
            name: {
                "article": article - arc.data_base,
                "common_attributes": common - arc.data_base,
                "special_attributes": special - arc.data_base,
            }
            for name, (article, common, special) in articles.items()
        },
        "raw_special_attributes": raw_special,
        "hitboxes": hitboxes,
        "grapple_hitbox": {
            "record_hex": grapple_hitbox_record.hex(),
            **grapple_hitbox,
        },
        "grapple_timelines": {
            "catch": [u16[f"grapple_ground_{name}_frame"] for name in ("spawn", "extend", "retract", "destroy")],
            "catch_dash": [u16[f"grapple_ground_dash_{name}_frame"] for name in ("spawn", "extend", "retract", "destroy")],
            "aircatch": [u16[f"grapple_{name}_frame"] for name in ("spawn", "extend", "retract", "destroy")],
            "attach_ticks": {
                "catch_xA0": u16["grapple_ground_extend_frame"],
                "catch_dash_xB0": u16["grapple_ground_dash_extend_frame"],
                "aircatch_xC0": u16["grapple_extend_frame"],
            },
        },
        "bomb_explosion_timeline": {
            "size_keyframes": [
                {"frame": frame, "size": size} for frame, size in explosion_size_events
            ],
            "remove_frame": explosion_remove_frames[0],
        },
    }
    return u16, f32, hitboxes, grapple_hitbox_record, audit


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Extract Samus-owned Bomb/Charge/Missile/Grapple parameters as MSLSSAR1."
    )
    ap.add_argument("--plss", type=Path, default=Path("_iso/PlSs.dat"))
    ap.add_argument("--main-dol", type=Path, default=Path("_iso/main.dol"))
    ap.add_argument("--moves", type=Path, default=Path("data/moves/samus.json"))
    ap.add_argument("--item-common", type=Path, default=Path("data/items/item_common.json"))
    ap.add_argument(
        "--owners",
        type=Path,
        default=Path("data/motion_state/owners/samus.bin"),
    )
    ap.add_argument(
        "--callback-symbols",
        type=Path,
        default=Path("data/motion_state/owners/callback_symbols.json"),
    )
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--audit", type=Path, required=True)
    args = ap.parse_args()

    u16, f32, hitboxes, grapple_hitbox_record, audit = extract(
        args.plss,
        args.main_dol,
        args.moves,
        args.item_common,
        args.owners,
        args.callback_symbols,
    )
    payload = bytearray(MAGIC)
    payload += struct.pack("<IHH", VERSION, len(U16_FIELDS), len(F32_FIELDS))
    payload += struct.pack(f"<{len(U16_FIELDS)}H", *(u16[name] for name in U16_FIELDS))
    payload += struct.pack(f"<{len(F32_FIELDS)}f", *(f32[name] for name in F32_FIELDS))
    for hitbox in hitboxes:
        payload += struct.pack(
            "<ffHHHHhBB",
            hitbox["damage"],
            hitbox["size"],
            hitbox["angle"],
            hitbox["kbg"],
            hitbox["wsk"],
            hitbox["bkb"],
            hitbox["shield_damage"],
            hitbox["element"],
            hitbox["flags"],
        )
    payload += grapple_hitbox_record
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(payload)
    args.audit.parent.mkdir(parents=True, exist_ok=True)
    args.audit.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"wrote {args.out}")
    print(f"wrote {args.audit}")


if __name__ == "__main__":
    main()
