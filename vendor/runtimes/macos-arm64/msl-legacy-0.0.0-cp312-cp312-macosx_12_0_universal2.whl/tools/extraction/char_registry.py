"""Central character registry for the extraction/preprocess pipeline.

One row per supported character; every tool that needs a per-character fact (Pl*.dat file,
ftData symbol, decomp source dir, ids) should consume this instead of carrying its own
fox/falco literals.

Id spaces:
- internal_id: Melee in-engine FighterKind / Slippi post-frame `character` id. This is the id the
  sim's seeds/binding use (char_id lanes).
- external_id: Slippi/CSS external character id used by GameStart metadata,
  what replay metadata carries.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CharInfo:
    name: str  # pipeline name (file stem for data artifacts)
    internal_id: int
    external_id: int
    pl_dat: str  # main fighter data archive in _iso
    aj_dat: str  # animation archive in _iso
    ftdata_symbol: str  # public symbol of the ftData root in pl_dat
    decomp_dir: str  # refs/melee/src/melee/ft/chara/<dir>
    decomp_prefix: str  # per-char function prefix (ftFx_, ftFc_, ftSs_, ftMs_, ...)
    # Directory whose forward.h holds the character submotion enum used by the init
    # MotionState table (clones reuse the donor's enum: Falco uses ftFox's ftFx_SM_*).
    submotion_dir: str
    submotion_prefix: str
    has_articles: bool  # source character spawns items/articles.
    exports_item_article_constants: bool  # supported by current compact MSLITAR1 exporter.
    # Fighter_Part indices needed by character-local collision descriptors even when no ordinary
    # hitbox or hurt capsule references them.
    anim_collision_parts: tuple[int, ...] = ()
    # Character MotionStates that are ordinary attacks rather than B-move specials, but whose
    # submotion scripts must be present in the compact move/animation artifacts.
    character_owned_move_msids: tuple[int, ...] = ()
    # Scaffold rows have authoritative identity/archive metadata, but have not earned inclusion in
    # the default simulator data build yet. They are opt-in via `build_data --chars` so a partial
    # port cannot make the verified runtime unusable.
    scaffold_only: bool = False
    # Ice Climbers need Popo plus an independently simulated Nana. The current four-port state
    # layout has no partner-fighter lane, so their scaffold is intentionally marked separately.
    requires_partner: bool = False


CHARS: dict[str, CharInfo] = {
    "mario": CharInfo(
        name="mario", internal_id=0, external_id=8, pl_dat="PlMr.dat", aj_dat="PlMrAJ.dat",
        ftdata_symbol="ftDataMario", decomp_dir="ftMario", decomp_prefix="ftMr_",
        submotion_dir="ftMario", submotion_prefix="ftMr_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "fox": CharInfo(
        name="fox",
        internal_id=1,
        external_id=2,
        pl_dat="PlFx.dat",
        aj_dat="PlFxAJ.dat",
        ftdata_symbol="ftDataFox",
        decomp_dir="ftFox",
        decomp_prefix="ftFx_",
        submotion_dir="ftFox",
        submotion_prefix="ftFx_SM_",
        has_articles=True,
        exports_item_article_constants=True,
    ),
    "donkey": CharInfo(
        name="donkey", internal_id=3, external_id=1, pl_dat="PlDk.dat", aj_dat="PlDkAJ.dat",
        ftdata_symbol="ftDataDonkey", decomp_dir="ftDonkey", decomp_prefix="ftDk_",
        submotion_dir="ftDonkey", submotion_prefix="ftDk_SM_", has_articles=False,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "kirby": CharInfo(
        name="kirby", internal_id=4, external_id=4, pl_dat="PlKb.dat", aj_dat="PlKbAJ.dat",
        ftdata_symbol="ftDataKirby", decomp_dir="ftKirby", decomp_prefix="ftKb_",
        submotion_dir="ftKirby", submotion_prefix="ftKb_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "bowser": CharInfo(
        name="bowser", internal_id=5, external_id=5, pl_dat="PlKp.dat", aj_dat="PlKpAJ.dat",
        ftdata_symbol="ftDataKoopa", decomp_dir="ftKoopa", decomp_prefix="ftKp_",
        submotion_dir="ftKoopa", submotion_prefix="ftKp_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "link": CharInfo(
        name="link", internal_id=6, external_id=6, pl_dat="PlLk.dat", aj_dat="PlLkAJ.dat",
        ftdata_symbol="ftDataLink", decomp_dir="ftLink", decomp_prefix="ftLk_",
        submotion_dir="ftLink", submotion_prefix="ftLk_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "falcon": CharInfo(
        name="falcon",
        internal_id=2,
        external_id=0,
        pl_dat="PlCa.dat",
        aj_dat="PlCaAJ.dat",
        ftdata_symbol="ftDataCaptain",
        decomp_dir="ftCaptain",
        decomp_prefix="ftCa_",
        submotion_dir="ftCaptain",
        submotion_prefix="ftCa_SM_",
        has_articles=False,
        exports_item_article_constants=False,
    ),
    "ganon": CharInfo(
        name="ganon",
        internal_id=25,
        external_id=25,
        pl_dat="PlGn.dat",
        aj_dat="PlGnAJ.dat",
        ftdata_symbol="ftDataGanon",
        decomp_dir="ftGanon",
        decomp_prefix="ftGn_",
        # ftGn_Init_MotionStateTable uses the ftCa_SM_* donor enum.
        submotion_dir="ftCaptain",
        submotion_prefix="ftCa_SM_",
        has_articles=False,
        exports_item_article_constants=False,
    ),
    "falco": CharInfo(
        name="falco",
        internal_id=22,
        external_id=20,
        pl_dat="PlFc.dat",
        aj_dat="PlFcAJ.dat",
        ftdata_symbol="ftDataFalco",
        decomp_dir="ftFalco",
        decomp_prefix="ftFc_",
        submotion_dir="ftFox",
        submotion_prefix="ftFx_SM_",
        has_articles=True,
        exports_item_article_constants=True,
    ),
    "marth": CharInfo(
        name="marth",
        internal_id=18,
        external_id=9,
        pl_dat="PlMs.dat",
        aj_dat="PlMsAJ.dat",
        ftdata_symbol="ftDataMars",
        decomp_dir="ftMars",
        decomp_prefix="ftMs_",
        submotion_dir="ftMars",
        submotion_prefix="ftMs_SM_",
        has_articles=False,
        exports_item_article_constants=False,
    ),
    "puff": CharInfo(
        name="puff",
        internal_id=15,
        external_id=15,
        pl_dat="PlPr.dat",
        aj_dat="PlPrAJ.dat",
        ftdata_symbol="ftDataPurin",
        decomp_dir="ftPurin",
        decomp_prefix="ftPr_",
        submotion_dir="ftPurin",
        submotion_prefix="ftPr_SM_",
        has_articles=False,
        exports_item_article_constants=False,
    ),
    "sheik": CharInfo(
        name="sheik",
        internal_id=7,
        external_id=19,
        pl_dat="PlSk.dat",
        aj_dat="PlSkAJ.dat",
        ftdata_symbol="ftDataSeak",
        decomp_dir="ftSeak",
        decomp_prefix="ftSk_",
        submotion_dir="ftSeak",
        submotion_prefix="ftSk_SM_",
        has_articles=True,
        exports_item_article_constants=True,
    ),
    "ness": CharInfo(
        name="ness", internal_id=8, external_id=11, pl_dat="PlNs.dat", aj_dat="PlNsAJ.dat",
        ftdata_symbol="ftDataNess", decomp_dir="ftNess", decomp_prefix="ftNs_",
        submotion_dir="ftNess", submotion_prefix="ftNs_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "iceclimbers": CharInfo(
        name="iceclimbers", internal_id=10, external_id=14, pl_dat="PlPp.dat", aj_dat="PlPpAJ.dat",
        ftdata_symbol="ftDataPopo", decomp_dir="ftPopo", decomp_prefix="ftPp_",
        submotion_dir="ftPopo", submotion_prefix="ftPp_SM_", has_articles=False,
        exports_item_article_constants=False, scaffold_only=True, requires_partner=True,
    ),
    "pikachu": CharInfo(
        name="pikachu",
        internal_id=12,
        external_id=13,
        pl_dat="PlPk.dat",
        aj_dat="PlPkAJ.dat",
        ftdata_symbol="ftDataPikachu",
        decomp_dir="ftPikachu",
        decomp_prefix="ftPk_",
        submotion_dir="ftPikachu",
        submotion_prefix="ftPk_SM_",
        has_articles=True,
        # Thunder and both Thunder Jolt articles are extracted directly from PlPk.dat by
        # extract_character_attrs.py and consumed by Pikachu's character-local runtime. The
        # compact shared MSLITAR1 schema is deliberately unchanged by that path.
        exports_item_article_constants=False,
    ),
    "samus": CharInfo(
        name="samus",
        # refs/melee/src/melee/ft/forward.h::FighterKind; Slippi GameStart/PostFrame.
        internal_id=13,
        external_id=16,
        pl_dat="PlSs.dat",
        aj_dat="PlSsAJ.dat",
        ftdata_symbol="ftDataSamus",
        decomp_dir="ftSamus",
        decomp_prefix="ftSs_",
        submotion_dir="ftSamus",
        submotion_prefix="ftSs_SM_",
        has_articles=True,
        # Bomb, Charge Shot, Missile, and Grapple Beam use the dedicated MSLSSAR1 extractor in
        # tools/extraction/extract_samus_articles.py; MSLITAR1 itself remains unchanged.
        exports_item_article_constants=False,
    ),
    "yoshi": CharInfo(
        name="yoshi", internal_id=14, external_id=17, pl_dat="PlYs.dat", aj_dat="PlYsAJ.dat",
        ftdata_symbol="ftDataYoshi", decomp_dir="ftYoshi", decomp_prefix="ftYs_",
        submotion_dir="ftYoshi", submotion_prefix="ftYs_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=False,
    ),
    "mewtwo": CharInfo(
        name="mewtwo", internal_id=16, external_id=10, pl_dat="PlMt.dat", aj_dat="PlMtAJ.dat",
        ftdata_symbol="ftDataMewtwo", decomp_dir="ftMewtwo", decomp_prefix="ftMt_",
        submotion_dir="ftMewtwo", submotion_prefix="ftMt_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "luigi": CharInfo(
        name="luigi", internal_id=17, external_id=7, pl_dat="PlLg.dat", aj_dat="PlLgAJ.dat",
        ftdata_symbol="ftDataLuigi", decomp_dir="ftLuigi", decomp_prefix="ftLg_",
        submotion_dir="ftLuigi", submotion_prefix="ftLg_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "peach": CharInfo(
        name="peach",
        internal_id=9,
        external_id=12,
        pl_dat="PlPe.dat",
        aj_dat="PlPeAJ.dat",
        ftdata_symbol="ftDataPeach",
        decomp_dir="ftPeach",
        decomp_prefix="ftPe_",
        submotion_dir="ftPeach",
        submotion_prefix="ftPe_SM_",
        # ftPe_Init_OnLoad registers Explode, Turnip, Parasol, Toad, and ToadSpore in x48_items.
        # MSLITAR1 v17 exports their PlPe.dat attrs/scripts plus the audited ItemKind/part constants;
        # runtime callbacks remain character-local in peach_articles.c.
        # refs/melee/src/melee/ft/chara/ftPeach/ftPe_Init.c::ftPe_Init_OnLoad
        # refs/melee/src/melee/it/forward.h::ItemKind
        has_articles=True,
        exports_item_article_constants=True,
        # PlPe.dat ftPe_DatAttrs.xAC: Toad's ShieldDesc is anchored to fp->parts[3].joint.
        # refs/melee/src/melee/ft/chara/ftPeach/ftPe_SpecialN.c::doAnim
        anim_collision_parts=(3,),
        # Float/FloatFall, the three f-smash variants, and common ItemParasolOpen/Fall all use
        # Peach-owned animation rows that must remain in the compact runtime track artifact.
        # refs/melee/src/melee/ft/chara/{ftPeach,ftCommon}/
        #   {ftPe_Init.c,ftPe_FloatFall.c,ftPe_AttackS4.c,ftCo_ItemParasolOpen.c}
        character_owned_move_msids=(295, 296, 297, 298, 299, 300, 316, 317),
    ),
    "zelda": CharInfo(
        name="zelda",
        internal_id=19,
        external_id=18,
        pl_dat="PlZd.dat",
        aj_dat="PlZdAJ.dat",
        ftdata_symbol="ftDataZelda",
        decomp_dir="ftZelda",
        decomp_prefix="ftZd_",
        submotion_dir="ftZelda",
        submotion_prefix="ftZd_SM_",
        has_articles=True,
        exports_item_article_constants=False,
    ),
    "younglink": CharInfo(
        name="younglink", internal_id=20, external_id=21, pl_dat="PlCl.dat", aj_dat="PlClAJ.dat",
        ftdata_symbol="ftDataClink", decomp_dir="ftCLink", decomp_prefix="ftCl_",
        submotion_dir="ftLink", submotion_prefix="ftLk_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "drmario": CharInfo(
        name="drmario", internal_id=21, external_id=22, pl_dat="PlDr.dat", aj_dat="PlDrAJ.dat",
        ftdata_symbol="ftDataDrmario", decomp_dir="ftDrMario", decomp_prefix="ftDr_",
        submotion_dir="ftMario", submotion_prefix="ftMr_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "pichu": CharInfo(
        name="pichu", internal_id=23, external_id=24, pl_dat="PlPc.dat", aj_dat="PlPcAJ.dat",
        ftdata_symbol="ftDataPichu", decomp_dir="ftPichu", decomp_prefix="ftPc_",
        submotion_dir="ftPikachu", submotion_prefix="ftPk_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "gamewatch": CharInfo(
        name="gamewatch", internal_id=24, external_id=3, pl_dat="PlGw.dat", aj_dat="PlGwAJ.dat",
        ftdata_symbol="ftDataGamewatch", decomp_dir="ftGameWatch", decomp_prefix="ftGw_",
        submotion_dir="ftGameWatch", submotion_prefix="ftGw_SM_", has_articles=True,
        exports_item_article_constants=False, scaffold_only=True,
    ),
    "roy": CharInfo(
        name="roy", internal_id=26, external_id=23, pl_dat="PlFe.dat", aj_dat="PlFeAJ.dat",
        ftdata_symbol="ftDataEmblem", decomp_dir="ftEmblem", decomp_prefix="ftFe_",
        submotion_dir="ftMars", submotion_prefix="ftMs_SM_", has_articles=False,
        exports_item_article_constants=False, scaffold_only=True,
    ),
}

# Keep the historical `CHARS` contract strict: its members have complete data artifacts and are
# expected to load in the native runtime. The broader table is intentionally opt-in for extractor
# work and readiness probes only.
ALL_CHARS: dict[str, CharInfo] = CHARS
SUPPORTED_CHARS: dict[str, CharInfo] = {
    k: v for k, v in ALL_CHARS.items() if not v.scaffold_only
}
SCAFFOLD_CHARS: dict[str, CharInfo] = {
    k: v for k, v in ALL_CHARS.items() if v.scaffold_only
}
CHARS = SUPPORTED_CHARS
CHAR_PL_DAT: dict[str, str] = {k: v.pl_dat for k, v in ALL_CHARS.items()}
CHAR_BY_INTERNAL_ID: dict[int, CharInfo] = {
    v.internal_id: v for v in ALL_CHARS.values()
}
CHAR_BY_EXTERNAL_ID: dict[int, CharInfo] = {
    v.external_id: v for v in ALL_CHARS.values()
}
