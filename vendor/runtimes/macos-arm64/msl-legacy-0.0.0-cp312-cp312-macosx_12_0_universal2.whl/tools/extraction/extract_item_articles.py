from __future__ import annotations

import argparse
import json
import struct
from pathlib import Path

from dataclasses import dataclass

from tools.extraction.known_data_artifacts import (
    ITEM_ARTICLE_CHAR_DOMAIN_SLIPPI_EXTERNAL_ID,
    ITEM_ARTICLE_MAGIC,
    ITEM_ARTICLE_VALUE_F32,
    ITEM_ARTICLE_VALUE_U16,
    ITEM_ARTICLE_VALUE_U32,
    ITEM_ARTICLE_VERSION,
)


from tools.extraction.char_registry import CHARS

CHAR_IDS = {name: info.external_id for name, info in CHARS.items() if info.exports_item_article_constants}
ILLUSION_ITEM_KINDS = {
    # refs/melee/src/melee/it/forward.h::ItemKind
    # refs/melee/src/melee/ft/chara/ftFox/ftFx_Init.c::ftFx_Init_OnLoad
    "fox": 56,
    # refs/melee/src/melee/ft/chara/ftFalco/ftFc_Init.c::ftFc_Init_OnLoad
    "falco": 57,
}
SHEIK_SPECIAL_ARTICLE_CONSTANTS = {
    # refs/melee/src/melee/it/forward.h::ItemKind
    # refs/melee/src/melee/it/items/itseakchain.c::itSeakChain_Spawn
    "chain_itkind": 97,
    # Source spawn part for `lb_8000B1CC(fp->parts[FtPart_L3rdNa].joint, NULL, &vec)`.
    # refs/melee/src/melee/ft/forward.h::FtPart_L3rdNa
    # refs/melee/src/melee/ft/chara/ftSeak/ftSk_SpecialS.c::ftSk_SpecialS_CheckInitChain
    "chain_spawn_part_id": 26,
    # Item_80268B18 seeds generic item lifetime from ItemCommonData; keep this article default
    # data-owned alongside the source article kind so runtime has no Sheik Chain literals.
    "chain_lifetime_frames": 1400,
    # refs/melee/src/melee/it/forward.h::ItemKind
    # refs/melee/src/melee/it/items/itseakvanish.c::{it_802B1C60,it_802B1D40}
    "vanish_itkind": 85,
    # Source spawn part for `lb_8000B1CC(fp->parts[FtPart_HipN].joint, NULL, &pos)`.
    # refs/melee/src/melee/ft/forward.h::FtPart_HipN
    # refs/melee/src/melee/ft/chara/ftSeak/ftSk_SpecialHi.c::ftSk_SpecialHi_80112F48
    "vanish_spawn_part_id": 4,
}
SHEIK_SPECIAL_ARTICLE_COMMON_LIFETIME_KEYS = {
    "vanish_lifetime_frames": "default_spawn_lifetime_frames",
}

PEACH_SOURCE_ARTIFACT_MAGIC = "MSLPEAR1"
PEACH_SOURCE_ARTIFACT_VERSION = 1
PEACH_SOURCE_ARTIFACT_PATH = (
    Path(__file__).resolve().parent / "source_artifacts" / "peach_articles.json"
)
PEACH_SOURCE_REQUIRED_KEYS = {
    "peach_bob_omb_itkind",
    "peach_mr_saturn_itkind",
    "peach_beam_sword_itkind",
    "peach_common_parasol_itkind",
    "peach_bomber_explosion_itkind",
    "peach_turnip_itkind",
    "peach_parasol_itkind",
    "peach_toad_itkind",
    "peach_toad_spore_itkind",
    "peach_bomber_attach_part_id",
    "peach_spore_lifetime_frames",
    "peach_bomber_lifetime_frames",
    "peach_spore_spawn_y_offset",
    "peach_turnip_ground_throw_base_speed",
    "peach_turnip_ground_throw_angle_radians",
    "peach_turnip_air_throw_base_speed",
    "peach_turnip_air_throw_angle_radians",
    "peach_turnip_bounce_vel_x_mul",
    "peach_turnip_bounce_vel_y_mul",
    "peach_turnip_bounce_vel_y_add",
}

UNIT_ITEM_KIND = 1
UNIT_PART_ID = 2
UNIT_FRAMES = 3
UNIT_DAMAGE = 4
UNIT_SIZE = 5
UNIT_DEGREES = 6
UNIT_VELOCITY = 7
UNIT_COUNT = 8
UNIT_BONE_ID = 9
UNIT_FLAGS = 10
UNIT_SCALAR = 11
UNIT_RADIANS = 12


@dataclass(frozen=True)
class FieldSpec:
    field_id: int
    value_type: int
    unit_id: int


FIELD_SPECS = {
    "blaster_shot_itkind": FieldSpec(1, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "blaster_gun_itkind": FieldSpec(2, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "laser_spawn_joint_part_id": FieldSpec(3, ITEM_ARTICLE_VALUE_U16, UNIT_PART_ID),
    "laser_lifetime_frames": FieldSpec(4, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "laser_damage": FieldSpec(5, ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE),
    "laser_size": FieldSpec(6, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "illusion_item_lifetime_state01_frames": FieldSpec(7, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "illusion_item_lifetime_state2_frames": FieldSpec(8, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "illusion_item_state0_damage": FieldSpec(9, ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE),
    "illusion_item_state1_damage": FieldSpec(10, ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE),
    "shield_bounce_extra_degrees": FieldSpec(11, ITEM_ARTICLE_VALUE_F32, UNIT_DEGREES),
    "side_special_illusion_itkind": FieldSpec(12, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "needle_throw_itkind": FieldSpec(13, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "needle_held_itkind": FieldSpec(14, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "needle_lifetime_frames": FieldSpec(15, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "needle_bounce_lifetime_frames": FieldSpec(16, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "needle_launch_speed": FieldSpec(17, ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    "needle_hurtbox_count": FieldSpec(18, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "needle_hurtbox_bone_id": FieldSpec(19, ITEM_ARTICLE_VALUE_U16, UNIT_BONE_ID),
    "needle_hurtbox_a_offset_x": FieldSpec(20, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hurtbox_a_offset_y": FieldSpec(21, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hurtbox_a_offset_z": FieldSpec(22, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hurtbox_b_offset_x": FieldSpec(23, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hurtbox_b_offset_y": FieldSpec(24, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hurtbox_b_offset_z": FieldSpec(25, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hurtbox_scale": FieldSpec(26, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "needle_hitbox_damage": FieldSpec(27, ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE),
    "chain_itkind": FieldSpec(28, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "chain_lifetime_frames": FieldSpec(29, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "vanish_itkind": FieldSpec(30, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    "vanish_lifetime_frames": FieldSpec(31, ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    "needle_hitbox_count": FieldSpec(32, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    **{
        f"needle_hitbox_damage_by_id_{i}": FieldSpec(33 + i, ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE)
        for i in range(4)
    },
    **{
        f"needle_hitbox_size_{i}": FieldSpec(37 + i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE)
        for i in range(4)
    },
    **{
        f"needle_hitbox_x_offset_{i}": FieldSpec(41 + i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE)
        for i in range(4)
    },
    **{
        f"needle_hitbox_y_offset_{i}": FieldSpec(45 + i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE)
        for i in range(4)
    },
    **{
        f"needle_hitbox_z_offset_{i}": FieldSpec(49 + i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE)
        for i in range(4)
    },
    **{
        f"needle_hitbox_angle_{i}": FieldSpec(53 + i, ITEM_ARTICLE_VALUE_U16, UNIT_DEGREES)
        for i in range(4)
    },
    **{
        f"needle_hitbox_kbg_{i}": FieldSpec(57 + i, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT)
        for i in range(4)
    },
    **{
        f"needle_hitbox_wsk_{i}": FieldSpec(61 + i, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT)
        for i in range(4)
    },
    **{
        f"needle_hitbox_bkb_{i}": FieldSpec(65 + i, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT)
        for i in range(4)
    },
    **{
        f"needle_hitbox_element_{i}": FieldSpec(69 + i, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT)
        for i in range(4)
    },
    **{
        f"needle_hitbox_shield_damage_{i}": FieldSpec(73 + i, ITEM_ARTICLE_VALUE_U16, UNIT_DAMAGE)
        for i in range(4)
    },
    **{
        f"needle_hitbox_flags_{i}": FieldSpec(77 + i, ITEM_ARTICLE_VALUE_U32, UNIT_FLAGS)
        for i in range(4)
    },
    "vanish_hitbox_count": FieldSpec(81, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "vanish_hitbox_damage": FieldSpec(82, ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE),
    "vanish_hitbox_size": FieldSpec(83, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "vanish_hitbox_x_offset": FieldSpec(84, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "vanish_hitbox_y_offset": FieldSpec(85, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "vanish_hitbox_z_offset": FieldSpec(86, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "vanish_hitbox_angle": FieldSpec(87, ITEM_ARTICLE_VALUE_U16, UNIT_DEGREES),
    "vanish_hitbox_kbg": FieldSpec(88, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "vanish_hitbox_wsk": FieldSpec(89, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "vanish_hitbox_bkb": FieldSpec(90, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "vanish_hitbox_element": FieldSpec(91, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "vanish_hitbox_shield_damage": FieldSpec(92, ITEM_ARTICLE_VALUE_U16, UNIT_DAMAGE),
    "vanish_hitbox_flags": FieldSpec(93, ITEM_ARTICLE_VALUE_U32, UNIT_FLAGS),
    "vanish_hitbox_size_keyframe_count": FieldSpec(94, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    "vanish_hitbox_size_keyframe_frame_0": FieldSpec(95, ITEM_ARTICLE_VALUE_U16, UNIT_FRAMES),
    "vanish_hitbox_size_keyframe_value_0": FieldSpec(96, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "vanish_hitbox_size_keyframe_frame_1": FieldSpec(97, ITEM_ARTICLE_VALUE_U16, UNIT_FRAMES),
    "vanish_hitbox_size_keyframe_value_1": FieldSpec(98, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    "vanish_hitbox_remove_frame": FieldSpec(99, ITEM_ARTICLE_VALUE_U16, UNIT_FRAMES),
    "chain_spawn_part_id": FieldSpec(100, ITEM_ARTICLE_VALUE_U16, UNIT_PART_ID),
    "vanish_spawn_part_id": FieldSpec(101, ITEM_ARTICLE_VALUE_U16, UNIT_PART_ID),
}

SHEIK_NEEDLE_FIELD_NAMES = tuple(
    name for name in FIELD_SPECS if name.startswith("needle_")
)
SHEIK_SPECIAL_ARTICLE_FIELD_NAMES = tuple(SHEIK_SPECIAL_ARTICLE_CONSTANTS)
SHEIK_SPECIAL_ARTICLE_FIELD_NAMES += tuple(SHEIK_SPECIAL_ARTICLE_COMMON_LIFETIME_KEYS)
SHEIK_VANISH_HITBOX_FIELD_NAMES = tuple(
    name for name in FIELD_SPECS if name.startswith("vanish_hitbox_")
)

# Thrown-Needle dropped/bounced motion RNG tables (HSD_Randi(8) lookups). These are decomp constant
# `static f32` arrays, transcribed by source symbol. Routed through MSLITAR1 so src/items.c carries
# no local literal copies. Registered after the needle/vanish field-name tuples above so they are
# injected as sheik-only constants (like the chain/vanish article kinds), not attrs lookups.
# refs/melee/src/melee/it/items/itseakneedlethrown.c::{it_803F6FA0,it_803F6FC0,it_803F7020,it_803F7040}
SHEIK_NEEDLE_DROP_BOUNCE_TABLES = {
    "needle_drop_min_vel_y": (102, (-2.0, -2.1, -2.2, -2.3, -2.4, -2.5, -2.6, -2.7)),  # it_803F6FA0
    "needle_drop_gravity": (110, (-0.1, -0.12, -0.14, -0.18, -0.2, -0.22, -0.24, -0.26)),  # it_803F6FC0
    "needle_bounce_min_vel_y": (118, (-2.0, -2.1, -2.2, -2.3, -2.4, -2.5, -2.6, -2.7)),  # it_803F7020
    "needle_bounce_gravity": (126, (-0.1, -0.12, -0.14, -0.18, -0.2, -0.22, -0.24, -0.26)),  # it_803F7040
    # SetupBounce xDD8 horizontal drift table; the |value| is selected by HSD_Randi(8) and signed by a
    # separate HSD_Randi(2). Unlike the strictly-negative velocity/gravity tables, this one is >= 0.
    "needle_bounce_x_vel": (134, (0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4)),  # it_803F7000
}
for _base_name, (_base_id, _values) in SHEIK_NEEDLE_DROP_BOUNCE_TABLES.items():
    for _i, _v in enumerate(_values):
        _key = f"{_base_name}_{_i}"
        FIELD_SPECS[_key] = FieldSpec(_base_id + _i, ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY)
        SHEIK_SPECIAL_ARTICLE_CONSTANTS[_key] = _v

# Sheik thrown-Needle command-11 HitCapsule publication fields. `needle_hitbox_bone_id` is decoded
# from the item script command; the JObj offsets come from Article::x10_modelDesc and model the
# source `it_8027137C -> lb_8000B1CC` endpoint publication used by ftColl_8007925C BODY contact.
for _i in range(4):
    FIELD_SPECS[f"needle_hitbox_bone_id_{_i}"] = FieldSpec(
        142 + _i, ITEM_ARTICLE_VALUE_U16, UNIT_BONE_ID
    )
    FIELD_SPECS[f"needle_hitbox_jobj_x_offset_{_i}"] = FieldSpec(
        146 + _i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE
    )
    FIELD_SPECS[f"needle_hitbox_jobj_y_offset_{_i}"] = FieldSpec(
        150 + _i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE
    )
    FIELD_SPECS[f"needle_hitbox_jobj_z_offset_{_i}"] = FieldSpec(
        154 + _i, ITEM_ARTICLE_VALUE_F32, UNIT_SIZE
    )
SHEIK_NEEDLE_FIELD_NAMES = tuple(
    name
    for name in FIELD_SPECS
    if name.startswith("needle_")
    and not any(name.startswith(f"{base_name}_") for base_name in SHEIK_NEEDLE_DROP_BOUNCE_TABLES)
)

# Sheik Side-B Chain article `itSeakChain_Attrs` (Verlet solver data, ISO-extracted into
# data/characters/sheik.json by extract_character_attrs._extract_seak_chain_article). Unlike the
# chain kind/spawn-part/lifetime (injected source constants above), these are PlSk.dat article data:
# they are read from the character attrs JSON via the generic `key in attrs` path in `_records`.
# field_id base 200 (the 1..141 range is taken by the explicit specs + needle drop/bounce tables).
# refs/melee/src/melee/it/itCharItems.h::itSeakChain_Attrs
# refs/melee/src/melee/it/items/itseakchain.c (it_802BAF2C link count; it_802BCFC4 launch;
#   it_802BBB0C gravity/segment; itSeakChain_clamp_x10/_x14 friction;
#   it_802BC94C/fn_802BB44C decay/wall-bounce)
# refs/melee/src/melee/ft/chara/ftSeak/ftSk_SpecialS.c::ftSk_SpecialS_80110BCC
SHEIK_CHAIN_ATTR_FIELDS = (
    ("sheik_chain_link_count", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    ("sheik_chain_segment_length", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("sheik_chain_friction_x10", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_friction_x14", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_gravity", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("sheik_chain_attr_x1c", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x20", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x24", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x28", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x2c", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x30", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_decay_x34", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x38", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x3c", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x40", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x44", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x48", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x4c", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("sheik_chain_initial_vel_x50", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("sheik_chain_attr_x54", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_wall_bounce_x58", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x5c", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("sheik_chain_attr_x60", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
)
for _i, (_key, _vt, _unit) in enumerate(SHEIK_CHAIN_ATTR_FIELDS):
    FIELD_SPECS[_key] = FieldSpec(200 + _i, _vt, _unit)
SHEIK_CHAIN_ATTR_FIELD_NAMES = tuple(name for name, _vt, _unit in SHEIK_CHAIN_ATTR_FIELDS)


# Peach's complete character-owned article/special surface. IDs 223..322 are a
# contiguous MSLITAR1 v17 family; pickup geometry is appended in v18 so the old
# field ids remain stable. Field 333 adds the source Turnip ItemAttr scale.
# PlPe.dat values are emitted by `_extract_peach_articles`; source-only enums and
# callback constants come from the packaged MSLPEAR1 artifact above.
PEACH_ARTICLE_SCALAR_FIELDS = (
    ("peach_bob_omb_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_mr_saturn_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_beam_sword_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_common_parasol_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_bomber_explosion_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_turnip_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_parasol_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_toad_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_toad_spore_itkind", ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND),
    ("peach_article_attach_part_id", ITEM_ARTICLE_VALUE_U16, UNIT_PART_ID),
    ("peach_bomber_attach_part_id", ITEM_ARTICLE_VALUE_U16, UNIT_PART_ID),
    ("peach_default_spawn_lifetime_frames", ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    ("peach_turnip_lifetime_frames", ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    ("peach_spore_lifetime_frames", ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    ("peach_bomber_lifetime_frames", ITEM_ARTICLE_VALUE_U32, UNIT_FRAMES),
    ("peach_rare_item_table_count", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    ("peach_rare_item_gate_max", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
)
for _i, (_key, _vt, _unit) in enumerate(PEACH_ARTICLE_SCALAR_FIELDS):
    FIELD_SPECS[_key] = FieldSpec(223 + _i, _vt, _unit)
for _i in range(3):
    FIELD_SPECS[f"peach_rare_item_weight_{_i}"] = FieldSpec(
        240 + _i, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT
    )
    FIELD_SPECS[f"peach_rare_item_kind_{_i}"] = FieldSpec(
        243 + _i, ITEM_ARTICLE_VALUE_U16, UNIT_ITEM_KIND
    )
FIELD_SPECS["peach_turnip_face_count"] = FieldSpec(
    246, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT
)
for _i in range(8):
    FIELD_SPECS[f"peach_turnip_face_odds_{_i}"] = FieldSpec(
        247 + _i, ITEM_ARTICLE_VALUE_U16, UNIT_COUNT
    )
    FIELD_SPECS[f"peach_turnip_face_damage_{_i}"] = FieldSpec(
        255 + _i, ITEM_ARTICLE_VALUE_U16, UNIT_DAMAGE
    )

PEACH_ARTICLE_PHYSICS_FIELDS = (
    ("peach_turnip_throw_speed_mul", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("peach_turnip_gravity", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_turnip_terminal_speed", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_turnip_stage_restitution", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("peach_turnip_ground_throw_base_speed", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_turnip_ground_throw_angle_radians", ITEM_ARTICLE_VALUE_F32, UNIT_RADIANS),
    ("peach_turnip_air_throw_base_speed", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_turnip_air_throw_angle_radians", ITEM_ARTICLE_VALUE_F32, UNIT_RADIANS),
    ("peach_turnip_bounce_vel_x_mul", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("peach_turnip_bounce_vel_y_mul", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("peach_turnip_bounce_vel_y_add", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_spore_min_speed", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_spore_speed_range", ITEM_ARTICLE_VALUE_F32, UNIT_VELOCITY),
    ("peach_spore_velocity_decay", ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR),
    ("peach_spore_angle_range_radians", ITEM_ARTICLE_VALUE_F32, UNIT_RADIANS),
    ("peach_spore_spawn_y_offset", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_toad_desc_bone_id", ITEM_ARTICLE_VALUE_U16, UNIT_BONE_ID),
    ("peach_toad_desc_offset_x", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_toad_desc_offset_y", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_toad_desc_offset_z", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_toad_desc_radius", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_toad_hitlag_floor", ITEM_ARTICLE_VALUE_U16, UNIT_FRAMES),
)
for _i, (_key, _vt, _unit) in enumerate(PEACH_ARTICLE_PHYSICS_FIELDS):
    FIELD_SPECS[_key] = FieldSpec(263 + _i, _vt, _unit)
FIELD_SPECS["peach_turnip_item_scale"] = FieldSpec(333, ITEM_ARTICLE_VALUE_F32, UNIT_SCALAR)

PEACH_HITBOX_PREFIXES = (
    "peach_turnip_hitbox",
    "peach_spore_hitbox",
    "peach_bomber_hitbox_normal",
    "peach_bomber_hitbox_smash",
)
PEACH_HITBOX_COMPONENTS = (
    ("damage", ITEM_ARTICLE_VALUE_F32, UNIT_DAMAGE),
    ("size", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("angle", ITEM_ARTICLE_VALUE_U16, UNIT_DEGREES),
    ("kbg", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    ("wsk", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    ("bkb", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    ("shield_damage", ITEM_ARTICLE_VALUE_U16, UNIT_DAMAGE),
    ("element", ITEM_ARTICLE_VALUE_U16, UNIT_COUNT),
    ("flags", ITEM_ARTICLE_VALUE_U32, UNIT_FLAGS),
)
for _prefix_i, _prefix in enumerate(PEACH_HITBOX_PREFIXES):
    for _component_i, (_component, _vt, _unit) in enumerate(PEACH_HITBOX_COMPONENTS):
        FIELD_SPECS[f"{_prefix}_{_component}"] = FieldSpec(
            285 + _prefix_i * 9 + _component_i, _vt, _unit
        )
FIELD_SPECS["peach_spore_hitbox_remove_frame"] = FieldSpec(
    321, ITEM_ARTICLE_VALUE_U16, UNIT_FRAMES
)
FIELD_SPECS["peach_bomber_hitbox_remove_frame"] = FieldSpec(
    322, ITEM_ARTICLE_VALUE_U16, UNIT_FRAMES
)
PEACH_PICKUP_FIELDS = (
    ("peach_turnip_grab_range_x", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_turnip_grab_range_y", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_ground_offset_x", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_ground_offset_y", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_ground_range_x", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_ground_range_y", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_air_offset_x", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_air_offset_y", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_air_range_x", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
    ("peach_light_pickup_air_range_y", ITEM_ARTICLE_VALUE_F32, UNIT_SIZE),
)
for _i, (_key, _vt, _unit) in enumerate(PEACH_PICKUP_FIELDS):
    FIELD_SPECS[_key] = FieldSpec(323 + _i, _vt, _unit)
PEACH_ARTICLE_FIELD_NAMES = tuple(
    name for name, spec in FIELD_SPECS.items() if 223 <= spec.field_id <= 333
)


def _load_peach_source_values() -> dict[str, float]:
    payload = json.loads(PEACH_SOURCE_ARTIFACT_PATH.read_text(encoding="utf-8"))
    if payload.get("magic") != PEACH_SOURCE_ARTIFACT_MAGIC:
        raise ValueError(
            f"{PEACH_SOURCE_ARTIFACT_PATH}: expected magic {PEACH_SOURCE_ARTIFACT_MAGIC}"
        )
    if int(payload.get("version", -1)) != PEACH_SOURCE_ARTIFACT_VERSION:
        raise ValueError(
            f"{PEACH_SOURCE_ARTIFACT_PATH}: expected version {PEACH_SOURCE_ARTIFACT_VERSION}"
        )
    values = payload.get("values")
    if not isinstance(values, dict):
        raise ValueError(f"{PEACH_SOURCE_ARTIFACT_PATH}: missing values object")
    missing = sorted(PEACH_SOURCE_REQUIRED_KEYS - set(values))
    if missing:
        raise ValueError(
            f"{PEACH_SOURCE_ARTIFACT_PATH}: missing required keys: {', '.join(missing)}"
        )
    return {key: float(values[key]) for key in PEACH_SOURCE_REQUIRED_KEYS}


def _peach_article_values(attrs: dict, common: dict) -> dict[str, float]:
    values = _load_peach_source_values()
    if "default_spawn_lifetime_frames" not in common:
        raise ValueError("item_common.json is missing default_spawn_lifetime_frames")
    values["peach_default_spawn_lifetime_frames"] = float(
        common["default_spawn_lifetime_frames"]
    )

    array_fields = {
        "peach_rare_item_weights": ("peach_rare_item_weight", 3),
        "peach_rare_item_kinds": ("peach_rare_item_kind", 3),
        "peach_turnip_face_odds": ("peach_turnip_face_odds", 8),
        "peach_turnip_face_damage": ("peach_turnip_face_damage", 8),
    }
    for source_key, (flat_key, count) in array_fields.items():
        source_values = attrs.get(source_key)
        if not isinstance(source_values, list) or len(source_values) != count:
            raise ValueError(
                f"Peach article attrs require {source_key} with exactly {count} entries"
            )
        for i, value in enumerate(source_values):
            values[f"{flat_key}_{i}"] = float(value)

    desc_offset = attrs.get("peach_toad_desc_offset")
    if not isinstance(desc_offset, list) or len(desc_offset) != 3:
        raise ValueError("Peach article attrs require peach_toad_desc_offset[3]")
    for i, axis in enumerate("xyz"):
        values[f"peach_toad_desc_offset_{axis}"] = float(desc_offset[i])

    for key in PEACH_ARTICLE_FIELD_NAMES:
        if key in values:
            continue
        if key in attrs:
            values[key] = float(attrs[key])
    missing = sorted(set(PEACH_ARTICLE_FIELD_NAMES) - set(values))
    if missing:
        raise ValueError(
            "Peach exports MSLITAR1 article fields but its generated attrs are missing: "
            + ", ".join(missing)
        )
    return values


def _f32(v: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(v)))[0]


def _pack_record(char_id: int, spec: FieldSpec, value: float) -> bytes:
    if spec.value_type in (ITEM_ARTICLE_VALUE_U16, ITEM_ARTICLE_VALUE_U32):
        u32_value = int(value)
        f32_value = 0.0
    elif spec.value_type == ITEM_ARTICLE_VALUE_F32:
        u32_value = 0
        f32_value = _f32(value)
    else:
        raise ValueError(f"unsupported MSLITAR1 value type: {spec.value_type}")
    return struct.pack(
        "<HBBHHIfII",
        int(char_id) & 0xFFFF,
        ITEM_ARTICLE_CHAR_DOMAIN_SLIPPI_EXTERNAL_ID,
        int(spec.value_type) & 0xFF,
        int(spec.field_id) & 0xFFFF,
        int(spec.unit_id) & 0xFFFF,
        int(u32_value) & 0xFFFF_FFFF,
        _f32(f32_value),
        0,
        0,
    )


def _records(chars: list[str], attrs_dir: Path, item_common: Path) -> list[tuple[int, FieldSpec, float]]:
    out: list[tuple[int, FieldSpec, float]] = []
    common = json.loads(item_common.read_text(encoding="utf-8"))
    for ch in chars:
        if ch not in CHAR_IDS:
            continue
        attrs = json.loads((attrs_dir / f"{ch}.json").read_text(encoding="utf-8"))
        peach_values = _peach_article_values(attrs, common) if ch == "peach" else {}
        if ch == "sheik":
            missing = [
                key
                for key in SHEIK_NEEDLE_FIELD_NAMES
                if key not in attrs
                and not key.startswith("needle_hurtbox_a_offset_")
                and not key.startswith("needle_hurtbox_b_offset_")
                and not (key.startswith("needle_hitbox_") and key[-1].isdigit())
            ]
            for vec_key in ("needle_hurtbox_a_offset", "needle_hurtbox_b_offset"):
                vals = attrs.get(vec_key)
                if not isinstance(vals, list) or len(vals) < 3:
                    missing.append(vec_key)
            for vec_key in (
                "needle_hitbox_damage_by_id",
                "needle_hitbox_bone_id",
                "needle_hitbox_jobj_x_offset",
                "needle_hitbox_jobj_y_offset",
                "needle_hitbox_jobj_z_offset",
                "needle_hitbox_size",
                "needle_hitbox_x_offset",
                "needle_hitbox_y_offset",
                "needle_hitbox_z_offset",
                "needle_hitbox_angle",
                "needle_hitbox_kbg",
                "needle_hitbox_wsk",
                "needle_hitbox_bkb",
                "needle_hitbox_element",
                "needle_hitbox_shield_damage",
                "needle_hitbox_flags",
            ):
                vals = attrs.get(vec_key)
                if not isinstance(vals, list) or len(vals) < 4:
                    missing.append(vec_key)
            for key in SHEIK_VANISH_HITBOX_FIELD_NAMES:
                if key.startswith("vanish_hitbox_size_keyframe_frame_"):
                    vals = attrs.get("vanish_hitbox_size_keyframe_frame")
                    if not isinstance(vals, list) or len(vals) < 2:
                        missing.append("vanish_hitbox_size_keyframe_frame")
                    continue
                if key.startswith("vanish_hitbox_size_keyframe_value_"):
                    vals = attrs.get("vanish_hitbox_size_keyframe_value")
                    if not isinstance(vals, list) or len(vals) < 2:
                        missing.append("vanish_hitbox_size_keyframe_value")
                    continue
                if key not in attrs:
                    missing.append(key)
            for key in SHEIK_CHAIN_ATTR_FIELD_NAMES:
                if key not in attrs:
                    missing.append(key)
            if missing:
                raise ValueError(
                    "Sheik exports MSLITAR1 special article fields but "
                    f"{attrs_dir / f'{ch}.json'} is missing: {', '.join(sorted(missing))}"
                )
        char_id = CHAR_IDS[ch]
        for key, spec in FIELD_SPECS.items():
            if key.startswith("peach_"):
                if ch == "peach":
                    out.append((char_id, spec, peach_values[key]))
                continue
            if key == "shield_bounce_extra_degrees":
                continue
            if key == "side_special_illusion_itkind":
                if ch not in ILLUSION_ITEM_KINDS:
                    continue
                out.append((char_id, spec, float(ILLUSION_ITEM_KINDS[ch])))
                continue
            if key in SHEIK_SPECIAL_ARTICLE_CONSTANTS:
                if ch == "sheik":
                    out.append((char_id, spec, float(SHEIK_SPECIAL_ARTICLE_CONSTANTS[key])))
                continue
            if key in SHEIK_SPECIAL_ARTICLE_COMMON_LIFETIME_KEYS:
                if ch == "sheik":
                    common_key = SHEIK_SPECIAL_ARTICLE_COMMON_LIFETIME_KEYS[key]
                    if common_key not in common:
                        raise ValueError(
                            f"{item_common} is missing required Sheik article lifetime key {common_key}"
                        )
                    out.append((char_id, spec, float(common[common_key])))
                continue
            if key.startswith("needle_hurtbox_a_offset_"):
                vals = attrs.get("needle_hurtbox_a_offset")
                comp = "xyz".index(key[-1])
                if isinstance(vals, list) and len(vals) > comp:
                    out.append((char_id, spec, float(vals[comp])))
                continue
            if key.startswith("needle_hurtbox_b_offset_"):
                vals = attrs.get("needle_hurtbox_b_offset")
                comp = "xyz".index(key[-1])
                if isinstance(vals, list) and len(vals) > comp:
                    out.append((char_id, spec, float(vals[comp])))
                continue
            if key.startswith("needle_hitbox_") and key[-1].isdigit():
                idx = int(key[-1])
                base_key = key[:-2]
                vals = attrs.get(base_key)
                if isinstance(vals, list) and len(vals) > idx:
                    out.append((char_id, spec, float(vals[idx])))
                continue
            if key.startswith("vanish_hitbox_size_keyframe_") and key[-1].isdigit():
                idx = int(key[-1])
                base_key = key[:-2]
                vals = attrs.get(base_key)
                if isinstance(vals, list) and len(vals) > idx:
                    out.append((char_id, spec, float(vals[idx])))
                continue
            if key in attrs:
                out.append((char_id, spec, float(attrs[key])))
    if "shield_bounce_extra_degrees" in common:
        for ch in chars:
            if ch not in CHAR_IDS:
                continue
            out.append((CHAR_IDS[ch], FIELD_SPECS["shield_bounce_extra_degrees"], float(common["shield_bounce_extra_degrees"])))
    return sorted(out, key=lambda row: (row[0], row[1].field_id))


def main() -> None:
    ap = argparse.ArgumentParser(description="Pack known fighter item/article owner constants as MSLITAR1.")
    ap.add_argument("--attrs-dir", type=Path, default=Path("data/characters"))
    ap.add_argument("--item-common", type=Path, default=Path("data/items/item_common.json"))
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--manifest", type=Path, default=None)
    ap.add_argument(
        "--chars",
        type=str,
        default=",".join(CHAR_IDS),
        help="comma-separated article owners (default: every exporter-backed registry character)",
    )
    args = ap.parse_args()

    chars = [c.strip() for c in args.chars.split(",") if c.strip()]
    records = _records(chars, args.attrs_dir, args.item_common)
    buf = bytearray()
    buf += ITEM_ARTICLE_MAGIC
    buf += struct.pack("<II", ITEM_ARTICLE_VERSION, len(records))
    for char_id, spec, value in records:
        buf += _pack_record(char_id, spec, value)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(bytes(buf))
    if args.manifest is not None:
        payload = {
            "magic": ITEM_ARTICLE_MAGIC.decode("ascii"),
            "version": ITEM_ARTICLE_VERSION,
            "char_domain": {
                "id": ITEM_ARTICLE_CHAR_DOMAIN_SLIPPI_EXTERNAL_ID,
                "name": "Slippi/CSS external character id",
                "note": "This is not the runtime MslSeed internal character id domain.",
            },
            "units": [
                {"id": UNIT_ITEM_KIND, "name": "item_kind"},
                {"id": UNIT_PART_ID, "name": "fighter_part_id"},
                {"id": UNIT_FRAMES, "name": "frames"},
                {"id": UNIT_DAMAGE, "name": "damage"},
                {"id": UNIT_SIZE, "name": "size"},
                {"id": UNIT_DEGREES, "name": "degrees"},
                {"id": UNIT_VELOCITY, "name": "velocity"},
                {"id": UNIT_COUNT, "name": "count"},
                {"id": UNIT_BONE_ID, "name": "bone_id"},
                {"id": UNIT_FLAGS, "name": "flags"},
                {"id": UNIT_SCALAR, "name": "scalar"},
                {"id": UNIT_RADIANS, "name": "radians"},
            ],
            "value_types": [
                {"id": ITEM_ARTICLE_VALUE_U16, "name": "u16"},
                {"id": ITEM_ARTICLE_VALUE_U32, "name": "u32"},
                {"id": ITEM_ARTICLE_VALUE_F32, "name": "f32"},
            ],
            "fields": [
                {"id": spec.field_id, "name": name, "value_type": spec.value_type, "unit_id": spec.unit_id}
                for name, spec in sorted(FIELD_SPECS.items(), key=lambda kv: kv[1].field_id)
            ],
        }
        args.manifest.parent.mkdir(parents=True, exist_ok=True)
        args.manifest.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
