"""Deterministic source provenance for the native extension build."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


NATIVE_BUILD_INPUT_MACRO = "MSL_NATIVE_BUILD_INPUT_SHA256"
NATIVE_BUILD_INPUT_ATTRIBUTE = "NATIVE_BUILD_INPUT_SHA256"
NATIVE_BUILD_CONFIG_PATHS = (
    "MANIFEST.in",
    "Makefile",
    "pyproject.toml",
    "setup.py",
    "tools/native_build_provenance.py",
)

_NATIVE_TREES = ("bindings", "src")
_NATIVE_SOURCE_SUFFIXES = frozenset({".c"})
_NATIVE_DEPENDENCY_SUFFIXES = frozenset({".h", ".inc"})
_DIGEST_DOMAIN = b"melee-sim-light-native-build-input-v1\0"


def _discover_repo_paths(root: Path, suffixes: frozenset[str]) -> tuple[str, ...]:
    paths: list[str] = []
    for tree_name in _NATIVE_TREES:
        tree = root / tree_name
        if not tree.is_dir():
            raise FileNotFoundError(f"native source tree is missing: {tree}")
        paths.extend(
            path.relative_to(root).as_posix()
            for path in tree.rglob("*")
            if path.is_file() and path.suffix.lower() in suffixes
        )
    return tuple(sorted(paths))


def native_extension_sources(root: str | Path) -> tuple[str, ...]:
    """Return every C translation unit compiled into ``melee_sim._native``."""
    return _discover_repo_paths(Path(root).resolve(), _NATIVE_SOURCE_SUFFIXES)


def native_extension_dependencies(root: str | Path) -> tuple[str, ...]:
    """Return every local header/include file that can affect native compilation."""
    return _discover_repo_paths(Path(root).resolve(), _NATIVE_DEPENDENCY_SUFFIXES)


def native_build_dependencies(root: str | Path) -> tuple[str, ...]:
    """Return every non-source input that must invalidate ``build_ext`` outputs."""
    repo_root = Path(root).resolve()
    relative_paths = tuple(
        sorted({*native_extension_dependencies(repo_root), *NATIVE_BUILD_CONFIG_PATHS})
    )
    missing = [relative for relative in relative_paths if not (repo_root / relative).is_file()]
    if missing:
        raise FileNotFoundError(f"native build dependencies are missing: {', '.join(missing)}")
    return relative_paths


def native_build_input_paths(root: str | Path) -> tuple[str, ...]:
    """Return the canonical, repo-relative native build input set."""
    repo_root = Path(root).resolve()
    relative_paths = tuple(
        sorted(
            {
                *native_extension_sources(repo_root),
                *native_build_dependencies(repo_root),
            }
        )
    )
    missing = [relative for relative in relative_paths if not (repo_root / relative).is_file()]
    if missing:
        raise FileNotFoundError(f"native build inputs are missing: {', '.join(missing)}")
    return relative_paths


def native_build_input_sha256(root: str | Path) -> str:
    """Hash canonical path/content records for every native build input."""
    repo_root = Path(root).resolve()
    digest = hashlib.sha256(_DIGEST_DOMAIN)
    for relative in native_build_input_paths(repo_root):
        path_bytes = relative.encode("utf-8")
        content = (repo_root / relative).read_bytes()
        digest.update(len(path_bytes).to_bytes(8, byteorder="big"))
        digest.update(path_bytes)
        digest.update(len(content).to_bytes(8, byteorder="big"))
        digest.update(content)
    return digest.hexdigest()


def native_build_define_macros(root: str | Path) -> list[tuple[str, str]]:
    """Return the compiler macro carrying this source tree's provenance digest."""
    value = native_build_input_sha256(root)
    return [(NATIVE_BUILD_INPUT_MACRO, f'"{value}"')]


def main() -> None:
    parser = argparse.ArgumentParser(description="Print the canonical native build-input digest")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="repository/source-distribution root",
    )
    args = parser.parse_args()
    print(native_build_input_sha256(args.root))


if __name__ == "__main__":
    main()
