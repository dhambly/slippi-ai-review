from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from importlib import metadata
from pathlib import Path
from urllib.parse import unquote, urlparse
from urllib.request import url2pathname

from .iso import IsoFile, extract_file, find_files, list_files


_STAGE_DAT_BY_KEY = {
    "grnla": "GrNLa.dat",
    "grnba": "GrNBa.dat",
    "griz": "GrIz.dat",
    "grps": "GrPs.dat",
    "grst": "GrSt.dat",
    "grop": "GrOp.dat",
}

_CHAR_GLOBS = {
    "fox": "*PlFx*.dat",
    "falcon": "*PlCa*.dat",
    "ganon": "*PlGn*.dat",
    "falco": "*PlFc*.dat",
    "marth": "*PlMs*.dat",
    "peach": "*PlPe*.dat",
    "pikachu": "*PlPk*.dat",
    "puff": "*PlPr*.dat",
    "samus": "*PlSs*.dat",
    "sheik": "*PlSk*.dat",
    "yoshi": "*PlYs*.dat",
    "zelda": "*PlZd*.dat",
}

_GAMECUBE_DOL_OFFSET = 0x420
_DOL_HEADER_SIZE = 0x100
_DOL_SECTION_LAYOUTS = (
    ("text", 0x00, 0x90, 7),
    ("data", 0x1C, 0xAC, 11),
)


def _path_from_direct_url() -> Path | None:
    try:
        text = metadata.distribution("melee-sim-light").read_text("direct_url.json")
    except Exception:
        return None
    if not text:
        return None
    try:
        payload = json.loads(text)
    except Exception:
        return None
    url = payload.get("url")
    if not isinstance(url, str):
        return None
    parsed = urlparse(url)
    if parsed.scheme != "file":
        return None
    url_path = parsed.path
    netloc = unquote(parsed.netloc)
    if len(netloc) == 2 and netloc[0].isalpha() and netloc[1] == ":":
        url_path = f"/{netloc}{url_path}"
    elif netloc and netloc.lower() != "localhost":
        url_path = f"//{netloc}{url_path}"
    path = Path(url2pathname(url_path)).resolve()
    if path.name == "python":
        path = path.parent
    return path


def _default_melee_decomp() -> Path | None:
    env_path = os.environ.get("MELEE_SIM_MELEE_DECOMP")
    if env_path:
        return Path(env_path).expanduser().resolve()
    cwd_path = Path("refs/melee").resolve()
    if cwd_path.exists():
        return cwd_path
    source_root = _path_from_direct_url()
    if source_root is not None:
        candidate = source_root / "refs" / "melee"
        if candidate.exists():
            return candidate.resolve()
    return None


def _extract_glob(*, iso: Path, files, pattern: str, out_dir: Path, force: bool) -> int:
    matches = find_files(files, pattern)
    if not matches:
        raise SystemExit(f"missing required ISO file matching {pattern!r}")
    count = 0
    for match in matches:
        out = out_dir / Path(match.path).name
        if out.exists() and not force:
            print(f"exists {out}; skipping")
            continue
        extract_file(iso, match, out)
        print(f"wrote {out} ({match.size} bytes)")
        count += 1
    return count


def _dol_file_size(header: bytes, *, available_size: int) -> int:
    if len(header) != _DOL_HEADER_SIZE:
        raise ValueError("DOL header is truncated")
    if available_size < _DOL_HEADER_SIZE:
        raise ValueError("DOL header extends beyond its container")

    dol_size = _DOL_HEADER_SIZE
    found_section = False
    for section_kind, offset_base, size_base, count in _DOL_SECTION_LAYOUTS:
        for index in range(count):
            file_offset = int.from_bytes(header[offset_base + index * 4 : offset_base + index * 4 + 4], "big")
            section_size = int.from_bytes(header[size_base + index * 4 : size_base + index * 4 + 4], "big")
            if not section_size:
                continue
            found_section = True
            section_end = file_offset + section_size
            if section_end > 0xFFFF_FFFF:
                raise ValueError(f"{section_kind} section {index} file range overflows 32 bits")
            if section_end > available_size:
                raise ValueError(f"{section_kind} section {index} extends beyond its container")
            dol_size = max(dol_size, section_end)

    if not found_section:
        raise ValueError("DOL has no file sections")
    return dol_size


def _main_dol_entry(iso: Path) -> IsoFile:
    """Return the ISO-backed main DOL after validating its declared sections."""
    iso_size = iso.stat().st_size
    if iso_size < _GAMECUBE_DOL_OFFSET + 4:
        raise SystemExit(f"invalid ISO main.dol: ISO is too small for the DOL offset ({iso})")

    with iso.open("rb") as f:
        f.seek(_GAMECUBE_DOL_OFFSET)
        dol_offset_bytes = f.read(4)
        if len(dol_offset_bytes) != 4:
            raise SystemExit(f"corrupt ISO main.dol: DOL offset is truncated ({iso})")
        dol_offset = int.from_bytes(dol_offset_bytes, "big", signed=False)
        if not dol_offset:
            raise SystemExit(f"missing ISO main.dol: DOL offset is zero ({iso})")
        if dol_offset + _DOL_HEADER_SIZE > iso_size:
            raise SystemExit(f"corrupt ISO main.dol: DOL header extends beyond ISO ({iso})")

        f.seek(dol_offset)
        header = f.read(_DOL_HEADER_SIZE)

    try:
        dol_size = _dol_file_size(header, available_size=iso_size - dol_offset)
    except ValueError as exc:
        raise SystemExit(f"corrupt ISO main.dol: {exc} ({iso})") from exc
    return IsoFile(path="main.dol", offset=dol_offset, size=dol_size)


def _validate_cached_main_dol(path: Path) -> None:
    try:
        available_size = path.stat().st_size
        with path.open("rb") as f:
            header = f.read(_DOL_HEADER_SIZE)
    except OSError as exc:
        raise ValueError(f"cannot read cached DOL: {exc}") from exc
    _dol_file_size(header, available_size=available_size)


def _extract_main_dol(*, iso: Path, out_dir: Path, force: bool) -> None:
    out = out_dir / "main.dol"
    if out.exists() and not force:
        try:
            _validate_cached_main_dol(out)
        except ValueError as exc:
            raise SystemExit(
                f"cached main.dol is invalid: {out}: {exc}\n"
                "rerun with --force to replace it from the ISO, or remove the cached file"
            ) from exc
        print(f"exists {out}; skipping")
        return
    entry = _main_dol_entry(iso)
    extract_file(iso, entry, out)
    print(f"wrote {out} ({entry.size} bytes)")


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="Extract melee-sim-light data from an SSBM ISO.")
    ap.add_argument("--iso", type=Path, required=True, help="path to a valid SSBM ISO")
    ap.add_argument("--out-dir", type=Path, default=Path(".msl"), help="generated data directory")
    ap.add_argument("--iso-dir", type=Path, default=None, help="directory for extracted source files")
    ap.add_argument("--force", action="store_true", help="rewrite already-extracted source files")
    ap.add_argument(
        "--chars",
        type=str,
        default=",".join(_CHAR_GLOBS),
        help="comma-separated characters (default: every registry character)",
    )
    ap.add_argument(
        "--stages",
        type=str,
        default="grnla,grnba,griz,grps,grst,grop",
        help="comma-separated stage keys",
    )
    ap.add_argument("--melee-decomp", type=Path, default=None, help="path to doldecomp/melee checkout")
    ap.add_argument("--timings", action="store_true", help="print per-generator wall-clock timings")
    args = ap.parse_args(argv)

    iso = args.iso.expanduser().resolve()
    if not iso.is_file():
        raise SystemExit(f"missing ISO: {iso}")
    out_dir = args.out_dir.expanduser().resolve()
    iso_dir = (args.iso_dir or (out_dir / "_iso")).expanduser().resolve()
    chars = [c.strip().lower() for c in args.chars.split(",") if c.strip()]
    stages = [s.strip().lower() for s in args.stages.split(",") if s.strip()]

    unknown_chars = [c for c in chars if c not in _CHAR_GLOBS]
    if unknown_chars:
        raise SystemExit(f"unsupported character key(s): {unknown_chars!r}")
    unknown_stages = [s for s in stages if s not in _STAGE_DAT_BY_KEY]
    if unknown_stages:
        raise SystemExit(f"unsupported stage key(s): {unknown_stages!r}")

    iso_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = list_files(iso)
    for pattern in ("*PlCo.dat", "*ItCo.dat"):
        _extract_glob(iso=iso, files=files, pattern=pattern, out_dir=iso_dir, force=args.force)
    for ch in chars:
        _extract_glob(iso=iso, files=files, pattern=_CHAR_GLOBS[ch], out_dir=iso_dir, force=args.force)
    for stage in stages:
        _extract_glob(
            iso=iso,
            files=files,
            pattern=f"*{_STAGE_DAT_BY_KEY[stage]}",
            out_dir=iso_dir,
            force=args.force,
        )
    if "samus" in chars:
        _extract_main_dol(iso=iso, out_dir=iso_dir, force=args.force)

    melee_decomp = args.melee_decomp.expanduser().resolve() if args.melee_decomp else _default_melee_decomp()
    cmd = [
        sys.executable,
        "-m",
        "tools.extraction.build_data",
        "--iso-dir",
        str(iso_dir),
        "--out-dir",
        str(out_dir),
        "--stages",
        ",".join(stages),
        "--chars",
        ",".join(chars),
    ]
    if melee_decomp is not None and melee_decomp.exists():
        cmd.extend(["--melee-decomp", str(melee_decomp)])
    if args.timings:
        cmd.append("--timings")
    print("$", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
