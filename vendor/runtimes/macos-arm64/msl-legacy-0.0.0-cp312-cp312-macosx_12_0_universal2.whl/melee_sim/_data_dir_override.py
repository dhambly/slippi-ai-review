from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from threading import RLock
from typing import Iterator, Protocol

from tools.native_build_provenance import (
    NATIVE_BUILD_INPUT_ATTRIBUTE,
    native_build_input_sha256,
)


class NativeDataDirBinding(Protocol):
    def set_data_dir(self, path: str) -> None: ...

    def clear_data_dir(self) -> None: ...


_LOCK = RLock()
_LEASES: list[NativeDataDirLease] = []


def _require_current_native_build(binding: NativeDataDirBinding) -> None:
    """Reject an in-place extension built against a different native ABI."""

    embedded = getattr(binding, NATIVE_BUILD_INPUT_ATTRIBUTE, None)
    repo_root = Path(__file__).resolve().parents[1]
    if not isinstance(embedded, str) or not (repo_root / "src").is_dir():
        return
    if embedded != native_build_input_sha256(repo_root):
        raise RuntimeError(
            "native extension does not match the current C sources; run `make build` before "
            "validation"
        )


@dataclass(slots=True, eq=False)
class NativeDataDirLease:
    binding: NativeDataDirBinding
    root: str
    _active: bool = True

    def close(self) -> None:
        """Release once, restoring an enclosing owner after clearing this override."""
        with _LOCK:
            if not self._active:
                return
            self._active = False

            clear_error: BaseException | None = None
            try:
                self.binding.clear_data_dir()
            except BaseException as exc:
                clear_error = exc

            _LEASES.remove(self)
            try:
                if _LEASES:
                    owner = _LEASES[-1]
                    owner.binding.set_data_dir(owner.root)
            except BaseException as restore_error:
                if clear_error is None:
                    raise
                clear_error.add_note(f"failed to restore enclosing native data root: {restore_error}")

            if clear_error is not None:
                raise clear_error


def acquire_native_data_dir(
    binding: NativeDataDirBinding,
    data_root: str | Path,
) -> NativeDataDirLease:
    _require_current_native_build(binding)
    root = str(Path(data_root).expanduser().resolve())
    lease = NativeDataDirLease(binding=binding, root=root)
    with _LOCK:
        binding.set_data_dir(root)
        try:
            _LEASES.append(lease)
        except BaseException:
            binding.clear_data_dir()
            raise
    return lease


@contextmanager
def native_data_dir_override(
    binding: NativeDataDirBinding,
    data_root: str | Path,
) -> Iterator[str]:
    lease = acquire_native_data_dir(binding, data_root)
    try:
        yield lease.root
    finally:
        lease.close()
